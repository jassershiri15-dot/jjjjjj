# QueueMaster Pro — 4 Applications

Système complet de gestion de file d'attente avec **4 applications** et un backend **.NET 10** en Clean Architecture.

---

## Architecture globale

```
QueueMaster4Apps/
├── backend/                          # API .NET 10
│   ├── QueueMaster.Domain/           # Entités, enums, événements, interfaces
│   ├── QueueMaster.Application/      # Use cases MediatR, DTOs, interfaces services
│   ├── QueueMaster.Infrastructure/   # EF Core, repos, Firebase, SendGrid, SignalR
│   └── QueueMaster.API/              # Controllers REST, Hubs, Middleware, Program.cs
└── apps/
    ├── mobile/    # App 1 — Client smartphone (iOS/Android)
    ├── tablet/    # App 2 — Client tablette (iPad/Android tablet)
    ├── tv/        # App 3 — Affichage salle d'attente (Android TV)
    └── admin/     # App 4 — Administration web/desktop
```

---

## Les 4 applications

| App | Plateforme | Utilisateurs | Fonctionnalités clés |
|-----|-----------|--------------|----------------------|
| Mobile | iOS / Android | Clients | Rejoindre file, suivi ticket, notifications push+email, RDV, QR code |
| Tablette | iPad / Android | Clients / Agents | Même que mobile + layout 2 colonnes + vue file |
| TV | Android TV / Chrome | Affichage salle | Ticket appelé, file en temps réel, stats, bandeau défilant |
| Admin | Web / Desktop | Superviseurs / Admins | Dashboard KPIs, graphiques, supervision file, gestion agents, rapports |

---

## Notifications (Push + Email)

| Événement | Push FCM | Email SendGrid |
|-----------|----------|----------------|
| Ticket créé | Position + attente estimée | HTML avec numéro, service, position |
| Ticket appelé | "C'est votre tour ! Guichet X" | HTML urgent avec guichet |
| Ticket servi | "Merci !" | HTML de confirmation |
| Rappel position (3 restants) | Notification push | — |
| RDV confirmé | Détails + code QR | HTML avec QR code |
| Rappel RDV (24h et 1h) | Push | Email |

---

## Démarrage rapide

### 1. Variables d'environnement

```bash
cp .env.example .env
# Renseigner :
# SA_PASSWORD=VotrePass@123
# JWT_SECRET=votre-cle-secrete-32-chars!
# SENDGRID_API_KEY=SG.xxx
# FROM_EMAIL=noreply@votre-domaine.com
```

### 2. Backend avec Docker

```bash
docker compose up -d
# API disponible sur http://localhost:5000/swagger
# Logs sur http://localhost:5341 (Seq)
```

### 3. Backend sans Docker

```bash
cd backend/QueueMaster.API
dotnet run
```

### 4. Applications Flutter

```bash
# Installer les dépendances (faire pour chaque app)
cd apps/mobile && flutter pub get
cd apps/tablet && flutter pub get
cd apps/tv     && flutter pub get
cd apps/admin  && flutter pub get

# Lancer l'app de votre choix
flutter run  # dans le dossier de l'app

# Build release
flutter build apk --release          # Android
flutter build ipa --release          # iOS
flutter build web --release          # Admin web
```

### 5. Configuration Firebase (notifications push)

1. Créer un projet Firebase sur [console.firebase.google.com](https://console.firebase.google.com)
2. Ajouter les apps iOS et Android
3. Télécharger `google-services.json` → `apps/mobile/android/app/`
4. Télécharger `GoogleService-Info.plist` → `apps/mobile/ios/Runner/`
5. Télécharger les credentials admin → `backend/QueueMaster.API/firebase-credentials.json`

---

## API REST — Endpoints principaux

```
POST   /api/auth/register          Inscription client
POST   /api/auth/login             Connexion
POST   /api/auth/refresh           Rafraîchir le token
POST   /api/auth/fcm-token         Mettre à jour le token FCM (push)

GET    /api/services               Lister les services actifs
GET    /api/services/{id}/slots    Créneaux disponibles

POST   /api/tickets                Créer un ticket (rejoindre la file)
GET    /api/tickets/{id}/position  Position et attente estimée
DELETE /api/tickets/{id}           Annuler son ticket
POST   /api/tickets/call-next      Appeler le suivant (agent)
POST   /api/tickets/{id}/serve     Marquer comme servi (agent)
POST   /api/tickets/{id}/no-show   Marquer comme absent (agent)

GET    /api/queues/{serviceId}     File complète d'un service
GET    /api/queues/{serviceId}/stats  Statistiques temps réel

POST   /api/appointments           Créer un rendez-vous
POST   /api/appointments/checkin   Check-in par QR code
DELETE /api/appointments/{id}      Annuler un rendez-vous

GET    /api/agents                 Lister les agents (admin/agent)
PATCH  /api/agents/{id}/status     Changer statut agent (actif/pause)
```

## SignalR Hub — /hubs/queue

| Groupe | Membres |
|--------|---------|
| `service-{id}` | Agents du service |
| `client-{id}` | App du client |
| `display` | App TV |
| `admin` | App Administration |

| Événement (serveur → client) | Contenu |
|------------------------------|---------|
| `PositionUpdated` | ticketId, newPosition, estimatedWait |
| `TicketCalled` | ticketNumber, counter, agentName |
| `TicketServed` | ticketId, ticketNumber |
| `QueueStatsUpdated` | totalWaiting, served, avgWait, agents |
| `NewTicket` | ticket complet |

---

## Sécurité

- JWT Bearer (15 min) + Refresh Token (7 jours)
- Rôles : `Client`, `Agent`, `Admin`
- Rate limiting : 100 req/min (API), 10 req/5min (Auth)
- HTTPS/TLS obligatoire en production
- Données sensibles dans Azure Key Vault / secrets dotnet

---

## Licence MIT
