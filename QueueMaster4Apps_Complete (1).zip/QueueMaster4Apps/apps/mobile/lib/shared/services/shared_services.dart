// ============================================================
// SHARED SERVICES — utilisé par les 4 applications Flutter
// ============================================================
import 'package:dio/dio.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:signalr_netcoreapp3_1/signalr_netcoreapp3_1.dart';

const kBaseUrl = 'https://api.queuemaster.pro/api';
const kHubUrl  = 'https://api.queuemaster.pro/hubs/queue';

// ── Models ────────────────────────────────────────────────────────────────────
class ServiceModel {
  final String id, name;
  final String? description, color;
  final int maxCapacity, avgMinutes, estimatedWait, currentQueue;
  final bool isActive;
  final String openTime, closeTime;

  ServiceModel({required this.id, required this.name, this.description,
    this.color, required this.maxCapacity, required this.avgMinutes,
    required this.estimatedWait, required this.currentQueue,
    required this.isActive, required this.openTime, required this.closeTime});

  factory ServiceModel.fromJson(Map<String, dynamic> j) => ServiceModel(
    id: j['id'], name: j['name'], description: j['description'],
    color: j['color'], maxCapacity: j['maxCapacity'],
    avgMinutes: j['averageServiceMinutes'], estimatedWait: j['estimatedWaitMinutes'],
    currentQueue: j['currentQueue'], isActive: j['isActive'],
    openTime: j['openTime'], closeTime: j['closeTime']);
}

enum TicketStatus { waiting, calling, served, cancelled, noShow }
enum TicketPriority { emergency, priority, vip, standard }

class TicketModel {
  final String id, ticketNumber, clientId, clientName, serviceId, serviceName;
  final TicketPriority priority;
  final TicketStatus status;
  final DateTime createdAt;
  final int estimatedWaitMinutes, position;
  final String? counter;

  TicketModel({required this.id, required this.ticketNumber,
    required this.clientId, required this.clientName,
    required this.serviceId, required this.serviceName,
    required this.priority, required this.status,
    required this.createdAt, required this.estimatedWaitMinutes,
    required this.position, this.counter});

  factory TicketModel.fromJson(Map<String, dynamic> j) => TicketModel(
    id: j['id'], ticketNumber: j['ticketNumber'],
    clientId: j['clientId'], clientName: j['clientName'] ?? '',
    serviceId: j['serviceId'], serviceName: j['serviceName'] ?? '',
    priority: TicketPriority.values[(j['priority'] as int) - 1],
    status: TicketStatus.values[(j['status'] as int) - 1],
    createdAt: DateTime.parse(j['createdAt']),
    estimatedWaitMinutes: j['estimatedWaitMinutes'],
    position: j['position'] ?? 0,
    counter: j['counter']);
}

class QueueStatsModel {
  final String serviceId, serviceName;
  final int totalWaiting, totalServedToday, activeAgents;
  final double averageWaitMinutes;

  QueueStatsModel({required this.serviceId, required this.serviceName,
    required this.totalWaiting, required this.totalServedToday,
    required this.activeAgents, required this.averageWaitMinutes});

  factory QueueStatsModel.fromJson(Map<String, dynamic> j) => QueueStatsModel(
    serviceId: j['serviceId'], serviceName: j['serviceName'],
    totalWaiting: j['totalWaiting'], totalServedToday: j['totalServedToday'],
    activeAgents: j['activeAgents'],
    averageWaitMinutes: (j['averageWaitMinutes'] as num).toDouble());
}

class AppointmentModel {
  final String id, clientId, clientName, clientEmail, serviceId, serviceName, qrCode;
  final DateTime scheduledAt;
  final int status;

  AppointmentModel({required this.id, required this.clientId,
    required this.clientName, required this.clientEmail,
    required this.serviceId, required this.serviceName,
    required this.qrCode, required this.scheduledAt, required this.status});

  factory AppointmentModel.fromJson(Map<String, dynamic> j) => AppointmentModel(
    id: j['id'], clientId: j['clientId'], clientName: j['clientName'],
    clientEmail: j['clientEmail'], serviceId: j['serviceId'],
    serviceName: j['serviceName'], qrCode: j['qrCode'],
    scheduledAt: DateTime.parse(j['scheduledAt']), status: j['status']);
}

class AuthResponse {
  final String accessToken, refreshToken, role;
  final int expiresIn;
  final String? clientId, agentId;

  AuthResponse({required this.accessToken, required this.refreshToken,
    required this.role, required this.expiresIn,
    this.clientId, this.agentId});

  factory AuthResponse.fromJson(Map<String, dynamic> j) => AuthResponse(
    accessToken: j['accessToken'], refreshToken: j['refreshToken'],
    role: j['role'], expiresIn: j['expiresIn'],
    clientId: j['clientId'], agentId: j['agentId']);
}

// ── Dio Provider ──────────────────────────────────────────────────────────────
final dioProvider = Provider<Dio>((ref) {
  final dio = Dio(BaseOptions(
    baseUrl: kBaseUrl,
    connectTimeout: const Duration(seconds: 10),
    receiveTimeout: const Duration(seconds: 15),
    headers: {'Content-Type': 'application/json'},
  ));
  dio.interceptors.add(AuthInterceptor());
  return dio;
});

class AuthInterceptor extends QueuedInterceptorsWrapper {
  static const _storage = FlutterSecureStorage();

  @override
  Future<void> onRequest(RequestOptions options, RequestInterceptorHandler handler) async {
    final token = await _storage.read(key: 'access_token');
    if (token != null) options.headers['Authorization'] = 'Bearer $token';
    handler.next(options);
  }

  @override
  Future<void> onError(DioException err, ErrorInterceptorHandler handler) async {
    if (err.response?.statusCode == 401) {
      try {
        if (await _refreshAccessToken()) {
          final token = await _storage.read(key: 'access_token');
          err.requestOptions.headers['Authorization'] = 'Bearer $token';
          final response = await Dio().fetch(err.requestOptions);
          return handler.resolve(response);
        }
      } catch (_) {}
    }
    handler.next(err);
  }

  Future<bool> _refreshAccessToken() async {
    final userId = await _storage.read(key: 'user_id');
    final refreshToken = await _storage.read(key: 'refresh_token');
    if (userId == null || refreshToken == null) return false;
    final dio = Dio(BaseOptions(baseUrl: kBaseUrl));
    final res = await dio.post('/auth/refresh',
        data: {'userId': userId, 'refreshToken': refreshToken});
    if (res.statusCode == 200) {
      final data = AuthResponse.fromJson(res.data);
      await _storage.write(key: 'access_token', value: data.accessToken);
      await _storage.write(key: 'refresh_token', value: data.refreshToken);
      return true;
    }
    return false;
  }
}

// ── API Service ───────────────────────────────────────────────────────────────
final apiProvider = Provider<ApiService>((ref) => ApiService(ref.watch(dioProvider)));

class ApiService {
  final Dio _dio;
  ApiService(this._dio);

  // Auth
  Future<AuthResponse> login(String email, String password) async {
    final res = await _dio.post('/auth/login', data: {'email': email, 'password': password});
    return AuthResponse.fromJson(res.data);
  }

  Future<AuthResponse> register(String fullName, String email, String password, String? phone) async {
    final res = await _dio.post('/auth/register',
        data: {'fullName': fullName, 'email': email, 'password': password, 'phone': phone});
    return AuthResponse.fromJson(res.data);
  }

  Future<void> updateFcmToken(String fcmToken) async
    => await _dio.post('/auth/fcm-token', data: {'fcmToken': fcmToken});

  // Services
  Future<List<ServiceModel>> getServices() async {
    final res = await _dio.get('/services');
    return (res.data as List).map((e) => ServiceModel.fromJson(e)).toList();
  }

  Future<List<DateTime>> getSlots(String serviceId, DateTime date) async {
    final res = await _dio.get('/services/$serviceId/slots',
        queryParameters: {'date': date.toIso8601String()});
    return (res.data as List).map((e) => DateTime.parse(e as String)).toList();
  }

  // Tickets
  Future<TicketModel> createTicket(String clientId, String serviceId, int priority) async {
    final res = await _dio.post('/tickets',
        data: {'clientId': clientId, 'serviceId': serviceId, 'priority': priority});
    return TicketModel.fromJson(res.data);
  }

  Future<Map<String, dynamic>> getPosition(String ticketId) async {
    final res = await _dio.get('/tickets/$ticketId/position');
    return res.data;
  }

  Future<void> cancelTicket(String ticketId) async
    => await _dio.delete('/tickets/$ticketId');

  Future<List<TicketModel>> getQueue(String serviceId, {String? status}) async {
    final res = await _dio.get('/queues/$serviceId',
        queryParameters: status != null ? {'status': status} : null);
    return (res.data as List).map((e) => TicketModel.fromJson(e)).toList();
  }

  Future<QueueStatsModel> getQueueStats(String serviceId) async {
    final res = await _dio.get('/queues/$serviceId/stats');
    return QueueStatsModel.fromJson(res.data);
  }

  // Agent actions
  Future<TicketModel?> callNext(String serviceId) async {
    final res = await _dio.post('/tickets/call-next', data: {'serviceId': serviceId});
    if (res.statusCode == 204) return null;
    return TicketModel.fromJson(res.data);
  }

  Future<void> serveTicket(String ticketId, {String? notes}) async
    => await _dio.post('/tickets/$ticketId/serve', data: {'notes': notes});

  Future<void> markNoShow(String ticketId) async
    => await _dio.post('/tickets/$ticketId/no-show');

  // Appointments
  Future<AppointmentModel> createAppointment(
      String clientId, String serviceId, DateTime scheduledAt) async {
    final res = await _dio.post('/appointments',
        data: {'clientId': clientId, 'serviceId': serviceId,
               'scheduledAt': scheduledAt.toIso8601String()});
    return AppointmentModel.fromJson(res.data);
  }

  Future<AppointmentModel> checkIn(String qrCode) async {
    final res = await _dio.post('/appointments/checkin', data: {'qrCode': qrCode});
    return AppointmentModel.fromJson(res.data);
  }
}

// ── SignalR Service ───────────────────────────────────────────────────────────
final signalRProvider = Provider<SignalRService>((ref) => SignalRService());

class SignalRService {
  HubConnection? _connection;
  static const _storage = FlutterSecureStorage();

  final _positionCallbacks = <void Function(Map<String, dynamic>)>[];
  final _ticketCalledCallbacks = <void Function(Map<String, dynamic>)>[];
  final _statsCallbacks = <void Function(QueueStatsModel)>[];
  final _newTicketCallbacks = <void Function(TicketModel)>[];

  Future<void> connect() async {
    final token = await _storage.read(key: 'access_token');
    _connection = HubConnectionBuilder()
        .withUrl(kHubUrl, options: HttpConnectionOptions(
          accessTokenFactory: () async => token,
          skipNegotiation: true,
          transport: HttpTransportType.WebSockets))
        .withAutomaticReconnect()
        .build();

    _connection!.on('PositionUpdated', (args) {
      if (args != null && args.isNotEmpty)
        for (final cb in _positionCallbacks) cb(args[0] as Map<String, dynamic>);
    });
    _connection!.on('TicketCalled', (args) {
      if (args != null && args.isNotEmpty)
        for (final cb in _ticketCalledCallbacks) cb(args[0] as Map<String, dynamic>);
    });
    _connection!.on('QueueStatsUpdated', (args) {
      if (args != null && args.isNotEmpty) {
        final stats = QueueStatsModel.fromJson(args[0] as Map<String, dynamic>);
        for (final cb in _statsCallbacks) cb(stats);
      }
    });
    _connection!.on('NewTicket', (args) {
      if (args != null && args.isNotEmpty) {
        final ticket = TicketModel.fromJson(args[0] as Map<String, dynamic>);
        for (final cb in _newTicketCallbacks) cb(ticket);
      }
    });

    await _connection!.start();
  }

  Future<void> joinServiceGroup(String serviceId) async
    => await _connection?.invoke('JoinServiceGroup', args: [serviceId]);
  Future<void> joinClientGroup(String clientId) async
    => await _connection?.invoke('JoinClientGroup', args: [clientId]);
  Future<void> joinDisplayGroup() async
    => await _connection?.invoke('JoinDisplayGroup');
  Future<void> joinAdminGroup() async
    => await _connection?.invoke('JoinAdminGroup');

  void onPositionUpdated(void Function(Map<String, dynamic>) cb) => _positionCallbacks.add(cb);
  void onTicketCalled(void Function(Map<String, dynamic>) cb) => _ticketCalledCallbacks.add(cb);
  void onStatsUpdated(void Function(QueueStatsModel) cb) => _statsCallbacks.add(cb);
  void onNewTicket(void Function(TicketModel) cb) => _newTicketCallbacks.add(cb);

  Future<void> disconnect() async {
    await _connection?.stop();
    _positionCallbacks.clear();
    _ticketCalledCallbacks.clear();
    _statsCallbacks.clear();
    _newTicketCallbacks.clear();
  }
}
