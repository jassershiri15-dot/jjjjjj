// ============================================================
// APP 1 — APPLICATION MOBILE CLIENT
// ============================================================

// main.dart
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:go_router/go_router.dart';
import 'shared/services/shared_services.dart';

// ── Notification Initialization ───────────────────────────────────────────────
final _localNotifs = FlutterLocalNotificationsPlugin();

Future<void> _bgHandler(RemoteMessage message) async {
  await _localNotifs.show(
    message.hashCode,
    message.notification?.title,
    message.notification?.body,
    const NotificationDetails(
      android: AndroidNotificationDetails('queuemaster', 'QueueMaster',
          importance: Importance.high, priority: Priority.high),
      iOS: DarwinNotificationDetails(presentAlert: true, presentSound: true),
    ),
  );
}

Future<void> _initNotifications() async {
  await Firebase.initializeApp();
  FirebaseMessaging.onBackgroundMessage(_bgHandler);
  await _localNotifs.initialize(
    const InitializationSettings(
      android: AndroidInitializationSettings('@mipmap/ic_launcher'),
      iOS: DarwinInitializationSettings(
          requestAlertPermission: true,
          requestBadgePermission: true,
          requestSoundPermission: true),
    ),
  );
  FirebaseMessaging.onMessage.listen(_bgHandler);
  await FirebaseMessaging.instance.requestPermission(alert: true, badge: true, sound: true);
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await _initNotifications();
  runApp(const ProviderScope(child: MobileApp()));
}

class MobileApp extends StatelessWidget {
  const MobileApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp.router(
      title: 'QueueMaster',
      theme: _buildTheme(),
      darkTheme: _buildDarkTheme(),
      themeMode: ThemeMode.system,
      routerConfig: _buildRouter(),
      debugShowCheckedModeBanner: false,
    );
  }

  ThemeData _buildTheme() => ThemeData(
    useMaterial3: true,
    colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF1E3A5F)),
    fontFamily: 'Inter',
    appBarTheme: const AppBarTheme(centerTitle: false, elevation: 0),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none),
      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(color: Color(0xFF1E3A5F), width: 1.5)),
    ),
  );

  ThemeData _buildDarkTheme() => ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF4A90D9), brightness: Brightness.dark),
    fontFamily: 'Inter',
  );

  GoRouter _buildRouter() => GoRouter(
    initialLocation: '/home',
    routes: [
      GoRoute(path: '/login', builder: (_, __) => const LoginScreen()),
      GoRoute(path: '/home', builder: (_, __) => const HomeScreen()),
      GoRoute(path: '/ticket', builder: (_, state) => MyTicketScreen(ticket: state.extra as TicketModel)),
      GoRoute(path: '/appointments', builder: (_, __) => const AppointmentsScreen()),
      GoRoute(path: '/notifications', builder: (_, __) => const NotificationsScreen()),
      GoRoute(path: '/profile', builder: (_, __) => const ProfileScreen()),
    ],
  );
}

// ── Auth Provider ─────────────────────────────────────────────────────────────
final authStateProvider = StateNotifierProvider<AuthNotifier, AuthState>((ref) {
  return AuthNotifier(ref.watch(apiProvider));
});

class AuthState {
  final bool isLoggedIn;
  final String? clientId, role, error;
  final bool isLoading;
  AuthState({this.isLoggedIn = false, this.clientId, this.role,
    this.error, this.isLoading = false});
  AuthState copyWith({bool? isLoggedIn, String? clientId, String? role,
    String? error, bool? isLoading}) =>
      AuthState(isLoggedIn: isLoggedIn ?? this.isLoggedIn,
        clientId: clientId ?? this.clientId, role: role ?? this.role,
        error: error, isLoading: isLoading ?? this.isLoading);
}

class AuthNotifier extends StateNotifier<AuthState> {
  final ApiService _api;
  static const _storage = FlutterSecureStorage();
  AuthNotifier(this._api) : super(AuthState()) { _checkSession(); }

  Future<void> _checkSession() async {
    final token = await _storage.read(key: 'access_token');
    final clientId = await _storage.read(key: 'client_id');
    if (token != null && clientId != null)
      state = state.copyWith(isLoggedIn: true, clientId: clientId, role: 'Client');
  }

  Future<void> login(String email, String password) async {
    state = state.copyWith(isLoading: true);
    try {
      final res = await _api.login(email, password);
      await _storage.write(key: 'access_token', value: res.accessToken);
      await _storage.write(key: 'refresh_token', value: res.refreshToken);
      if (res.clientId != null) await _storage.write(key: 'client_id', value: res.clientId);
      state = state.copyWith(isLoggedIn: true, clientId: res.clientId, role: res.role, isLoading: false);
    } catch (e) {
      state = state.copyWith(error: e.toString(), isLoading: false);
    }
  }

  Future<void> register(String name, String email, String pass, String? phone) async {
    state = state.copyWith(isLoading: true);
    try {
      final res = await _api.register(name, email, pass, phone);
      await _storage.write(key: 'access_token', value: res.accessToken);
      await _storage.write(key: 'refresh_token', value: res.refreshToken);
      if (res.clientId != null) await _storage.write(key: 'client_id', value: res.clientId);
      // Update FCM token after registration
      final fcmToken = await FirebaseMessaging.instance.getToken();
      if (fcmToken != null) await _api.updateFcmToken(fcmToken);
      state = state.copyWith(isLoggedIn: true, clientId: res.clientId, role: res.role, isLoading: false);
    } catch (e) {
      state = state.copyWith(error: e.toString(), isLoading: false);
    }
  }

  Future<void> logout() async {
    await _storage.deleteAll();
    state = AuthState();
  }
}

// ── Login Screen ──────────────────────────────────────────────────────────────
class LoginScreen extends ConsumerStatefulWidget {
  const LoginScreen({super.key});
  @override
  ConsumerState<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends ConsumerState<LoginScreen> {
  final _emailCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  bool _isRegister = false;
  final _nameCtrl = TextEditingController();
  final _phoneCtrl = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final auth = ref.watch(authStateProvider);
    final theme = Theme.of(context);

    ref.listen(authStateProvider, (_, next) {
      if (next.isLoggedIn) context.go('/home');
    });

    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(children: [
            const SizedBox(height: 48),
            Container(
              width: 72, height: 72,
              decoration: BoxDecoration(
                color: const Color(0xFF1E3A5F),
                borderRadius: BorderRadius.circular(18),
              ),
              child: const Icon(Icons.queue, color: Colors.white, size: 36),
            ),
            const SizedBox(height: 16),
            Text('QueueMaster Pro', style: theme.textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w600)),
            Text(_isRegister ? 'Créer un compte' : 'Connexion',
                style: theme.textTheme.bodyMedium?.copyWith(color: theme.colorScheme.onSurface.withOpacity(0.6))),
            const SizedBox(height: 32),

            if (_isRegister) ...[
              TextField(controller: _nameCtrl, decoration: const InputDecoration(labelText: 'Nom complet', prefixIcon: Icon(Icons.person_outline))),
              const SizedBox(height: 12),
              TextField(controller: _phoneCtrl, decoration: const InputDecoration(labelText: 'Téléphone (optionnel)', prefixIcon: Icon(Icons.phone_outlined))),
              const SizedBox(height: 12),
            ],

            TextField(controller: _emailCtrl, keyboardType: TextInputType.emailAddress,
                decoration: const InputDecoration(labelText: 'Email', prefixIcon: Icon(Icons.email_outlined))),
            const SizedBox(height: 12),
            TextField(controller: _passCtrl, obscureText: true,
                decoration: const InputDecoration(labelText: 'Mot de passe', prefixIcon: Icon(Icons.lock_outlined))),

            if (auth.error != null) ...[
              const SizedBox(height: 12),
              Container(padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(color: Colors.red.shade50, borderRadius: BorderRadius.circular(8)),
                child: Text(auth.error!, style: const TextStyle(color: Colors.red, fontSize: 13))),
            ],

            const SizedBox(height: 24),
            FilledButton(
              onPressed: auth.isLoading ? null : () {
                if (_isRegister)
                  ref.read(authStateProvider.notifier).register(
                    _nameCtrl.text, _emailCtrl.text, _passCtrl.text,
                    _phoneCtrl.text.isEmpty ? null : _phoneCtrl.text);
                else
                  ref.read(authStateProvider.notifier).login(_emailCtrl.text, _passCtrl.text);
              },
              style: FilledButton.styleFrom(minimumSize: const Size(double.infinity, 52),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
              child: auth.isLoading
                  ? const CircularProgressIndicator(color: Colors.white, strokeWidth: 2)
                  : Text(_isRegister ? "S'inscrire" : 'Se connecter'),
            ),

            const SizedBox(height: 16),
            TextButton(
              onPressed: () => setState(() => _isRegister = !_isRegister),
              child: Text(_isRegister ? 'Déjà un compte ? Se connecter' : "Pas de compte ? S'inscrire"),
            ),
          ]),
        ),
      ),
    );
  }
}

// ── Services Provider ─────────────────────────────────────────────────────────
final servicesProvider = FutureProvider<List<ServiceModel>>((ref) async {
  return ref.watch(apiProvider).getServices();
});

// ── Home Screen ───────────────────────────────────────────────────────────────
class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});
  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen> {
  ServiceModel? _selected;
  int _priority = 4;

  @override
  Widget build(BuildContext context) {
    final servicesAsync = ref.watch(servicesProvider);
    final theme = Theme.of(context);

    return Scaffold(
      body: CustomScrollView(slivers: [
        SliverAppBar.large(
          title: const Text('QueueMaster Pro'),
          actions: [
            IconButton(icon: const Icon(Icons.notifications_outlined),
                onPressed: () => context.push('/notifications')),
            IconButton(icon: const Icon(Icons.account_circle_outlined),
                onPressed: () => context.push('/profile')),
          ],
        ),
        SliverPadding(
          padding: const EdgeInsets.all(16),
          sliver: SliverList(delegate: SliverChildListDelegate([
            _WelcomeBanner(),
            const SizedBox(height: 20),
            Text('Services disponibles', style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w600)),
            const SizedBox(height: 10),
            servicesAsync.when(
              loading: () => const Center(child: CircularProgressIndicator()),
              error: (e, _) => _ErrorCard(message: e.toString(),
                  onRetry: () => ref.invalidate(servicesProvider)),
              data: (services) => Column(
                children: services.map((s) => _ServiceCard(
                  service: s, isSelected: _selected?.id == s.id,
                  onTap: () => setState(() => _selected = s),
                )).toList(),
              ),
            ),
            if (_selected != null) ...[
              const SizedBox(height: 20),
              Text('Priorité', style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w600)),
              const SizedBox(height: 8),
              _PrioritySelector(selected: _priority, onChanged: (p) => setState(() => _priority = p)),
              const SizedBox(height: 20),
              _JoinButton(service: _selected!, priority: _priority),
            ],
            const SizedBox(height: 24),
            _QuickActions(),
          ])),
        ),
      ]),
    );
  }
}

class _WelcomeBanner extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: theme.colorScheme.primary,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(children: [
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Bienvenue !', style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w600)),
          const SizedBox(height: 4),
          Text('Sélectionnez un service pour rejoindre la file',
              style: TextStyle(color: Colors.white.withOpacity(0.8), fontSize: 13)),
        ])),
        const Icon(Icons.queue, color: Colors.white, size: 40),
      ]),
    );
  }
}

class _ServiceCard extends StatelessWidget {
  final ServiceModel service;
  final bool isSelected;
  final VoidCallback onTap;
  const _ServiceCard({required this.service, required this.isSelected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final color = Color(int.parse((service.color ?? '#1E3A5F').replaceFirst('#', '0xFF')));
    return GestureDetector(
      onTap: service.isActive ? onTap : null,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: isSelected ? color.withOpacity(0.08) : theme.colorScheme.surface,
          border: Border.all(color: isSelected ? color : theme.dividerColor, width: isSelected ? 2 : 0.5),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(children: [
          Container(width: 40, height: 40, decoration: BoxDecoration(
            color: color.withOpacity(0.12), borderRadius: BorderRadius.circular(10)),
            child: Icon(Icons.business_outlined, color: color, size: 20)),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(service.name, style: theme.textTheme.bodyLarge?.copyWith(
                fontWeight: FontWeight.w500, color: isSelected ? color : null)),
            Text('${service.currentQueue} en attente · ~${service.estimatedWait} min',
                style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.onSurface.withOpacity(0.6))),
            const SizedBox(height: 4),
            ClipRRect(borderRadius: BorderRadius.circular(3),
              child: LinearProgressIndicator(
                value: (service.estimatedWait / 30).clamp(0.0, 1.0),
                backgroundColor: theme.colorScheme.onSurface.withOpacity(0.1),
                valueColor: AlwaysStoppedAnimation<Color>(color),
                minHeight: 3,
              )),
          ])),
          if (!service.isActive)
            Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(color: Colors.grey.shade200, borderRadius: BorderRadius.circular(6)),
              child: const Text('Fermé', style: TextStyle(fontSize: 10, color: Colors.grey))),
          if (isSelected) Icon(Icons.check_circle, color: color, size: 20),
        ]),
      ),
    );
  }
}

class _PrioritySelector extends StatelessWidget {
  final int selected;
  final ValueChanged<int> onChanged;
  const _PrioritySelector({required this.selected, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    final options = [(4,'Standard',Icons.person_outline), (2,'Prioritaire',Icons.accessible_outlined), (1,'Urgence',Icons.local_hospital_outlined)];
    return Row(children: options.map((o) {
      final (value, label, icon) = o;
      final isSel = selected == value;
      final theme = Theme.of(context);
      return Expanded(child: GestureDetector(
        onTap: () => onChanged(value),
        child: Container(
          margin: const EdgeInsets.only(right: 6),
          padding: const EdgeInsets.symmetric(vertical: 10),
          decoration: BoxDecoration(
            color: isSel ? theme.colorScheme.primary.withOpacity(0.1) : Colors.transparent,
            border: Border.all(color: isSel ? theme.colorScheme.primary : theme.dividerColor, width: isSel ? 2 : 0.5),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Column(children: [
            Icon(icon, color: isSel ? theme.colorScheme.primary : Colors.grey, size: 20),
            const SizedBox(height: 4),
            Text(label, style: TextStyle(fontSize: 11,
              color: isSel ? theme.colorScheme.primary : Colors.grey,
              fontWeight: isSel ? FontWeight.w600 : FontWeight.normal)),
          ]),
        ),
      ));
    }).toList());
  }
}

class _JoinButton extends ConsumerWidget {
  final ServiceModel service;
  final int priority;
  const _JoinButton({required this.service, required this.priority});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return FilledButton.icon(
      onPressed: () async {
        try {
          const storage = FlutterSecureStorage();
          final clientId = await storage.read(key: 'client_id');
          if (clientId == null) { context.go('/login'); return; }
          final ticket = await ref.read(apiProvider).createTicket(clientId, service.id, priority);
          if (context.mounted) context.push('/ticket', extra: ticket);
        } catch (e) {
          if (context.mounted)
            ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Erreur : $e')));
        }
      },
      icon: const Icon(Icons.add),
      label: const Text("Rejoindre la file d'attente"),
      style: FilledButton.styleFrom(
        minimumSize: const Size(double.infinity, 52),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
    );
  }
}

class _QuickActions extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final actions = [
      ('Rendez-vous', Icons.calendar_today_outlined, '/appointments'),
      ('Notifications', Icons.notifications_outlined, '/notifications'),
      ('Profil', Icons.person_outline, '/profile'),
    ];
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('Accès rapide', style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w600)),
      const SizedBox(height: 10),
      Row(children: actions.map((a) {
        final (label, icon, route) = a;
        return Expanded(child: GestureDetector(
          onTap: () => context.push(route),
          child: Container(
            margin: const EdgeInsets.only(right: 8),
            padding: const EdgeInsets.symmetric(vertical: 14),
            decoration: BoxDecoration(
              color: theme.colorScheme.surface,
              border: Border.all(color: theme.dividerColor, width: 0.5),
              borderRadius: BorderRadius.circular(10)),
            child: Column(children: [
              Icon(icon, color: theme.colorScheme.primary, size: 22),
              const SizedBox(height: 5),
              Text(label, style: const TextStyle(fontSize: 11)),
            ]),
          ),
        ));
      }).toList()),
    ]);
  }
}

// ── My Ticket Screen ──────────────────────────────────────────────────────────
class MyTicketScreen extends ConsumerStatefulWidget {
  final TicketModel ticket;
  const MyTicketScreen({super.key, required this.ticket});
  @override
  ConsumerState<MyTicketScreen> createState() => _MyTicketScreenState();
}

class _MyTicketScreenState extends ConsumerState<MyTicketScreen> {
  late int _position;
  late int _estimatedWait;
  late TicketStatus _status;
  bool _isCalled = false;

  @override
  void initState() {
    super.initState();
    _position = widget.ticket.position;
    _estimatedWait = widget.ticket.estimatedWaitMinutes;
    _status = widget.ticket.status;
    _setupRealTime();
  }

  void _setupRealTime() {
    final signalR = ref.read(signalRProvider);
    signalR.onPositionUpdated((data) {
      if (data['ticketId'] == widget.ticket.id && mounted)
        setState(() {
          _position = data['newPosition'];
          _estimatedWait = data['estimatedWait'];
        });
    });
    signalR.onTicketCalled((data) {
      if (data['ticketId'] == widget.ticket.id && mounted) {
        setState(() { _status = TicketStatus.calling; _isCalled = true; });
        _showCalledDialog(data['counter'] as String);
      }
    });
    signalR.joinClientGroup(widget.ticket.clientId);
  }

  void _showCalledDialog(String counter) => showDialog(
    context: context,
    barrierDismissible: false,
    builder: (_) => AlertDialog(
      title: const Row(children: [
        Icon(Icons.notifications_active, color: Colors.orange),
        SizedBox(width: 8), Text("C'est votre tour !"),
      ]),
      content: Text('Ticket ${widget.ticket.ticketNumber} — Présentez-vous au guichet $counter.'),
      actions: [FilledButton(onPressed: () => Navigator.pop(context), child: const Text('OK'))],
    ),
  );

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isCalling = _status == TicketStatus.calling;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Mon Ticket'),
        actions: [IconButton(icon: const Icon(Icons.close), onPressed: _confirmCancel)],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(children: [
          // Hero ticket card
          AnimatedContainer(
            duration: const Duration(milliseconds: 300),
            width: double.infinity,
            padding: const EdgeInsets.all(28),
            decoration: BoxDecoration(
              color: isCalling ? Colors.orange.shade700 : theme.colorScheme.primary,
              borderRadius: BorderRadius.circular(20)),
            child: Column(children: [
              Text('Numéro de ticket',
                  style: TextStyle(color: Colors.white.withOpacity(0.8), fontSize: 13)),
              const SizedBox(height: 6),
              Text(widget.ticket.ticketNumber,
                  style: const TextStyle(color: Colors.white, fontSize: 72,
                      fontWeight: FontWeight.w500, letterSpacing: -2, height: 1)),
              const SizedBox(height: 6),
              Text('${widget.ticket.serviceName} · ${_fmt(widget.ticket.createdAt)}',
                  style: TextStyle(color: Colors.white.withOpacity(0.75), fontSize: 13)),
              if (isCalling) ...[
                const SizedBox(height: 14),
                Container(padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  decoration: BoxDecoration(color: Colors.white.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(20)),
                  child: const Text('Votre tour est arrivé !',
                      style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600))),
              ],
            ]),
          ),
          const SizedBox(height: 20),

          // Stats
          Row(children: [
            Expanded(child: _StatCard(label: 'Position', value: '#$_position',
                icon: Icons.people_outline, color: theme.colorScheme.primary)),
            const SizedBox(width: 12),
            Expanded(child: _StatCard(label: 'Attente estimée', value: '$_estimatedWait min',
                icon: Icons.access_time, color: Colors.orange)),
          ]),
          const SizedBox(height: 16),

          // Progress
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(color: theme.colorScheme.surface,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: theme.dividerColor, width: 0.5)),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Progression', style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w600)),
              const SizedBox(height: 14),
              _ProgressStep(label: 'Inscrit', done: true, active: false),
              _ProgressStep(label: 'En file d\'attente', done: true, active: _status == TicketStatus.waiting),
              _ProgressStep(label: 'Appelé au guichet', done: isCalling, active: isCalling, isLast: true),
            ]),
          ),
          const SizedBox(height: 20),

          SizedBox(width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: _confirmCancel,
              icon: const Icon(Icons.cancel_outlined, color: Colors.red),
              label: const Text('Annuler mon ticket', style: TextStyle(color: Colors.red)),
              style: OutlinedButton.styleFrom(
                side: const BorderSide(color: Colors.red),
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
            )),
        ]),
      ),
    );
  }

  void _confirmCancel() => showDialog(
    context: context,
    builder: (_) => AlertDialog(
      title: const Text('Annuler le ticket ?'),
      content: const Text("Voulez-vous vraiment quitter la file d'attente ?"),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Non')),
        FilledButton(
          style: FilledButton.styleFrom(backgroundColor: Colors.red),
          onPressed: () async {
            Navigator.pop(context);
            await ref.read(apiProvider).cancelTicket(widget.ticket.id);
            if (mounted) context.pop();
          },
          child: const Text('Oui, annuler')),
      ],
    ),
  );

  String _fmt(DateTime dt) => '${dt.hour.toString().padLeft(2,'0')}:${dt.minute.toString().padLeft(2,'0')}';
}

class _StatCard extends StatelessWidget {
  final String label, value;
  final IconData icon;
  final Color color;
  const _StatCard({required this.label, required this.value, required this.icon, required this.color});

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(color: color.withOpacity(0.08),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.2))),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Icon(icon, color: color, size: 20),
      const SizedBox(height: 8),
      Text(label, style: TextStyle(color: color.withOpacity(0.7), fontSize: 12)),
      Text(value, style: TextStyle(color: color, fontSize: 22, fontWeight: FontWeight.w500)),
    ]),
  );
}

class _ProgressStep extends StatelessWidget {
  final String label;
  final bool done, active, isLast;
  const _ProgressStep({required this.label, required this.done, required this.active, this.isLast = false});

  @override
  Widget build(BuildContext context) {
    final color = done ? Colors.green : active ? Colors.orange : Colors.grey.shade400;
    return Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Column(children: [
        Container(width: 22, height: 22, decoration: BoxDecoration(
            color: done ? Colors.green : Colors.transparent,
            border: Border.all(color: color, width: done ? 0 : 2),
            shape: BoxShape.circle),
          child: done ? const Icon(Icons.check, color: Colors.white, size: 14) : null),
        if (!isLast) Container(width: 2, height: 28, color: Colors.grey.shade300),
      ]),
      const SizedBox(width: 12),
      Padding(padding: const EdgeInsets.only(top: 2),
        child: Text(label, style: TextStyle(color: done ? Colors.green : color,
            fontWeight: active ? FontWeight.w600 : FontWeight.normal))),
    ]);
  }
}

// ── Appointments Screen ───────────────────────────────────────────────────────
class AppointmentsScreen extends ConsumerStatefulWidget {
  const AppointmentsScreen({super.key});
  @override
  ConsumerState<AppointmentsScreen> createState() => _AppointmentsScreenState();
}

class _AppointmentsScreenState extends ConsumerState<AppointmentsScreen> {
  ServiceModel? _selectedService;
  DateTime _selectedDate = DateTime.now();
  DateTime? _selectedSlot;
  List<DateTime> _slots = [];
  List<ServiceModel> _services = [];
  bool _loading = false;

  @override
  void initState() {
    super.initState();
    _loadServices();
  }

  Future<void> _loadServices() async {
    _services = await ref.read(apiProvider).getServices();
    setState(() {});
  }

  Future<void> _loadSlots() async {
    if (_selectedService == null) return;
    setState(() => _loading = true);
    _slots = await ref.read(apiProvider).getSlots(_selectedService!.id, _selectedDate);
    setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(title: const Text('Rendez-vous')),
      body: SingleChildScrollView(padding: const EdgeInsets.all(16), child: Column(children: [
        Text('Prendre un rendez-vous', style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w600)),
        const SizedBox(height: 16),

        // Service selection
        DropdownButtonFormField<ServiceModel>(
          value: _selectedService,
          decoration: const InputDecoration(labelText: 'Service'),
          items: _services.map((s) => DropdownMenuItem(value: s, child: Text(s.name))).toList(),
          onChanged: (s) { setState(() => _selectedService = s); _loadSlots(); },
        ),
        const SizedBox(height: 12),

        // Date picker
        InkWell(
          onTap: () async {
            final date = await showDatePicker(context: context,
                initialDate: _selectedDate,
                firstDate: DateTime.now(),
                lastDate: DateTime.now().add(const Duration(days: 30)));
            if (date != null) { setState(() => _selectedDate = date); _loadSlots(); }
          },
          child: Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(border: Border.all(color: theme.dividerColor, width: 0.5),
                borderRadius: BorderRadius.circular(10)),
            child: Row(children: [
              const Icon(Icons.calendar_today, size: 18),
              const SizedBox(width: 10),
              Text('${_selectedDate.day}/${_selectedDate.month}/${_selectedDate.year}'),
            ])),
        ),
        const SizedBox(height: 16),

        // Slots
        if (_loading) const CircularProgressIndicator()
        else if (_slots.isNotEmpty) ...[
          Text('Créneaux disponibles', style: theme.textTheme.titleSmall),
          const SizedBox(height: 8),
          Wrap(spacing: 8, runSpacing: 8,
            children: _slots.map((slot) {
              final isSel = _selectedSlot == slot;
              return GestureDetector(
                onTap: () => setState(() => _selectedSlot = slot),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                  decoration: BoxDecoration(
                    color: isSel ? theme.colorScheme.primary : Colors.transparent,
                    border: Border.all(color: isSel ? theme.colorScheme.primary : theme.dividerColor, width: isSel ? 2 : 0.5),
                    borderRadius: BorderRadius.circular(8)),
                  child: Text('${slot.hour.toString().padLeft(2,'0')}:${slot.minute.toString().padLeft(2,'0')}',
                    style: TextStyle(color: isSel ? Colors.white : null, fontWeight: isSel ? FontWeight.w600 : null)),
                ),
              );
            }).toList()),
        ],

        if (_selectedSlot != null) ...[
          const SizedBox(height: 20),
          FilledButton(
            onPressed: () async {
              const storage = FlutterSecureStorage();
              final clientId = await storage.read(key: 'client_id');
              if (clientId == null) return;
              try {
                await ref.read(apiProvider).createAppointment(
                    clientId, _selectedService!.id, _selectedSlot!);
                if (mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Rendez-vous confirmé ! Email envoyé.')));
                  context.pop();
                }
              } catch (e) {
                if (mounted) ScaffoldMessenger.of(context)
                    .showSnackBar(SnackBar(content: Text('Erreur : $e')));
              }
            },
            style: FilledButton.styleFrom(minimumSize: const Size(double.infinity, 52),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
            child: const Text('Confirmer le rendez-vous'),
          ),
        ],
      ])),
    );
  }
}

// Placeholder screens
class NotificationsScreen extends StatelessWidget {
  const NotificationsScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Notifications')),
    body: const Center(child: Text('Notifications')),
  );
}

class ProfileScreen extends ConsumerWidget {
  const ProfileScreen({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) => Scaffold(
    appBar: AppBar(title: const Text('Profil')),
    body: Center(child: ElevatedButton(
      onPressed: () async {
        await ref.read(authStateProvider.notifier).logout();
        if (context.mounted) context.go('/login');
      },
      child: const Text('Se déconnecter'),
    )),
  );
}

class _ErrorCard extends StatelessWidget {
  final String message;
  final VoidCallback onRetry;
  const _ErrorCard({required this.message, required this.onRetry});
  @override
  Widget build(BuildContext context) => Card(
    child: Padding(padding: const EdgeInsets.all(16), child: Column(children: [
      Text('Erreur : $message', style: const TextStyle(color: Colors.red)),
      TextButton(onPressed: onRetry, child: const Text('Réessayer')),
    ])),
  );
}
