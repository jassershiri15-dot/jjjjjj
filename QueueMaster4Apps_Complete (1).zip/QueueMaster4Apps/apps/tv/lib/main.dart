// ============================================================
// APP 3 — APPLICATION AFFICHAGE TV (salle d'attente)
// ============================================================
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../mobile/lib/shared/services/shared_services.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([DeviceOrientation.landscapeLeft]);
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  runApp(const ProviderScope(child: TvApp()));
}

class TvApp extends StatelessWidget {
  const TvApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'QueueMaster TV',
    theme: ThemeData(brightness: Brightness.dark, fontFamily: 'Inter',
        scaffoldBackgroundColor: const Color(0xFF0a0f1a)),
    home: const TvDisplayScreen(),
    debugShowCheckedModeBanner: false,
  );
}

// ── State ─────────────────────────────────────────────────────────────────────
class TvState {
  final TicketModel? currentCalling;
  final List<TicketModel> queue;
  final Map<String, QueueStatsModel> statsByService;
  final String currentTime;

  TvState({this.currentCalling, this.queue = const [],
    this.statsByService = const {}, required this.currentTime});

  TvState copyWith({TicketModel? currentCalling, bool clearCalling = false,
    List<TicketModel>? queue, Map<String, QueueStatsModel>? statsByService,
    String? currentTime}) =>
      TvState(
        currentCalling: clearCalling ? null : currentCalling ?? this.currentCalling,
        queue: queue ?? this.queue,
        statsByService: statsByService ?? this.statsByService,
        currentTime: currentTime ?? this.currentTime,
      );
}

class TvNotifier extends StateNotifier<TvState> {
  final ApiService _api;
  final SignalRService _hub;
  Timer? _clockTimer;
  Timer? _refreshTimer;

  TvNotifier(this._api, this._hub) : super(TvState(currentTime: _nowTime())) {
    _start();
  }

  static String _nowTime() {
    final n = DateTime.now();
    return '${n.hour.toString().padLeft(2,'0')}:${n.minute.toString().padLeft(2,'0')}:${n.second.toString().padLeft(2,'0')}';
  }

  Future<void> _start() async {
    // Clock
    _clockTimer = Timer.periodic(const Duration(seconds: 1),
        (_) => state = state.copyWith(currentTime: _nowTime()));

    // Load services & initial queue
    await _loadAll();
    _refreshTimer = Timer.periodic(const Duration(seconds: 30), (_) => _loadAll());

    // SignalR
    await _hub.connect();
    await _hub.joinDisplayGroup();

    _hub.onTicketCalled((data) {
      final calling = TicketModel(
        id: data['ticketId'], ticketNumber: data['ticketNumber'],
        clientId: '', clientName: '', serviceId: '',
        serviceName: data['serviceName'] ?? '',
        priority: TicketPriority.standard, status: TicketStatus.calling,
        createdAt: DateTime.now(), estimatedWaitMinutes: 0,
        position: 0, counter: data['counter'],
      );
      state = state.copyWith(currentCalling: calling);
      // Auto-clear after 30 seconds
      Future.delayed(const Duration(seconds: 30),
          () { if (mounted) state = state.copyWith(clearCalling: true); });
    });

    _hub.onStatsUpdated((stats) {
      final updated = Map<String, QueueStatsModel>.from(state.statsByService);
      updated[stats.serviceId] = stats;
      state = state.copyWith(statsByService: updated);
    });

    _hub.onNewTicket((ticket) {
      final updated = [...state.queue, ticket];
      state = state.copyWith(queue: updated);
    });
  }

  Future<void> _loadAll() async {
    final services = await _api.getServices();
    final allTickets = <TicketModel>[];
    final stats = <String, QueueStatsModel>{};

    for (final svc in services) {
      try {
        final tickets = await _api.getQueue(svc.id, status: 'waiting');
        allTickets.addAll(tickets);
        final s = await _api.getQueueStats(svc.id);
        stats[svc.id] = s;
      } catch (_) {}
    }

    state = state.copyWith(
      queue: allTickets..sort((a, b) => a.position.compareTo(b.position)),
      statsByService: stats,
    );
  }

  @override
  void dispose() {
    _clockTimer?.cancel();
    _refreshTimer?.cancel();
    _hub.disconnect();
    super.dispose();
  }
}

final tvProvider = StateNotifierProvider<TvNotifier, TvState>((ref) {
  return TvNotifier(ref.watch(apiProvider), ref.watch(signalRProvider));
});

// ── TV Display Screen ─────────────────────────────────────────────────────────
class TvDisplayScreen extends ConsumerWidget {
  const TvDisplayScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(tvProvider);
    final totalWaiting = state.statsByService.values.fold(0, (s, v) => s + v.totalWaiting);
    final totalServed = state.statsByService.values.fold(0, (s, v) => s + v.totalServedToday);
    final avgWait = state.statsByService.isEmpty ? 0.0
        : state.statsByService.values.map((s) => s.averageWaitMinutes).reduce((a, b) => a + b)
            / state.statsByService.length;

    return Scaffold(
      body: Column(children: [
        // ── Header ──────────────────────────────────────────────────────────
        _TvHeader(time: state.currentTime, totalWaiting: totalWaiting),

        // ── Body ────────────────────────────────────────────────────────────
        Expanded(child: Padding(
          padding: const EdgeInsets.all(20),
          child: Row(children: [
            // Left: Current calling + upcoming
            Expanded(flex: 5, child: Column(children: [
              // Calling card
              _CallingCard(ticket: state.currentCalling),
              const SizedBox(height: 16),
              // Next 2 tickets
              Row(children: [
                Expanded(child: _NextCard(
                  label: 'Prochain',
                  ticket: state.queue.where((t) => t.status == TicketStatus.waiting).skip(0).firstOrNull,
                )),
                const SizedBox(width: 12),
                Expanded(child: _NextCard(
                  label: 'Après',
                  ticket: state.queue.where((t) => t.status == TicketStatus.waiting).skip(1).firstOrNull,
                )),
              ]),
            ])),

            const SizedBox(width: 20),

            // Right: Queue list
            Expanded(flex: 3, child: _QueueList(queue: state.queue)),
          ]),
        )),

        // ── Stats Bar ────────────────────────────────────────────────────────
        _StatsBar(waiting: totalWaiting, served: totalServed, avgWait: avgWait.round()),

        // ── Ticker ───────────────────────────────────────────────────────────
        const _Ticker(),
      ]),
    );
  }
}

class _TvHeader extends StatelessWidget {
  final String time;
  final int totalWaiting;
  const _TvHeader({required this.time, required this.totalWaiting});

  @override
  Widget build(BuildContext context) => Container(
    color: const Color(0xFF0d1525),
    padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 14),
    child: Row(children: [
      Container(width: 40, height: 40,
        decoration: BoxDecoration(color: const Color(0xFF1E3A5F), borderRadius: BorderRadius.circular(10)),
        child: const Icon(Icons.queue, color: Colors.white, size: 22)),
      const SizedBox(width: 14),
      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('QUEUEMASTER PRO', style: TextStyle(color: Colors.white,
            fontSize: 16, fontWeight: FontWeight.w600, letterSpacing: 1.5)),
        Text('Salle d\'attente · $totalWaiting client(s) en file',
            style: const TextStyle(color: Color(0xFF6b9fd4), fontSize: 12)),
      ]),
      const Spacer(),
      Container(padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
        decoration: BoxDecoration(color: const Color(0xFF1a2535), borderRadius: BorderRadius.circular(8)),
        child: Text(time, style: const TextStyle(color: Color(0xFF6b9fd4),
            fontSize: 22, fontWeight: FontWeight.w500, fontFeatures: [FontFeature.tabularFigures()]))),
    ]),
  );
}

class _CallingCard extends StatefulWidget {
  final TicketModel? ticket;
  const _CallingCard({this.ticket});
  @override
  State<_CallingCard> createState() => _CallingCardState();
}

class _CallingCardState extends State<_CallingCard> with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _anim;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1200))
      ..repeat(reverse: true);
    _anim = Tween<double>(begin: 0.85, end: 1.0).animate(
        CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut));
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final ticket = widget.ticket;
    return Expanded(child: AnimatedBuilder(
      animation: _anim,
      builder: (_, __) => Transform.scale(
        scale: ticket != null ? _anim.value : 1.0,
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: ticket != null ? const Color(0xFF1a2d1a) : const Color(0xFF0d1525),
            border: Border.all(
              color: ticket != null ? const Color(0xFF2d8b2d) : const Color(0xFF1a2535),
              width: ticket != null ? 2 : 0.5),
            borderRadius: BorderRadius.circular(16)),
          child: ticket != null ? Column(children: [
            const Text('TICKET APPELÉ', style: TextStyle(color: Color(0xFF6bbd6b),
                fontSize: 12, fontWeight: FontWeight.w600, letterSpacing: 2)),
            const SizedBox(height: 10),
            Text(ticket.ticketNumber, style: const TextStyle(color: Colors.white,
                fontSize: 80, fontWeight: FontWeight.w700, letterSpacing: -2, height: 1)),
            const SizedBox(height: 8),
            Text('Guichet ${ticket.counter ?? '-'}',
                style: const TextStyle(color: Color(0xFF6bbd6b), fontSize: 22, fontWeight: FontWeight.w500)),
            if (ticket.serviceName.isNotEmpty)
              Text(ticket.serviceName,
                  style: const TextStyle(color: Color(0xFF4a6a8a), fontSize: 14)),
          ]) : Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            const Icon(Icons.queue, color: Color(0xFF1a2535), size: 64),
            const SizedBox(height: 12),
            const Text('En attente d\'appel', style: TextStyle(color: Color(0xFF3a4a5a), fontSize: 16)),
          ]),
        ),
      ),
    ));
  }
}

class _NextCard extends StatelessWidget {
  final String label;
  final TicketModel? ticket;
  const _NextCard({required this.label, this.ticket});

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(color: const Color(0xFF0d1525),
        border: Border.all(color: const Color(0xFF1a2535), width: 0.5),
        borderRadius: BorderRadius.circular(12)),
    child: Column(children: [
      Text(label, style: const TextStyle(color: Color(0xFF4a6a8a), fontSize: 11,
          letterSpacing: 1, fontWeight: FontWeight.w500)),
      const SizedBox(height: 6),
      Text(ticket?.ticketNumber ?? '—',
          style: TextStyle(color: ticket != null ? Colors.white : const Color(0xFF2a3a4a),
              fontSize: 32, fontWeight: FontWeight.w600)),
      if (ticket != null)
        Text(ticket!.serviceName,
            style: const TextStyle(color: Color(0xFF4a6a8a), fontSize: 11)),
    ]),
  );
}

class _QueueList extends StatelessWidget {
  final List<TicketModel> queue;
  const _QueueList({required this.queue});

  @override
  Widget build(BuildContext context) {
    final waiting = queue.where((t) => t.status == TicketStatus.waiting).take(8).toList();
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: const Color(0xFF0d1525),
          border: Border.all(color: const Color(0xFF1a2535), width: 0.5),
          borderRadius: BorderRadius.circular(14)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('FILE D\'ATTENTE', style: TextStyle(color: Color(0xFF6b9fd4),
            fontSize: 11, fontWeight: FontWeight.w600, letterSpacing: 1.5)),
        const SizedBox(height: 12),
        ...waiting.map((t) => _QueueRow(ticket: t, position: waiting.indexOf(t) + 1)),
        if (waiting.isEmpty)
          const Center(child: Padding(padding: EdgeInsets.all(20),
              child: Text('Aucun client en attente',
                  style: TextStyle(color: Color(0xFF2a3a4a), fontSize: 14)))),
      ]),
    );
  }
}

class _QueueRow extends StatelessWidget {
  final TicketModel ticket;
  final int position;
  const _QueueRow({required this.ticket, required this.position});

  @override
  Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.only(bottom: 8),
    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
    decoration: BoxDecoration(color: const Color(0xFF111b2b),
        borderRadius: BorderRadius.circular(8)),
    child: Row(children: [
      Text(ticket.ticketNumber, style: const TextStyle(color: Colors.white,
          fontSize: 16, fontWeight: FontWeight.w500)),
      const SizedBox(width: 10),
      Expanded(child: Text(ticket.serviceName,
          style: const TextStyle(color: Color(0xFF4a6a8a), fontSize: 12),
          overflow: TextOverflow.ellipsis)),
      Text('~${ticket.estimatedWaitMinutes}min',
          style: const TextStyle(color: Color(0xFF6b9fd4), fontSize: 12)),
    ]),
  );
}

class _StatsBar extends StatelessWidget {
  final int waiting, served, avgWait;
  const _StatsBar({required this.waiting, required this.served, required this.avgWait});

  @override
  Widget build(BuildContext context) => Container(
    color: const Color(0xFF0d1525),
    padding: const EdgeInsets.symmetric(vertical: 10),
    child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
      _StatItem(label: 'EN ATTENTE', value: '$waiting', color: const Color(0xFF6b9fd4)),
      _StatItem(label: 'SERVIS AUJOURD\'HUI', value: '$served', color: const Color(0xFF6bbd6b)),
      _StatItem(label: 'ATTENTE MOYENNE', value: '$avgWait min', color: const Color(0xFFEF9F27)),
    ]),
  );
}

class _StatItem extends StatelessWidget {
  final String label, value;
  final Color color;
  const _StatItem({required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) => Column(children: [
    Text(value, style: TextStyle(color: color, fontSize: 28, fontWeight: FontWeight.w600)),
    Text(label, style: const TextStyle(color: Color(0xFF3a4a5a), fontSize: 10, letterSpacing: 1)),
  ]);
}

class _Ticker extends StatefulWidget {
  const _Ticker();
  @override
  State<_Ticker> createState() => _TickerState();
}

class _TickerState extends State<_Ticker> with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _anim;
  final _messages = [
    'Bienvenue — Prenez votre ticket à l\'accueil ou sur l\'application mobile QueueMaster Pro',
    'Votre satisfaction est notre priorité — Merci de votre patience',
    'Pour tout renseignement, adressez-vous à l\'accueil',
  ];
  int _msgIdx = 0;
  Timer? _msgTimer;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(seconds: 15))..repeat();
    _anim = Tween<double>(begin: 1.0, end: -0.1).animate(_ctrl);
    _msgTimer = Timer.periodic(const Duration(seconds: 15),
        (_) => setState(() => _msgIdx = (_msgIdx + 1) % _messages.length));
  }

  @override
  void dispose() { _ctrl.dispose(); _msgTimer?.cancel(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Container(
    color: const Color(0xFF061020),
    padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 20),
    child: Row(children: [
      Container(margin: const EdgeInsets.only(right: 12),
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
        decoration: BoxDecoration(color: const Color(0xFF1E3A5F), borderRadius: BorderRadius.circular(4)),
        child: const Text('INFO', style: TextStyle(color: Colors.white, fontSize: 10,
            fontWeight: FontWeight.w600, letterSpacing: 1))),
      Expanded(child: ClipRect(child: AnimatedBuilder(
        animation: _anim,
        builder: (_, child) => FractionalTranslation(translation: Offset(_anim.value, 0), child: child),
        child: Text(_messages[_msgIdx],
            style: const TextStyle(color: Color(0xFF4a6a8a), fontSize: 13),
            maxLines: 1, overflow: TextOverflow.visible),
      ))),
    ]),
  );
}
