// ============================================================
// APP 4 — APPLICATION ADMINISTRATION (Web / Desktop)
// ============================================================
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../mobile/lib/shared/services/shared_services.dart';

void main() => runApp(const ProviderScope(child: AdminApp()));

class AdminApp extends StatelessWidget {
  const AdminApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp.router(
    title: 'QueueMaster Admin',
    theme: ThemeData(useMaterial3: true, fontFamily: 'Inter',
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF1E3A5F))),
    darkTheme: ThemeData(useMaterial3: true, fontFamily: 'Inter', brightness: Brightness.dark,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF4A90D9), brightness: Brightness.dark)),
    themeMode: ThemeMode.system,
    routerConfig: GoRouter(initialLocation: '/dashboard', routes: [
      ShellRoute(builder: (_, __, child) => AdminShell(child: child), routes: [
        GoRoute(path: '/dashboard', builder: (_, __) => const DashboardScreen()),
        GoRoute(path: '/queue', builder: (_, __) => const QueueScreen()),
        GoRoute(path: '/agents', builder: (_, __) => const AgentsScreen()),
        GoRoute(path: '/appointments', builder: (_, __) => const AdminAppointmentsScreen()),
        GoRoute(path: '/reports', builder: (_, __) => const ReportsScreen()),
      ]),
    ]),
    debugShowCheckedModeBanner: false,
  );
}

// ── Admin Shell (sidebar layout) ─────────────────────────────────────────────
class AdminShell extends StatelessWidget {
  final Widget child;
  const AdminShell({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final location = GoRouterState.of(context).matchedLocation;

    return Scaffold(
      body: Row(children: [
        // Sidebar
        Container(width: 220,
          decoration: BoxDecoration(color: const Color(0xFF1E3A5F),
              border: Border(right: BorderSide(color: theme.dividerColor, width: 0.5))),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            // Logo
            Padding(padding: const EdgeInsets.all(20), child: Column(
              crossAxisAlignment: CrossAxisAlignment.start, children: [
              const SizedBox(height: 12),
              const Text('QueueMaster', style: TextStyle(color: Colors.white,
                  fontSize: 17, fontWeight: FontWeight.w600)),
              const Text('Administration', style: TextStyle(color: Color(0xFF6b9fd4), fontSize: 12)),
            ])),
            const Divider(color: Color(0xFF2a4a6a), height: 1),
            const SizedBox(height: 8),
            ..._navItems.map((item) => _NavItem(
              icon: item.$1, label: item.$2, route: item.$3,
              isActive: location == item.$3,
            )),
            const Spacer(),
            Padding(padding: const EdgeInsets.all(16),
              child: Text('v1.0.0', style: const TextStyle(color: Color(0xFF3a5a7a), fontSize: 11))),
          ]),
        ),
        // Content
        Expanded(child: child),
      ]),
    );
  }

  static const _navItems = [
    (Icons.dashboard_outlined, 'Tableau de bord', '/dashboard'),
    (Icons.queue_outlined, 'File d\'attente', '/queue'),
    (Icons.people_outline, 'Agents', '/agents'),
    (Icons.calendar_today_outlined, 'Rendez-vous', '/appointments'),
    (Icons.bar_chart_outlined, 'Rapports', '/reports'),
  ];
}

class _NavItem extends StatelessWidget {
  final IconData icon;
  final String label, route;
  final bool isActive;
  const _NavItem({required this.icon, required this.label, required this.route, required this.isActive});

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: () => context.go(route),
    child: Container(
      margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 2),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: isActive ? const Color(0xFF2E75B6).withOpacity(0.3) : Colors.transparent,
        borderRadius: BorderRadius.circular(8),
        border: isActive ? Border.all(color: const Color(0xFF2E75B6).withOpacity(0.5), width: 0.5) : null,
      ),
      child: Row(children: [
        Icon(icon, color: isActive ? Colors.white : const Color(0xFF6b9fd4), size: 18),
        const SizedBox(width: 10),
        Text(label, style: TextStyle(color: isActive ? Colors.white : const Color(0xFF6b9fd4), fontSize: 13,
            fontWeight: isActive ? FontWeight.w500 : FontWeight.normal)),
      ]),
    ),
  );
}

// ── Dashboard State ───────────────────────────────────────────────────────────
class DashboardState {
  final List<QueueStatsModel> stats;
  final List<TicketModel> recentTickets;
  final List<Map<String, dynamic>> hourlyData;
  final bool isLoading;

  DashboardState({this.stats = const [], this.recentTickets = const [],
    this.hourlyData = const [], this.isLoading = true});

  DashboardState copyWith({List<QueueStatsModel>? stats, List<TicketModel>? recentTickets,
    List<Map<String, dynamic>>? hourlyData, bool? isLoading}) =>
      DashboardState(
        stats: stats ?? this.stats, recentTickets: recentTickets ?? this.recentTickets,
        hourlyData: hourlyData ?? this.hourlyData, isLoading: isLoading ?? this.isLoading,
      );

  int get totalWaiting => stats.fold(0, (s, v) => s + v.totalWaiting);
  int get totalServed => stats.fold(0, (s, v) => s + v.totalServedToday);
  int get totalAgents => stats.fold(0, (s, v) => s + v.activeAgents);
  double get avgWait => stats.isEmpty ? 0
      : stats.map((s) => s.averageWaitMinutes).reduce((a, b) => a + b) / stats.length;
}

class DashboardNotifier extends StateNotifier<DashboardState> {
  final ApiService _api;
  final SignalRService _hub;
  Timer? _refreshTimer;

  DashboardNotifier(this._api, this._hub) : super(DashboardState()) { _init(); }

  Future<void> _init() async {
    await _hub.connect();
    await _hub.joinAdminGroup();
    _hub.onStatsUpdated((_) => refresh());
    _hub.onNewTicket((_) => refresh());
    await refresh();
    _refreshTimer = Timer.periodic(const Duration(seconds: 30), (_) => refresh());
  }

  Future<void> refresh() async {
    final services = await _api.getServices();
    final statsList = <QueueStatsModel>[];
    final allTickets = <TicketModel>[];

    for (final svc in services) {
      try {
        final s = await _api.getQueueStats(svc.id);
        statsList.add(s);
        final tickets = await _api.getQueue(svc.id);
        allTickets.addAll(tickets.take(5));
      } catch (_) {}
    }

    // Mock hourly data (replace with real API call)
    final hourly = List.generate(8, (i) => {
      'hour': '${8 + i}h',
      'count': [5, 12, 18, 22, 15, 8, 11, 7][i],
    });

    state = state.copyWith(
      stats: statsList,
      recentTickets: allTickets..sort((a, b) => b.createdAt.compareTo(a.createdAt)),
      hourlyData: hourly,
      isLoading: false,
    );
  }

  @override
  void dispose() { _refreshTimer?.cancel(); _hub.disconnect(); super.dispose(); }
}

final dashboardProvider = StateNotifierProvider<DashboardNotifier, DashboardState>((ref) {
  return DashboardNotifier(ref.watch(apiProvider), ref.watch(signalRProvider));
});

// ── Dashboard Screen ──────────────────────────────────────────────────────────
class DashboardScreen extends ConsumerWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(dashboardProvider);
    final theme = Theme.of(context);

    return Scaffold(
      body: state.isLoading
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                // Header
                Row(children: [
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('Tableau de bord', style: theme.textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w600)),
                    Text('Mis à jour en temps réel · ${DateTime.now().day}/${DateTime.now().month}/${DateTime.now().year}',
                        style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.onSurface.withOpacity(0.5))),
                  ])),
                  _LivePill(),
                  const SizedBox(width: 12),
                  FilledButton.icon(
                    onPressed: () => ref.read(dashboardProvider.notifier).refresh(),
                    icon: const Icon(Icons.refresh, size: 16),
                    label: const Text('Actualiser'),
                    style: FilledButton.styleFrom(
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8))),
                  ),
                ]),
                const SizedBox(height: 24),

                // KPI Cards
                Row(children: [
                  _KpiCard(label: 'En file', value: '${state.totalWaiting}',
                      sub: 'Actif', subColor: Colors.green, icon: Icons.queue),
                  const SizedBox(width: 12),
                  _KpiCard(label: 'Servis aujourd\'hui', value: '${state.totalServed}',
                      sub: '+4 vs hier', subColor: Colors.green, icon: Icons.check_circle_outline),
                  const SizedBox(width: 12),
                  _KpiCard(label: 'Attente moyenne', value: '${state.avgWait.round()} min',
                      sub: 'SLA : 15 min', subColor: Colors.orange, icon: Icons.access_time),
                  const SizedBox(width: 12),
                  _KpiCard(label: 'Agents actifs', value: '${state.totalAgents}',
                      sub: 'sur ${state.stats.length * 3}', subColor: Colors.blue, icon: Icons.people_outline),
                ]),
                const SizedBox(height: 20),

                // Charts row
                Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Expanded(flex: 3, child: _TicketsChart(hourlyData: state.hourlyData)),
                  const SizedBox(width: 16),
                  Expanded(flex: 2, child: _ServiceStats(stats: state.stats)),
                ]),
                const SizedBox(height: 20),

                // Recent tickets
                _RecentTickets(tickets: state.recentTickets),
              ]),
            ),
    );
  }
}

class _LivePill extends StatefulWidget {
  @override
  State<_LivePill> createState() => _LivePillState();
}

class _LivePillState extends State<_LivePill> with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  @override
  void initState() { super.initState(); _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1200))..repeat(reverse: true); }
  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
    decoration: BoxDecoration(color: Colors.green.withOpacity(0.1),
        border: Border.all(color: Colors.green.withOpacity(0.3)), borderRadius: BorderRadius.circular(20)),
    child: Row(mainAxisSize: MainAxisSize.min, children: [
      AnimatedBuilder(animation: _ctrl,
        builder: (_, __) => Container(width: 7, height: 7,
          decoration: BoxDecoration(shape: BoxShape.circle,
              color: Colors.green.withOpacity(0.4 + _ctrl.value * 0.6)))),
      const SizedBox(width: 6),
      const Text('Temps réel', style: TextStyle(color: Colors.green, fontSize: 12, fontWeight: FontWeight.w500)),
    ]),
  );
}

class _KpiCard extends StatelessWidget {
  final String label, value, sub;
  final Color subColor;
  final IconData icon;
  const _KpiCard({required this.label, required this.value, required this.sub,
    required this.subColor, required this.icon});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Expanded(child: Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: theme.colorScheme.surface,
          border: Border.all(color: theme.dividerColor, width: 0.5),
          borderRadius: BorderRadius.circular(12)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Icon(icon, color: theme.colorScheme.primary.withOpacity(0.6), size: 18),
          const Spacer(),
        ]),
        const SizedBox(height: 12),
        Text(label, style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.onSurface.withOpacity(0.5))),
        const SizedBox(height: 4),
        Text(value, style: theme.textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.w600)),
        const SizedBox(height: 4),
        Text(sub, style: TextStyle(color: subColor, fontSize: 12)),
      ]),
    ));
  }
}

class _TicketsChart extends StatelessWidget {
  final List<Map<String, dynamic>> hourlyData;
  const _TicketsChart({required this.hourlyData});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final maxVal = hourlyData.isEmpty ? 1 : hourlyData.map((d) => d['count'] as int).reduce((a, b) => a > b ? a : b);

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: theme.colorScheme.surface,
          border: Border.all(color: theme.dividerColor, width: 0.5),
          borderRadius: BorderRadius.circular(12)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Tickets traités par heure', style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w600)),
        const SizedBox(height: 16),
        SizedBox(height: 120, child: Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: hourlyData.map((d) {
            final count = d['count'] as int;
            final frac = count / maxVal;
            return Expanded(child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 3),
              child: Column(mainAxisAlignment: MainAxisAlignment.end, children: [
                Text('$count', style: theme.textTheme.bodySmall?.copyWith(
                    color: theme.colorScheme.onSurface.withOpacity(0.5))),
                const SizedBox(height: 4),
                ClipRRect(borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(4), topRight: Radius.circular(4)),
                  child: AnimatedContainer(duration: const Duration(milliseconds: 600),
                    height: frac * 80,
                    color: theme.colorScheme.primary.withOpacity(0.3 + frac * 0.7))),
                const SizedBox(height: 6),
                Text(d['hour'] as String, style: theme.textTheme.bodySmall?.copyWith(
                    color: theme.colorScheme.onSurface.withOpacity(0.4), fontSize: 10)),
              ]),
            ));
          }).toList(),
        )),
      ]),
    );
  }
}

class _ServiceStats extends StatelessWidget {
  final List<QueueStatsModel> stats;
  const _ServiceStats({required this.stats});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: theme.colorScheme.surface,
          border: Border.all(color: theme.dividerColor, width: 0.5),
          borderRadius: BorderRadius.circular(12)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Par service', style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w600)),
        const SizedBox(height: 14),
        ...stats.map((s) {
          final pct = s.totalWaiting / 30;
          return Padding(padding: const EdgeInsets.only(bottom: 14), child: Column(children: [
            Row(children: [
              Expanded(child: Text(s.serviceName, style: theme.textTheme.bodySmall?.copyWith(fontWeight: FontWeight.w500))),
              Text('${s.totalWaiting} / 30', style: theme.textTheme.bodySmall?.copyWith(
                  color: theme.colorScheme.onSurface.withOpacity(0.5))),
            ]),
            const SizedBox(height: 6),
            ClipRRect(borderRadius: BorderRadius.circular(4),
              child: LinearProgressIndicator(value: pct.clamp(0.0, 1.0), minHeight: 6,
                  backgroundColor: theme.colorScheme.onSurface.withOpacity(0.1),
                  valueColor: AlwaysStoppedAnimation<Color>(
                      pct > 0.8 ? Colors.red : pct > 0.5 ? Colors.orange : Colors.green))),
            const SizedBox(height: 4),
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Text('${s.activeAgents} agent(s) actif(s)', style: TextStyle(fontSize: 11,
                  color: theme.colorScheme.onSurface.withOpacity(0.4))),
              Text('moy. ${s.averageWaitMinutes.round()} min', style: TextStyle(fontSize: 11,
                  color: theme.colorScheme.onSurface.withOpacity(0.4))),
            ]),
          ]));
        }),
      ]),
    );
  }
}

class _RecentTickets extends StatelessWidget {
  final List<TicketModel> tickets;
  const _RecentTickets({required this.tickets});

  static const _statusLabel = {TicketStatus.waiting: 'En attente', TicketStatus.calling: 'Appelé',
    TicketStatus.served: 'Servi', TicketStatus.cancelled: 'Annulé', TicketStatus.noShow: 'Absent'};
  static const _statusColor = {TicketStatus.waiting: Colors.blue, TicketStatus.calling: Colors.orange,
    TicketStatus.served: Colors.green, TicketStatus.cancelled: Colors.grey, TicketStatus.noShow: Colors.red};
  static const _priorityLabel = {TicketPriority.emergency: 'Urgence', TicketPriority.priority: 'Prioritaire',
    TicketPriority.vip: 'VIP', TicketPriority.standard: 'Standard'};

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: theme.colorScheme.surface,
          border: Border.all(color: theme.dividerColor, width: 0.5),
          borderRadius: BorderRadius.circular(12)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Tickets récents', style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w600)),
        const SizedBox(height: 12),
        Table(
          columnWidths: const {0: FlexColumnWidth(1), 1: FlexColumnWidth(2), 2: FlexColumnWidth(2), 3: FlexColumnWidth(1.5), 4: FlexColumnWidth(1.5)},
          children: [
            TableRow(children: ['Ticket', 'Client', 'Service', 'Priorité', 'Statut'].map((h) =>
              Padding(padding: const EdgeInsets.only(bottom: 10),
                child: Text(h, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w500,
                    color: theme.colorScheme.onSurface.withOpacity(0.4))))).toList()),
            ...tickets.take(10).map((t) => TableRow(children: [
              _Cell(text: t.ticketNumber, bold: true),
              _Cell(text: t.clientName.isEmpty ? 'N/A' : t.clientName),
              _Cell(text: t.serviceName),
              _BadgeCell(label: _priorityLabel[t.priority] ?? '', color: _priorityColor(t.priority)),
              _BadgeCell(label: _statusLabel[t.status] ?? '', color: _statusColor[t.status] ?? Colors.grey),
            ])),
          ],
        ),
        if (tickets.isEmpty) const Center(child: Padding(padding: EdgeInsets.all(24),
            child: Text('Aucun ticket récent'))),
      ]),
    );
  }

  Color _priorityColor(TicketPriority p) {
    switch (p) {
      case TicketPriority.emergency: return Colors.red;
      case TicketPriority.priority: return Colors.orange;
      case TicketPriority.vip: return Colors.purple;
      default: return Colors.grey;
    }
  }
}

class _Cell extends StatelessWidget {
  final String text;
  final bool bold;
  const _Cell({required this.text, this.bold = false});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 8),
    child: Text(text, style: TextStyle(fontSize: 13, fontWeight: bold ? FontWeight.w500 : FontWeight.normal),
        overflow: TextOverflow.ellipsis));
}

class _BadgeCell extends StatelessWidget {
  final String label;
  final Color color;
  const _BadgeCell({required this.label, required this.color});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 6),
    child: Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(6)),
      child: Text(label, style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.w500))));
}

// ── Queue Screen ──────────────────────────────────────────────────────────────
class QueueScreen extends ConsumerStatefulWidget {
  const QueueScreen({super.key});
  @override
  ConsumerState<QueueScreen> createState() => _QueueScreenState();
}

class _QueueScreenState extends ConsumerState<QueueScreen> {
  List<ServiceModel> _services = [];
  ServiceModel? _selectedService;
  List<TicketModel> _tickets = [];
  bool _loading = false;

  @override
  void initState() { super.initState(); _loadServices(); }

  Future<void> _loadServices() async {
    _services = await ref.read(apiProvider).getServices();
    if (_services.isNotEmpty) { _selectedService = _services.first; _loadQueue(); }
    setState(() {});
  }

  Future<void> _loadQueue() async {
    if (_selectedService == null) return;
    setState(() => _loading = true);
    _tickets = await ref.read(apiProvider).getQueue(_selectedService!.id);
    setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      body: Padding(padding: const EdgeInsets.all(24), child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            Text('Supervision de la file', style: theme.textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w600)),
            const Spacer(),
            DropdownButton<ServiceModel>(
              value: _selectedService,
              items: _services.map((s) => DropdownMenuItem(value: s, child: Text(s.name))).toList(),
              onChanged: (s) { setState(() => _selectedService = s); _loadQueue(); },
            ),
            const SizedBox(width: 12),
            FilledButton.icon(onPressed: _loadQueue, icon: const Icon(Icons.refresh, size: 16),
                label: const Text('Actualiser')),
          ]),
          const SizedBox(height: 20),
          if (_loading) const LinearProgressIndicator()
          else Expanded(child: ListView.separated(
            itemCount: _tickets.length,
            separatorBuilder: (_, __) => const Divider(height: 1),
            itemBuilder: (_, i) {
              final t = _tickets[i];
              return ListTile(
                leading: _TicketAvatar(number: t.ticketNumber, status: t.status),
                title: Text(t.clientName.isEmpty ? 'N/A' : t.clientName,
                    style: const TextStyle(fontWeight: FontWeight.w500)),
                subtitle: Text('${t.serviceName} · ${t.createdAt.hour}:${t.createdAt.minute.toString().padLeft(2,'0')} · ~${t.estimatedWaitMinutes} min'),
                trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                  _StatusBadge(status: t.status),
                  const SizedBox(width: 8),
                  IconButton(icon: const Icon(Icons.arrow_upward, size: 18), onPressed: () async {
                    // Boost priority via API
                    await _loadQueue();
                  }),
                  IconButton(icon: const Icon(Icons.close, size: 18, color: Colors.red), onPressed: () async {
                    await ref.read(apiProvider).cancelTicket(t.id);
                    await _loadQueue();
                  }),
                ]),
              );
            },
          )),
        ],
      )),
    );
  }
}

class _TicketAvatar extends StatelessWidget {
  final String number;
  final TicketStatus status;
  const _TicketAvatar({required this.number, required this.status});

  @override
  Widget build(BuildContext context) {
    final color = status == TicketStatus.calling ? Colors.orange
        : status == TicketStatus.waiting ? Colors.blue : Colors.green;
    return Container(width: 44, height: 44, decoration: BoxDecoration(
        color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(10)),
      child: Center(child: Text(number, style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w600))));
  }
}

class _StatusBadge extends StatelessWidget {
  final TicketStatus status;
  const _StatusBadge({required this.status});

  @override
  Widget build(BuildContext context) {
    final (label, color) = switch (status) {
      TicketStatus.waiting => ('En attente', Colors.blue),
      TicketStatus.calling => ('Appelé', Colors.orange),
      TicketStatus.served  => ('Servi', Colors.green),
      _                    => ('Annulé', Colors.grey),
    };
    return Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(8)),
      child: Text(label, style: TextStyle(color: color, fontSize: 12)));
  }
}

// ── Agents Screen ─────────────────────────────────────────────────────────────
class AgentsScreen extends ConsumerStatefulWidget {
  const AgentsScreen({super.key});
  @override
  ConsumerState<AgentsScreen> createState() => _AgentsScreenState();
}

class _AgentsScreenState extends ConsumerState<AgentsScreen> {
  List<AgentDto>? _agents;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    // Real API call would go here
    setState(() => _agents = [
      AgentDto('1', 'Ahmed Salhi', 'G1', AgentStatus.active, 12),
      AgentDto('2', 'Rim Jebali', 'G2', AgentStatus.active, 9),
      AgentDto('3', 'Nour Ferchichi', 'G3', AgentStatus.onBreak, 7),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(body: Padding(padding: const EdgeInsets.all(24), child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Gestion des agents', style: theme.textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w600)),
        const SizedBox(height: 20),
        if (_agents == null) const CircularProgressIndicator()
        else GridView.builder(
          shrinkWrap: true,
          gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
              maxCrossAxisExtent: 280, childAspectRatio: 1.4, crossAxisSpacing: 12, mainAxisSpacing: 12),
          itemCount: _agents!.length,
          itemBuilder: (_, i) {
            final a = _agents![i];
            final isActive = a.status == AgentStatus.active;
            return Container(padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(color: theme.colorScheme.surface,
                  border: Border.all(color: theme.dividerColor, width: 0.5),
                  borderRadius: BorderRadius.circular(12)),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  CircleAvatar(backgroundColor: theme.colorScheme.primary.withOpacity(0.15), radius: 22,
                    child: Text(a.name.substring(0, 1), style: TextStyle(color: theme.colorScheme.primary, fontSize: 18))),
                  const Spacer(),
                  Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(color: isActive ? Colors.green.withOpacity(0.1) : Colors.orange.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(8)),
                    child: Text(isActive ? 'Actif' : 'Pause',
                        style: TextStyle(color: isActive ? Colors.green : Colors.orange, fontSize: 11))),
                ]),
                const SizedBox(height: 10),
                Text(a.name, style: const TextStyle(fontWeight: FontWeight.w600)),
                Text('Guichet ${a.counter}', style: TextStyle(color: theme.colorScheme.onSurface.withOpacity(0.5), fontSize: 13)),
                const Spacer(),
                Row(children: [
                  Icon(Icons.check_circle_outline, size: 14, color: Colors.green.withOpacity(0.7)),
                  const SizedBox(width: 4),
                  Text('${a.servedToday} servis', style: const TextStyle(fontSize: 12)),
                  const Spacer(),
                  TextButton(onPressed: () => _load(),
                      child: Text(isActive ? 'Pause' : 'Reprendre')),
                ]),
              ]));
          },
        ),
      ],
    )));
  }
}

class AgentDto {
  final String id, name, counter;
  final AgentStatus status;
  final int servedToday;
  AgentDto(this.id, this.name, this.counter, this.status, this.servedToday);
}

// Placeholder screens
class AdminAppointmentsScreen extends StatelessWidget {
  const AdminAppointmentsScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    body: Padding(padding: const EdgeInsets.all(24),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Rendez-vous', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w600)),
        const SizedBox(height: 20),
        const Center(child: Text('Liste des rendez-vous — À connecter à l\'API')),
      ])));
}

class ReportsScreen extends StatelessWidget {
  const ReportsScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    body: Padding(padding: const EdgeInsets.all(24),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Rapports', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w600)),
        const SizedBox(height: 20),
        Row(children: [
          Expanded(child: _ReportCard(title: 'Rapport journalier', sub: 'PDF · Excel', icon: Icons.today_outlined)),
          const SizedBox(width: 12),
          Expanded(child: _ReportCard(title: 'Rapport hebdomadaire', sub: 'PDF · Excel', icon: Icons.date_range_outlined)),
          const SizedBox(width: 12),
          Expanded(child: _ReportCard(title: 'Rapport mensuel', sub: 'PDF · Excel', icon: Icons.calendar_month_outlined)),
        ]),
      ])));
}

class _ReportCard extends StatelessWidget {
  final String title, sub;
  final IconData icon;
  const _ReportCard({required this.title, required this.sub, required this.icon});
  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(color: theme.colorScheme.surface,
          border: Border.all(color: theme.dividerColor, width: 0.5),
          borderRadius: BorderRadius.circular(12)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Icon(icon, color: theme.colorScheme.primary, size: 28),
        const SizedBox(height: 12),
        Text(title, style: const TextStyle(fontWeight: FontWeight.w500)),
        Text(sub, style: TextStyle(color: theme.colorScheme.onSurface.withOpacity(0.4), fontSize: 12)),
        const SizedBox(height: 16),
        OutlinedButton(onPressed: () {}, child: const Text('Exporter')),
      ]));
  }
}

enum AgentStatus { offline, active, onBreak, busy }
