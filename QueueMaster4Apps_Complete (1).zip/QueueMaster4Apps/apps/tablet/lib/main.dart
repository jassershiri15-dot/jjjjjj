// ============================================================
// APP 2 — TABLETTE KIOSQUE CLIENT
// Posée en salle d'attente — remplace l'absence de smartphone
// Parcours : Accueil → Service → Priorité+SMS → Ticket+Impression
// ============================================================

import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:http/http.dart' as http;
import 'package:qr_flutter/qr_flutter.dart';
import 'package:wakelock_plus/wakelock_plus.dart';
import '../mobile/lib/shared/services/shared_services.dart';

// ─── Entry point ─────────────────────────────────────────────────────────────

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.landscapeLeft,
    DeviceOrientation.landscapeRight,
  ]);
  await SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  await WakelockPlus.enable();
  runApp(const ProviderScope(child: TabletKioskApp()));
}

// ─── Constants ────────────────────────────────────────────────────────────────

const _kPrimary   = Color(0xFF1E3A5F);
const _kAccent    = Color(0xFF1D9E75);
const _kWarning   = Color(0xFFBA7517);
const _kDanger    = Color(0xFFE24B4A);
const _kSurface   = Color(0xFFF8FAFC);
const _kBorder    = Color(0xFFE2E8F0);
const _kText      = Color(0xFF1E293B);
const _kMuted     = Color(0xFF94A3B8);
const _kCompany   = 'Mon Entreprise';
const _kIdleTime  = Duration(seconds: 60);

// ─── Ticket args ──────────────────────────────────────────────────────────────

class _TicketArgs {
  final TicketModel ticket;
  final ServiceModel service;
  final int priority;
  final String? phone;
  const _TicketArgs({required this.ticket, required this.service,
    required this.priority, this.phone});
}

// ─── App root ─────────────────────────────────────────────────────────────────

class TabletKioskApp extends StatelessWidget {
  const TabletKioskApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp.router(
    title: 'QueueMaster Kiosque',
    theme: _theme(),
    themeMode: ThemeMode.light,
    routerConfig: _router(),
    debugShowCheckedModeBanner: false,
    builder: (ctx, child) => MediaQuery(
      data: MediaQuery.of(ctx).copyWith(textScaler: const TextScaler.linear(1.0)),
      child: child!),
  );

  ThemeData _theme() => ThemeData(
    useMaterial3: true, fontFamily: 'Inter',
    colorScheme: ColorScheme.fromSeed(seedColor: _kPrimary, primary: _kPrimary),
    scaffoldBackgroundColor: const Color(0xFFF5F7FA),
    elevatedButtonTheme: ElevatedButtonThemeData(style: ElevatedButton.styleFrom(
      backgroundColor: _kPrimary, foregroundColor: Colors.white,
      minimumSize: const Size(double.infinity, 64), elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      textStyle: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600, fontFamily: 'Inter'))),
    outlinedButtonTheme: OutlinedButtonThemeData(style: OutlinedButton.styleFrom(
      minimumSize: const Size(double.infinity, 56),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      side: const BorderSide(color: _kBorder, width: 1.5),
      textStyle: const TextStyle(fontSize: 15, fontWeight: FontWeight.w500, fontFamily: 'Inter'))),
  );

  GoRouter _router() => GoRouter(initialLocation: '/welcome', routes: [
    GoRoute(path: '/welcome',  builder: (_, __) => const _WelcomeScreen()),
    GoRoute(path: '/services', builder: (_, __) => const _ServiceScreen()),
    GoRoute(path: '/priority', builder: (_, s) => _PriorityScreen(service: s.extra as ServiceModel)),
    GoRoute(path: '/ticket',   builder: (_, s) => _TicketScreen(args: s.extra as _TicketArgs)),
    GoRoute(path: '/checkin',  builder: (_, __) => const _CheckinScreen()),
  ]);
}

// ─── Idle detector ────────────────────────────────────────────────────────────

class _Idle extends StatefulWidget {
  final Widget child;
  final VoidCallback onIdle;
  const _Idle({required this.child, required this.onIdle});
  @override
  State<_Idle> createState() => _IdleState();
}
class _IdleState extends State<_Idle> {
  Timer? _t;
  @override void initState() { super.initState(); _reset(); }
  @override void dispose()   { _t?.cancel(); super.dispose(); }
  void _reset() { _t?.cancel(); _t = Timer(_kIdleTime, widget.onIdle); }
  @override
  Widget build(BuildContext context) => GestureDetector(
    behavior: HitTestBehavior.opaque,
    onTap: _reset, onPanDown: (_) => _reset(),
    child: widget.child);
}

// ─── Kiosk Scaffold ───────────────────────────────────────────────────────────

class _Shell extends StatefulWidget {
  final Widget body;
  final String subtitle;
  final bool showBack;
  final Color? header;
  const _Shell({required this.body, required this.subtitle,
    this.showBack = true, this.header});
  @override
  State<_Shell> createState() => _ShellState();
}
class _ShellState extends State<_Shell> {
  String _t = '';
  Timer? _timer;
  @override
  void initState() {
    super.initState();
    _update();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) => _update());
  }
  void _update() {
    final n = DateTime.now();
    if (mounted) setState(() =>
      _t = '${n.hour.toString().padLeft(2,'0')}:${n.minute.toString().padLeft(2,'0')}');
  }
  @override void dispose() { _timer?.cancel(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: Column(children: [
      Container(
        color: widget.header ?? _kPrimary,
        padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 14),
        child: Row(children: [
          Container(width: 44, height: 44,
            decoration: BoxDecoration(color: Colors.white.withOpacity(0.17),
                borderRadius: BorderRadius.circular(12)),
            child: const Icon(Icons.queue, color: Colors.white, size: 24)),
          const SizedBox(width: 14),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('QueueMaster Pro',
                style: TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w600)),
            Text(widget.subtitle,
                style: TextStyle(color: Colors.white.withOpacity(0.6), fontSize: 12)),
          ]),
          const Spacer(),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            decoration: BoxDecoration(color: Colors.white.withOpacity(0.15),
                borderRadius: BorderRadius.circular(8)),
            child: Text(_t, style: const TextStyle(color: Colors.white, fontSize: 22,
                fontWeight: FontWeight.w500,
                fontFeatures: [FontFeature.tabularFigures()]))),
          if (widget.showBack) ...[
            const SizedBox(width: 12),
            TextButton.icon(onPressed: () => context.pop(),
              icon: const Icon(Icons.arrow_back_ios, color: Colors.white70, size: 16),
              label: const Text('Retour', style: TextStyle(color: Colors.white70, fontSize: 13))),
          ],
        ]),
      ),
      Expanded(child: widget.body),
    ]),
  );
}

// ─── Step dots ────────────────────────────────────────────────────────────────

class _Steps extends StatelessWidget {
  final int current;
  const _Steps(this.current);
  @override
  Widget build(BuildContext context) {
    const labels = ['Service', 'Situation', 'Ticket'];
    return Row(children: List.generate(3, (i) {
      final done   = i + 1 < current;
      final active = i + 1 == current;
      final color  = done ? _kAccent : active ? _kPrimary : const Color(0xFFCBD5E1);
      return Expanded(child: Row(children: [
        Column(children: [
          AnimatedContainer(duration: const Duration(milliseconds: 250),
            width: 34, height: 34,
            decoration: BoxDecoration(color: color, shape: BoxShape.circle),
            child: Center(child: done
                ? const Icon(Icons.check, color: Colors.white, size: 17)
                : Text('${i+1}', style: TextStyle(
                    color: active ? Colors.white : const Color(0xFFADB5BD),
                    fontWeight: FontWeight.w700, fontSize: 14)))),
          const SizedBox(height: 4),
          Text(labels[i], style: TextStyle(fontSize: 11,
              color: active ? _kPrimary : _kMuted,
              fontWeight: active ? FontWeight.w600 : FontWeight.normal)),
        ]),
        if (i < 2) Expanded(child: Container(height: 2,
            margin: const EdgeInsets.only(bottom: 18),
            color: done ? _kAccent : _kBorder)),
      ]));
    }));
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// SCREEN 1 — WELCOME
// ═══════════════════════════════════════════════════════════════════════════════

class _WelcomeScreen extends ConsumerStatefulWidget {
  const _WelcomeScreen({super.key});
  @override
  ConsumerState<_WelcomeScreen> createState() => _WelcomeState();
}
class _WelcomeState extends ConsumerState<_WelcomeScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _anim;
  List<ServiceModel> _services = [];
  Timer? _refresh;
  String _time = '', _date = '';
  Timer? _clock;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1800))
      ..repeat(reverse: true);
    _anim = Tween<double>(begin: 0.97, end: 1.03)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut));
    _loadServices();
    _refresh = Timer.periodic(const Duration(seconds: 30), (_) => _loadServices());
    _updateClock();
    _clock = Timer.periodic(const Duration(seconds: 1), (_) => _updateClock());
  }

  void _updateClock() {
    final n = DateTime.now();
    if (mounted) setState(() {
      _time = '${n.hour.toString().padLeft(2,'0')}:${n.minute.toString().padLeft(2,'0')}:${n.second.toString().padLeft(2,'0')}';
      _date = '${n.day.toString().padLeft(2,'0')}/${n.month.toString().padLeft(2,'0')}/${n.year}';
    });
  }

  Future<void> _loadServices() async {
    try {
      final s = await ref.read(apiProvider).getServices();
      if (mounted) setState(() => _services = s);
    } catch (_) {}
  }

  @override
  void dispose() { _ctrl.dispose(); _refresh?.cancel(); _clock?.cancel(); super.dispose(); }

  @override
  Widget build(BuildContext context) => _Idle(
    onIdle: () {},
    child: Scaffold(
      backgroundColor: _kPrimary,
      body: Row(children: [
        // Left CTA
        Expanded(flex: 5, child: Padding(
          padding: const EdgeInsets.all(44),
          child: Column(mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start, children: [
            Container(width: 80, height: 80,
              decoration: BoxDecoration(color: Colors.white.withOpacity(0.14),
                  borderRadius: BorderRadius.circular(22)),
              child: const Icon(Icons.confirmation_number_outlined,
                  color: Colors.white, size: 44)),
            const SizedBox(height: 32),
            const Text('Bienvenue', style: TextStyle(color: Colors.white,
                fontSize: 48, fontWeight: FontWeight.w800, height: 1.1)),
            const SizedBox(height: 12),
            Text('Touchez l\'écran pour rejoindre\nla file d\'attente.',
                style: TextStyle(color: Colors.white.withOpacity(0.75),
                    fontSize: 19, height: 1.5)),
            const SizedBox(height: 48),
            ScaleTransition(scale: _anim, child: SizedBox(
              width: double.infinity, height: 76,
              child: ElevatedButton.icon(
                onPressed: () => context.push('/services'),
                icon: const Icon(Icons.confirmation_number_outlined, size: 28),
                label: const Text('Prendre un ticket'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.white, foregroundColor: _kPrimary,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                  elevation: 0,
                  textStyle: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700, fontFamily: 'Inter')),
              ))),
            const SizedBox(height: 14),
            SizedBox(width: double.infinity, height: 60,
              child: OutlinedButton.icon(
                onPressed: () => context.push('/checkin'),
                icon: const Icon(Icons.qr_code_scanner, size: 22),
                label: const Text('J\'ai un rendez-vous — Scanner QR'),
                style: OutlinedButton.styleFrom(
                  foregroundColor: Colors.white,
                  side: BorderSide(color: Colors.white.withOpacity(0.35), width: 1.5),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500, fontFamily: 'Inter')),
              )),
          ]),
        )),

        // Right: services + clock
        Expanded(flex: 4, child: Container(
          color: const Color(0xFF162942),
          padding: const EdgeInsets.all(32),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              const Text('Services disponibles',
                  style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w600)),
              const Spacer(),
              Container(width: 8, height: 8,
                  decoration: const BoxDecoration(color: _kAccent, shape: BoxShape.circle)),
              const SizedBox(width: 5),
              Text('Temps réel',
                  style: TextStyle(color: Colors.white.withOpacity(0.4), fontSize: 12)),
            ]),
            const SizedBox(height: 20),
            Expanded(child: _services.isEmpty
                ? const Center(child: CircularProgressIndicator(color: Colors.white38))
                : ListView.separated(
                    itemCount: _services.length,
                    separatorBuilder: (_, __) =>
                        Divider(color: Colors.white.withOpacity(0.07), height: 1),
                    itemBuilder: (_, i) => _SvcRow(service: _services[i]))),
            const SizedBox(height: 20),
            Column(crossAxisAlignment: CrossAxisAlignment.center, children: [
              Text(_time, style: const TextStyle(color: Colors.white, fontSize: 34,
                  fontWeight: FontWeight.w300,
                  fontFeatures: [FontFeature.tabularFigures()])),
              Text(_date, style: TextStyle(color: Colors.white.withOpacity(0.3), fontSize: 13)),
            ]),
          ]),
        )),
      ]),
    ),
  );
}

class _SvcRow extends StatelessWidget {
  final ServiceModel service;
  const _SvcRow({required this.service});
  Color get _dot { if (!service.isActive) return Colors.grey;
    if (service.estimatedWait < 10) return _kAccent;
    if (service.estimatedWait < 20) return _kWarning; return _kDanger; }
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 14),
    child: Row(children: [
      Container(width: 10, height: 10, decoration: BoxDecoration(color: _dot, shape: BoxShape.circle)),
      const SizedBox(width: 12),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(service.name, style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w500)),
        const SizedBox(height: 2),
        Text(service.isActive ? '${service.currentQueue} personne(s) en attente' : 'Service fermé',
            style: TextStyle(color: Colors.white.withOpacity(0.4), fontSize: 12)),
      ])),
      if (service.isActive) Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
        Text('~${service.estimatedWait} min',
            style: const TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w600)),
        Text('d\'attente', style: TextStyle(color: Colors.white.withOpacity(0.3), fontSize: 11)),
      ]),
    ]),
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// SCREEN 2 — SERVICE SELECTION
// ═══════════════════════════════════════════════════════════════════════════════

class _ServiceScreen extends ConsumerStatefulWidget {
  const _ServiceScreen({super.key});
  @override
  ConsumerState<_ServiceScreen> createState() => _ServiceState();
}
class _ServiceState extends ConsumerState<_ServiceScreen> {
  ServiceModel? _sel;
  List<ServiceModel> _services = [];
  bool _loading = true;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    try {
      final s = await ref.read(apiProvider).getServices();
      if (mounted) setState(() { _services = s; _loading = false; });
    } catch (_) { if (mounted) setState(() => _loading = false); }
  }

  @override
  Widget build(BuildContext context) => _Idle(
    onIdle: () => context.go('/welcome'),
    child: _Shell(subtitle: 'Choisissez un service', body: Padding(
      padding: const EdgeInsets.all(32),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        _Steps(1),
        const SizedBox(height: 26),
        const Text('Quel service souhaitez-vous ?',
            style: TextStyle(fontSize: 26, fontWeight: FontWeight.w700, color: _kText)),
        const SizedBox(height: 4),
        const Text('Touchez une carte pour sélectionner',
            style: TextStyle(fontSize: 14, color: _kMuted)),
        const SizedBox(height: 22),
        Expanded(child: _loading
            ? const Center(child: CircularProgressIndicator())
            : GridView.builder(
                gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
                  maxCrossAxisExtent: 260, childAspectRatio: 1.1,
                  crossAxisSpacing: 14, mainAxisSpacing: 14),
                itemCount: _services.length,
                itemBuilder: (_, i) => _SvcCard(
                  service: _services[i],
                  isSelected: _sel?.id == _services[i].id,
                  onTap: _services[i].isActive
                      ? () => setState(() => _sel = _services[i])
                      : null))),
        const SizedBox(height: 18),
        Row(children: [
          Expanded(child: OutlinedButton(onPressed: () => context.pop(),
              child: const Text('← Retour'))),
          const SizedBox(width: 14),
          Expanded(flex: 2, child: AnimatedOpacity(
            opacity: _sel != null ? 1.0 : 0.38,
            duration: const Duration(milliseconds: 200),
            child: ElevatedButton(
              onPressed: _sel != null
                  ? () => context.push('/priority', extra: _sel) : null,
              child: Text(_sel != null
                  ? 'Continuer — ${_sel!.name} →'
                  : 'Sélectionnez un service')))),
        ]),
      ]),
    )),
  );
}

class _SvcCard extends StatelessWidget {
  final ServiceModel service;
  final bool isSelected;
  final VoidCallback? onTap;
  const _SvcCard({required this.service, required this.isSelected, this.onTap});

  Color get _c { try { return Color(int.parse((service.color ?? '#1E3A5F').replaceFirst('#', '0xFF'))); } catch (_) { return _kPrimary; } }
  IconData get _icon { final n = service.name.toLowerCase();
    if (n.contains('caisse') || n.contains('paie')) return Icons.payment_outlined;
    if (n.contains('rh') || n.contains('human')) return Icons.people_outline;
    if (n.contains('tech') || n.contains('support')) return Icons.build_outlined;
    if (n.contains('direct')) return Icons.account_balance_outlined;
    return Icons.business_outlined; }
  Color _wc(int m) { if (m < 10) return _kAccent; if (m < 20) return _kWarning; return _kDanger; }

  @override
  Widget build(BuildContext context) => Material(color: Colors.transparent,
    child: InkWell(onTap: onTap, borderRadius: BorderRadius.circular(20),
      child: AnimatedContainer(duration: const Duration(milliseconds: 140),
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: isSelected ? _c.withOpacity(0.09) : Colors.white,
          border: Border.all(color: isSelected ? _c : _kBorder, width: isSelected ? 2.5 : 1),
          borderRadius: BorderRadius.circular(20)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Container(width: 46, height: 46,
              decoration: BoxDecoration(color: _c.withOpacity(0.12), borderRadius: BorderRadius.circular(12)),
              child: Icon(_icon, color: _c, size: 24)),
            const Spacer(),
            if (!service.isActive) Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(color: Colors.grey.shade100, borderRadius: BorderRadius.circular(6)),
              child: const Text('Fermé', style: TextStyle(fontSize: 11, color: Colors.grey))),
            if (isSelected) Container(width: 26, height: 26,
              decoration: BoxDecoration(color: _c, shape: BoxShape.circle),
              child: const Icon(Icons.check, color: Colors.white, size: 15)),
          ]),
          const Spacer(),
          Text(service.name, style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700,
              color: isSelected ? _c : _kText)),
          const SizedBox(height: 3),
          if (service.isActive) ...[
            Text('${service.currentQueue} en attente',
                style: const TextStyle(fontSize: 12, color: _kMuted)),
            const SizedBox(height: 2),
            Row(children: [
              const Icon(Icons.access_time, size: 13, color: Color(0xFF64748B)),
              const SizedBox(width: 3),
              Text('~${service.estimatedWait} min',
                  style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600,
                      color: _wc(service.estimatedWait))),
            ]),
          ],
        ]),
      )));
}

// ═══════════════════════════════════════════════════════════════════════════════
// SCREEN 3 — PRIORITY + PHONE NUMBER
// ═══════════════════════════════════════════════════════════════════════════════

class _PriorityScreen extends ConsumerStatefulWidget {
  final ServiceModel service;
  const _PriorityScreen({super.key, required this.service});
  @override
  ConsumerState<_PriorityScreen> createState() => _PriorityState();
}
class _PriorityState extends ConsumerState<_PriorityScreen> {
  int _priority = 4;
  bool _sms = false;
  final _phone = TextEditingController();
  bool _loading = false;
  String? _error;

  static const _prios = [
    (1,'Urgence',Icons.local_hospital_outlined,_kDanger,'Situation d\'urgence médicale ou critique'),
    (2,'PMR / Senior',Icons.accessible_outlined,_kAccent,'Personne à mobilité réduite ou âgée'),
    (3,'VIP',Icons.star_outline,_kWarning,'Client VIP ou porteur de rendez-vous'),
    (4,'Standard',Icons.person_outline,Color(0xFF2E75B6),'File normale — premier arrivé, premier servi'),
  ];

  @override void dispose() { _phone.dispose(); super.dispose(); }

  Future<void> _confirm() async {
    setState(() { _loading = true; _error = null; });
    try {
      final ticket = await ref.read(apiProvider).createTicket(
        'KIOSK_ANON', widget.service.id, _priority);
      if (mounted) context.push('/ticket', extra: _TicketArgs(
        ticket: ticket, service: widget.service, priority: _priority,
        phone: _sms && _phone.text.trim().isNotEmpty ? _phone.text.trim() : null));
    } catch (e) {
      if (mounted) setState(() { _error = 'Erreur serveur. Réessayez.'; _loading = false; });
    }
  }

  @override
  Widget build(BuildContext context) => _Idle(
    onIdle: () => context.go('/welcome'),
    child: _Shell(subtitle: 'Votre situation', body: Row(children: [

      // Left: priorities
      Expanded(flex: 6, child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          _Steps(2),
          const SizedBox(height: 26),
          const Text('Quelle est votre situation ?',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.w700, color: _kText)),
          const SizedBox(height: 4),
          const Text('Touchez pour sélectionner votre priorité',
              style: TextStyle(fontSize: 14, color: _kMuted)),
          const SizedBox(height: 18),
          Expanded(child: ListView.separated(
            itemCount: _prios.length,
            separatorBuilder: (_, __) => const SizedBox(height: 10),
            itemBuilder: (_, i) {
              final (val, name, icon, color, desc) = _prios[i];
              final sel = _priority == val;
              return GestureDetector(
                onTap: () => setState(() => _priority = val),
                child: AnimatedContainer(duration: const Duration(milliseconds: 140),
                  padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
                  decoration: BoxDecoration(
                    color: sel ? color.withOpacity(0.08) : Colors.white,
                    border: Border.all(color: sel ? color : _kBorder, width: sel ? 2.5 : 1),
                    borderRadius: BorderRadius.circular(16)),
                  child: Row(children: [
                    Container(width: 52, height: 52,
                      decoration: BoxDecoration(color: color.withOpacity(0.13),
                          borderRadius: BorderRadius.circular(14)),
                      child: Icon(icon, color: color, size: 26)),
                    const SizedBox(width: 16),
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(name, style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700,
                          color: sel ? color : _kText)),
                      const SizedBox(height: 2),
                      Text(desc, style: const TextStyle(fontSize: 13, color: _kMuted)),
                    ])),
                    if (sel) Container(width: 28, height: 28,
                      decoration: BoxDecoration(color: color, shape: BoxShape.circle),
                      child: const Icon(Icons.check, color: Colors.white, size: 16))
                    else Container(width: 28, height: 28,
                      decoration: BoxDecoration(border: Border.all(color: _kBorder, width: 1.5),
                          shape: BoxShape.circle)),
                  ])),
              );
            })),
        ])),

      // Right: phone + confirm
      Container(width: 340,
        decoration: const BoxDecoration(color: _kSurface,
            border: Border(left: BorderSide(color: _kBorder))),
        padding: const EdgeInsets.all(28),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          // Service recap
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: _kPrimary.withOpacity(0.06),
                border: Border.all(color: _kPrimary.withOpacity(0.18)),
                borderRadius: BorderRadius.circular(12)),
            child: Row(children: [
              const Icon(Icons.confirmation_number_outlined, color: _kPrimary, size: 20),
              const SizedBox(width: 10),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('Service sélectionné',
                    style: TextStyle(fontSize: 11, color: Color(0xFF64748B))),
                Text(widget.service.name,
                    style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: _kPrimary)),
                Text('~${widget.service.estimatedWait} min d\'attente',
                    style: const TextStyle(fontSize: 12, color: _kMuted)),
              ])),
            ])),
          const SizedBox(height: 22),
          const Text('Notification SMS (optionnel)',
              style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600, color: _kText)),
          const SizedBox(height: 4),
          const Text('Recevez un SMS quand c\'est votre tour',
              style: TextStyle(fontSize: 13, color: _kMuted)),
          const SizedBox(height: 12),

          // SMS toggle
          GestureDetector(
            onTap: () => setState(() => _sms = !_sms),
            child: AnimatedContainer(duration: const Duration(milliseconds: 140),
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: _sms ? _kAccent.withOpacity(0.07) : Colors.white,
                border: Border.all(color: _sms ? _kAccent : _kBorder, width: _sms ? 2 : 1),
                borderRadius: BorderRadius.circular(12)),
              child: Row(children: [
                Icon(Icons.sms_outlined,
                    color: _sms ? _kAccent : Colors.grey.shade400, size: 22),
                const SizedBox(width: 10),
                Expanded(child: Text('Activer les notifications SMS',
                    style: TextStyle(fontSize: 14,
                        color: _sms ? _kAccent : const Color(0xFF64748B),
                        fontWeight: _sms ? FontWeight.w600 : FontWeight.normal))),
                Switch(value: _sms, onChanged: (v) => setState(() => _sms = v),
                    activeColor: _kAccent),
              ]))),

          // Phone field
          AnimatedSize(duration: const Duration(milliseconds: 200), curve: Curves.easeInOut,
            child: _sms ? Padding(
              padding: const EdgeInsets.only(top: 14),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('Votre numéro de téléphone',
                    style: TextStyle(fontSize: 13, fontWeight: FontWeight.w500, color: _kText)),
                const SizedBox(height: 8),
                TextField(
                  controller: _phone,
                  keyboardType: TextInputType.phone,
                  inputFormatters: [
                    FilteringTextInputFormatter.allow(RegExp(r'[0-9+\s\-]')),
                    LengthLimitingTextInputFormatter(15),
                  ],
                  style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w700, letterSpacing: 2),
                  textAlign: TextAlign.center,
                  decoration: InputDecoration(
                    hintText: '+216 XX XXX XXX',
                    hintStyle: const TextStyle(fontSize: 16, letterSpacing: 1, color: Color(0xFFCBD5E1)),
                    prefixIcon: const Icon(Icons.phone_outlined),
                    filled: true, fillColor: const Color(0xFFF0F4F8),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide.none),
                    focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12),
                        borderSide: const BorderSide(color: _kAccent, width: 2))),
                ),
              ])) : const SizedBox.shrink()),

          const Spacer(),
          if (_error != null) ...[
            Container(padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: _kDanger.withOpacity(0.07),
                  border: Border.all(color: _kDanger.withOpacity(0.3)),
                  borderRadius: BorderRadius.circular(10)),
              child: Row(children: [
                const Icon(Icons.error_outline, color: _kDanger, size: 18),
                const SizedBox(width: 8),
                Expanded(child: Text(_error!, style: const TextStyle(color: _kDanger, fontSize: 13))),
              ])),
            const SizedBox(height: 12),
          ],

          SizedBox(width: double.infinity, height: 68,
            child: ElevatedButton.icon(
              onPressed: _loading ? null : _confirm,
              icon: _loading
                  ? const SizedBox(width: 20, height: 20,
                      child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                  : const Icon(Icons.confirmation_number, size: 24),
              label: Text(_loading ? 'Création...' : 'Confirmer et prendre mon ticket'),
              style: ElevatedButton.styleFrom(backgroundColor: _kAccent,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  textStyle: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700, fontFamily: 'Inter')),
            )),
          const SizedBox(height: 10),
          OutlinedButton(onPressed: () => context.pop(),
              child: const Text('← Retour au choix du service')),
        ]),
      ),
    ])),
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// SCREEN 4 — TICKET CONFIRMATION + PRINT + SMS
// ═══════════════════════════════════════════════════════════════════════════════

class _TicketScreen extends ConsumerStatefulWidget {
  final _TicketArgs args;
  const _TicketScreen({super.key, required this.args});
  @override
  ConsumerState<_TicketScreen> createState() => _TicketState();
}
class _TicketState extends ConsumerState<_TicketScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _bounceCtrl;
  late Animation<double> _bounceAnim;
  bool _printing = false, _printDone = false;
  bool _smsSending = false, _smsDone = false;
  String? _smsError;
  int _count = 30;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _bounceCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 700))..forward();
    _bounceAnim = Tween<double>(begin: 0.6, end: 1.0)
        .animate(CurvedAnimation(parent: _bounceCtrl, curve: Curves.elasticOut));
    if (widget.args.phone != null && widget.args.phone!.isNotEmpty)
      WidgetsBinding.instance.addPostFrameCallback((_) => _sendSms());
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) { t.cancel(); return; }
      if (_count <= 1) { t.cancel(); if (mounted) context.go('/welcome'); return; }
      setState(() => _count--);
    });
  }

  @override
  void dispose() { _bounceCtrl.dispose(); _timer?.cancel(); super.dispose(); }

  Future<void> _print() async {
    setState(() => _printing = true);
    await Future.delayed(const Duration(milliseconds: 1400));
    if (mounted) setState(() { _printing = false; _printDone = true; });
  }

  Future<void> _sendSms() async {
    if (widget.args.phone == null || widget.args.phone!.isEmpty) return;
    setState(() { _smsSending = true; _smsError = null; });
    try {
      final res = await http.post(
        Uri.parse('https://api.queuemaster.pro/api/notifications/sms'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'phone': widget.args.phone,
          'ticketNumber': widget.args.ticket.ticketNumber,
          'serviceName': widget.args.service.name,
          'position': widget.args.ticket.position,
          'estimatedWait': widget.args.ticket.estimatedWaitMinutes,
        }),
      );
      if (mounted) setState(() { _smsSending = false; _smsDone = res.statusCode < 300; });
    } catch (_) {
      if (mounted) setState(() { _smsSending = false; _smsError = 'SMS non envoyé'; });
    }
  }

  String get _prioLabel { switch(widget.args.priority) {
    case 1: return 'Urgence'; case 2: return 'PMR / Senior';
    case 3: return 'VIP'; default: return 'Standard'; }}
  Color get _prioColor { switch(widget.args.priority) {
    case 1: return _kDanger; case 2: return _kAccent;
    case 3: return _kWarning; default: return const Color(0xFF2E75B6); }}

  @override
  Widget build(BuildContext context) {
    final t = widget.args.ticket; final s = widget.args.service;
    final n = DateTime.now();
    final ds = '${n.day.toString().padLeft(2,'0')}/${n.month.toString().padLeft(2,'0')}/${n.year} '
        '${n.hour.toString().padLeft(2,'0')}:${n.minute.toString().padLeft(2,'0')}';

    return _Idle(onIdle: () => context.go('/welcome'),
      child: _Shell(subtitle: 'Votre ticket', showBack: false, header: _kAccent,
        body: Row(children: [

          // Left: ticket card
          Expanded(flex: 5, child: Container(color: const Color(0xFFF0FDF4),
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Container(width: 72, height: 72,
                decoration: const BoxDecoration(color: _kAccent, shape: BoxShape.circle),
                child: const Icon(Icons.check, color: Colors.white, size: 40)),
              const SizedBox(height: 16),
              const Text('Votre ticket est prêt !',
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700, color: _kText)),
              const SizedBox(height: 22),
              Container(width: 300, padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 22),
                decoration: BoxDecoration(color: Colors.white,
                    border: Border.all(color: _kBorder), borderRadius: BorderRadius.circular(22)),
                child: Column(children: [
                  Text(_kCompany.toUpperCase(),
                      style: TextStyle(fontSize: 11, letterSpacing: 2,
                          color: Colors.grey.shade400, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 12),
                  ScaleTransition(scale: _bounceAnim,
                    child: Text(t.ticketNumber,
                        style: const TextStyle(fontSize: 78, fontWeight: FontWeight.w800,
                            color: _kPrimary, height: 1, letterSpacing: -3))),
                  const SizedBox(height: 8),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
                    decoration: BoxDecoration(color: _prioColor.withOpacity(0.1),
                        border: Border.all(color: _prioColor.withOpacity(0.3)),
                        borderRadius: BorderRadius.circular(20)),
                    child: Text(_prioLabel,
                        style: TextStyle(color: _prioColor, fontSize: 13, fontWeight: FontWeight.w600))),
                  const SizedBox(height: 12),
                  Divider(color: Colors.grey.shade200),
                  const SizedBox(height: 8),
                  _IR('Service', s.name),
                  _IR('Position', '#${t.position}'),
                  _IR('Attente estimée', '~${t.estimatedWaitMinutes} min', color: _kWarning),
                  _IR('Date', ds),
                  if (widget.args.phone != null && widget.args.phone!.isNotEmpty)
                    _IR('SMS', widget.args.phone!),
                  const SizedBox(height: 10),
                  Divider(color: Colors.grey.shade200),
                  const SizedBox(height: 8),
                  QrImageView(data: t.id, version: QrVersions.auto, size: 85,
                      eyeStyle: const QrEyeStyle(eyeShape: QrEyeShape.square, color: _kPrimary),
                      dataModuleStyle: const QrDataModuleStyle(
                          dataModuleShape: QrDataModuleShape.square, color: _kPrimary)),
                  const SizedBox(height: 5),
                  const Text('Scannez pour suivre votre position sur mobile',
                      style: TextStyle(fontSize: 10, color: _kMuted)),
                ])),
            ]))),

          // Right: actions + countdown
          Container(width: 340, color: Colors.white, padding: const EdgeInsets.all(26),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Container(padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(color: const Color(0xFFF0F9FF),
                    border: Border.all(color: const Color(0xFFBAE6FD)),
                    borderRadius: BorderRadius.circular(12)),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Row(children: [
                    Icon(Icons.info_outline, color: Color(0xFF0369A1), size: 18),
                    SizedBox(width: 8),
                    Text('Que faire maintenant ?',
                        style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: Color(0xFF0369A1))),
                  ]),
                  const SizedBox(height: 8),
                  _Ins('1', 'Asseyez-vous en salle d\'attente'),
                  _Ins('2', 'Surveillez l\'écran TV — votre numéro apparaîtra'),
                  _Ins('3', widget.args.phone != null
                      ? 'Vous recevrez un SMS quand c\'est votre tour'
                      : 'Imprimez ce ticket pour l\'avoir avec vous'),
                ])),
              const SizedBox(height: 18),

              // Print
              const Text('Imprimer le ticket',
                  style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: _kText)),
              const SizedBox(height: 8),
              SizedBox(width: double.infinity, height: 56,
                child: ElevatedButton.icon(
                  onPressed: _printing ? null : _print,
                  icon: _printing
                      ? const SizedBox(width: 18, height: 18,
                          child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                      : Icon(_printDone ? Icons.check : Icons.print_outlined, size: 22),
                  label: Text(_printing ? 'Impression...' : _printDone ? 'Ticket imprimé !' : 'Imprimer le ticket'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _printDone ? _kAccent : _kPrimary,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    textStyle: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600, fontFamily: 'Inter')),
                )),

              // SMS status
              if (widget.args.phone != null && widget.args.phone!.isNotEmpty) ...[
                const SizedBox(height: 12),
                AnimatedContainer(duration: const Duration(milliseconds: 300),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: _smsDone ? const Color(0xFFF0FDF4)
                        : _smsError != null ? const Color(0xFFFFF1F2) : Colors.grey.shade50,
                    border: Border.all(color: _smsDone ? const Color(0xFF86EFAC)
                        : _smsError != null ? const Color(0xFFFCA5A5) : _kBorder),
                    borderRadius: BorderRadius.circular(10)),
                  child: Row(children: [
                    _smsSending
                        ? const SizedBox(width: 18, height: 18,
                            child: CircularProgressIndicator(strokeWidth: 2))
                        : Icon(_smsDone ? Icons.sms : _smsError != null ? Icons.sms_failed : Icons.sms_outlined,
                            color: _smsDone ? _kAccent : _smsError != null ? _kDanger : Colors.grey, size: 20),
                    const SizedBox(width: 10),
                    Expanded(child: Text(
                      _smsSending ? 'Envoi du SMS...'
                          : _smsDone ? 'SMS envoyé au ${widget.args.phone}'
                          : _smsError ?? 'SMS en préparation',
                      style: TextStyle(fontSize: 13,
                          color: _smsDone ? _kAccent : _smsError != null ? _kDanger : Colors.grey.shade600))),
                    if (_smsError != null)
                      TextButton(onPressed: _sendSms,
                          child: const Text('Réessayer', style: TextStyle(fontSize: 12))),
                  ])),
              ],

              const Spacer(),

              // Countdown
              Container(padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(color: Colors.grey.shade50,
                    border: Border.all(color: _kBorder), borderRadius: BorderRadius.circular(12)),
                child: Row(children: [
                  SizedBox(width: 44, height: 44, child: Stack(children: [
                    CircularProgressIndicator(value: _count / 30,
                        backgroundColor: Colors.grey.shade200,
                        color: _count > 10 ? _kPrimary : _kDanger, strokeWidth: 4),
                    Center(child: Text('$_count', style: TextStyle(fontSize: 13,
                        fontWeight: FontWeight.w700,
                        color: _count > 10 ? _kPrimary : _kDanger))),
                  ])),
                  const SizedBox(width: 12),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Text('Retour accueil automatique',
                        style: TextStyle(fontSize: 13, fontWeight: FontWeight.w500)),
                    Text('dans $_count seconde${_count > 1 ? 's' : ''}',
                        style: const TextStyle(fontSize: 12, color: _kMuted)),
                  ])),
                ])),
              const SizedBox(height: 10),
              OutlinedButton.icon(
                onPressed: () => context.go('/welcome'),
                icon: const Icon(Icons.home_outlined, size: 20),
                label: const Text('Terminer — Retour accueil'),
                style: OutlinedButton.styleFrom(minimumSize: const Size(double.infinity, 50),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
              ),
            ])),
        ])));
  }
}

class _IR extends StatelessWidget {
  final String l, v; final Color? color;
  const _IR(this.l, this.v, {this.color});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 3),
    child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      Text(l, style: const TextStyle(fontSize: 12, color: _kMuted)),
      Text(v, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: color ?? _kText)),
    ]));
}

class _Ins extends StatelessWidget {
  final String n, t;
  const _Ins(this.n, this.t);
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(top: 6),
    child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Container(width: 18, height: 18,
        decoration: BoxDecoration(color: const Color(0xFF0369A1).withOpacity(0.14), shape: BoxShape.circle),
        child: Center(child: Text(n, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w700, color: Color(0xFF0369A1))))),
      const SizedBox(width: 8),
      Expanded(child: Text(t, style: const TextStyle(fontSize: 12, color: Color(0xFF374151), height: 1.4))),
    ]));
}

// ═══════════════════════════════════════════════════════════════════════════════
// SCREEN 5 — CHECK-IN QR (rendez-vous)
// ═══════════════════════════════════════════════════════════════════════════════

class _CheckinScreen extends ConsumerStatefulWidget {
  const _CheckinScreen({super.key});
  @override
  ConsumerState<_CheckinScreen> createState() => _CheckinState();
}
class _CheckinState extends ConsumerState<_CheckinScreen> {
  final _code = TextEditingController();
  bool _loading = false;
  String? _error;
  bool _success = false;

  @override void dispose() { _code.dispose(); super.dispose(); }

  Future<void> _checkin(String code) async {
    if (code.trim().isEmpty) return;
    setState(() { _loading = true; _error = null; });
    try {
      await Future.delayed(const Duration(milliseconds: 1200)); // replace with real API
      if (mounted) setState(() { _loading = false; _success = true; });
    } catch (_) {
      if (mounted) setState(() { _error = 'Code invalide ou rendez-vous introuvable.'; _loading = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_success) return _Shell(subtitle: 'Check-in confirmé', showBack: false, header: _kAccent,
      body: Center(child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 460),
        child: Padding(padding: const EdgeInsets.all(40), child: Column(
          mainAxisAlignment: MainAxisAlignment.center, children: [
          const Icon(Icons.check_circle, color: _kAccent, size: 80),
          const SizedBox(height: 20),
          const Text('Bienvenue !', style: TextStyle(fontSize: 34, fontWeight: FontWeight.w800, color: _kText)),
          const SizedBox(height: 8),
          const Text('Votre rendez-vous a été enregistré',
              style: TextStyle(fontSize: 17, color: _kMuted)),
          const SizedBox(height: 24),
          const Text('Asseyez-vous — votre numéro apparaîtra\nsur l\'écran TV de la salle.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 15, color: _kMuted, height: 1.5)),
          const SizedBox(height: 28),
          SizedBox(width: 260, height: 56,
            child: ElevatedButton.icon(
              onPressed: () => context.go('/welcome'),
              icon: const Icon(Icons.home_outlined),
              label: const Text('Retour à l\'accueil'),
              style: ElevatedButton.styleFrom(
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
            )),
        ])))));

    return _Idle(onIdle: () => context.go('/welcome'),
      child: _Shell(subtitle: 'Check-in rendez-vous', body: Row(children: [
        // QR scanner zone
        Expanded(flex: 5, child: Container(color: Colors.black,
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            Container(width: 260, height: 260,
              decoration: BoxDecoration(border: Border.all(color: Colors.white, width: 2),
                  borderRadius: BorderRadius.circular(16)),
              child: const Center(
                  child: Icon(Icons.qr_code_scanner, color: Colors.white54, size: 80))),
            const SizedBox(height: 16),
            const Text('Placez votre QR code dans le cadre',
                style: TextStyle(color: Colors.white70, fontSize: 16)),
          ]))),

        // Manual code
        Container(width: 340, color: Colors.white, padding: const EdgeInsets.all(28),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Ou entrez votre code',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600, color: _kText)),
            const SizedBox(height: 5),
            const Text('Code présent dans votre email de confirmation',
                style: TextStyle(fontSize: 13, color: _kMuted)),
            const SizedBox(height: 16),
            TextField(controller: _code,
              textCapitalization: TextCapitalization.characters,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800,
                  letterSpacing: 4, color: _kPrimary),
              decoration: const InputDecoration(
                hintText: 'AB12CD34',
                hintStyle: TextStyle(fontSize: 18, letterSpacing: 3, color: Color(0xFFCBD5E1)),
                filled: true, fillColor: Color(0xFFF0F4F8),
                border: OutlineInputBorder(borderSide: BorderSide.none,
                    borderRadius: BorderRadius.all(Radius.circular(12))))),
            const SizedBox(height: 14),
            if (_error != null) ...[
              Container(padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(color: _kDanger.withOpacity(0.07),
                    border: Border.all(color: _kDanger.withOpacity(0.3)),
                    borderRadius: BorderRadius.circular(10)),
                child: Text(_error!, style: const TextStyle(color: _kDanger, fontSize: 13))),
              const SizedBox(height: 12),
            ],
            SizedBox(width: double.infinity, height: 56,
              child: ElevatedButton.icon(
                onPressed: _loading ? null : () => _checkin(_code.text),
                icon: _loading
                    ? const SizedBox(width: 18, height: 18,
                        child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                    : const Icon(Icons.check_circle_outline),
                label: Text(_loading ? 'Vérification...' : 'Valider le code'),
                style: ElevatedButton.styleFrom(backgroundColor: _kAccent,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
              )),
            const Spacer(),
            OutlinedButton.icon(onPressed: () => context.go('/welcome'),
              icon: const Icon(Icons.home_outlined, size: 18),
              label: const Text('← Retour accueil'),
              style: OutlinedButton.styleFrom(minimumSize: const Size(double.infinity, 50),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
            ),
          ])),
      ])));
  }
}
