using MediatR;
using Microsoft.Extensions.Logging;
using QueueMaster.Application.DTOs;
using QueueMaster.Application.Interfaces;
using QueueMaster.Domain.Entities;
using QueueMaster.Domain.Enums;
using QueueMaster.Domain.Interfaces;

namespace QueueMaster.Application.Features.Tickets.Commands;

// ── Create Ticket ─────────────────────────────────────────────────────────────
public record CreateTicketCommand(Guid ClientId, Guid ServiceId, TicketPriority Priority)
    : IRequest<TicketDto>;

public class CreateTicketHandler : IRequestHandler<CreateTicketCommand, TicketDto>
{
    private readonly ITicketRepository _tickets;
    private readonly IServiceRepository _services;
    private readonly IClientRepository _clients;
    private readonly INotificationService _notify;
    private readonly IQueueHubService _hub;
    private readonly IUnitOfWork _uow;
    private readonly ILogger<CreateTicketHandler> _log;

    public CreateTicketHandler(ITicketRepository tickets, IServiceRepository services,
        IClientRepository clients, INotificationService notify,
        IQueueHubService hub, IUnitOfWork uow, ILogger<CreateTicketHandler> log)
    {
        _tickets = tickets; _services = services; _clients = clients;
        _notify = notify; _hub = hub; _uow = uow; _log = log;
    }

    public async Task<TicketDto> Handle(CreateTicketCommand req, CancellationToken ct)
    {
        var service = await _services.GetByIdAsync(req.ServiceId, ct)
            ?? throw new KeyNotFoundException($"Service {req.ServiceId} not found.");
        if (!service.IsActive) throw new InvalidOperationException("Service is inactive.");

        var client = await _clients.GetByIdAsync(req.ClientId, ct)
            ?? throw new KeyNotFoundException($"Client {req.ClientId} not found.");

        var ticketNumber = await _tickets.GenerateTicketNumberAsync(req.ServiceId, ct);
        var estimatedWait = await _services.GetEstimatedWaitAsync(req.ServiceId, ct);

        var ticket = Ticket.Create(req.ClientId, req.ServiceId, req.Priority, ticketNumber, estimatedWait);
        await _tickets.AddAsync(ticket, ct);
        await _uow.SaveChangesAsync(ct);

        var position = await _tickets.GetPositionAsync(ticket.Id, ct);

        // Push + Email notifications
        await _notify.SendTicketCreatedAsync(client.Id, ticket.Id, ticketNumber,
            service.Name, position, estimatedWait, ct);

        // Real-time broadcast
        var stats = await _tickets.GetQueueStatsAsync(req.ServiceId, ct);
        await _hub.BroadcastQueueStatsAsync(req.ServiceId,
            new QueueStatsDto(req.ServiceId, service.Name, stats.TotalWaiting,
                stats.TotalServedToday, stats.AverageWaitMinutes, stats.ActiveAgents), ct);

        var dto = ToDto(ticket, client.FullName, client.Email, service.Name, position, null);
        await _hub.BroadcastNewTicketAsync(new NewTicketEvent(req.ServiceId, dto), ct);

        _log.LogInformation("Ticket {Number} created for client {ClientId}", ticketNumber, req.ClientId);
        return dto;
    }

    private static TicketDto ToDto(Ticket t, string name, string email, string svc, int pos, string? counter)
        => new(t.Id, t.TicketNumber, t.ClientId, name, email, t.ServiceId, svc,
            t.Priority, t.Status, t.CreatedAt, t.CalledAt, t.ServedAt,
            t.EstimatedWaitMinutes, t.ActualWaitMinutes, pos, counter);
}

// ── Call Next Ticket ──────────────────────────────────────────────────────────
public record CallNextTicketCommand(Guid ServiceId, Guid AgentId) : IRequest<TicketDto?>;

public class CallNextTicketHandler : IRequestHandler<CallNextTicketCommand, TicketDto?>
{
    private readonly ITicketRepository _tickets;
    private readonly IAgentRepository _agents;
    private readonly IServiceRepository _services;
    private readonly IClientRepository _clients;
    private readonly INotificationService _notify;
    private readonly IQueueHubService _hub;
    private readonly IUnitOfWork _uow;

    public CallNextTicketHandler(ITicketRepository tickets, IAgentRepository agents,
        IServiceRepository services, IClientRepository clients,
        INotificationService notify, IQueueHubService hub, IUnitOfWork uow)
    {
        _tickets = tickets; _agents = agents; _services = services;
        _clients = clients; _notify = notify; _hub = hub; _uow = uow;
    }

    public async Task<TicketDto?> Handle(CallNextTicketCommand req, CancellationToken ct)
    {
        var next = await _tickets.GetNextWaitingAsync(req.ServiceId, ct);
        if (next is null) return null;

        var agent = await _agents.GetByIdAsync(req.AgentId, ct)
            ?? throw new KeyNotFoundException($"Agent {req.AgentId} not found.");
        var service = await _services.GetByIdAsync(req.ServiceId, ct);
        var client = await _clients.GetByIdAsync(next.ClientId, ct);

        next.Call(req.AgentId);
        _tickets.Update(next);
        await _uow.SaveChangesAsync(ct);

        // Push + Email: ticket called
        if (client is not null)
            await _notify.SendTicketCalledAsync(client.Id, next.Id, next.TicketNumber,
                agent.Counter, agent.FullName, ct);

        // Real-time: notify all screens
        await _hub.BroadcastTicketCalledAsync(new TicketCalledEvent(
            next.Id, next.TicketNumber, agent.Counter, agent.FullName, service?.Name ?? ""), ct);

        // Recalculate positions for remaining waiting tickets
        var remaining = await _tickets.GetWaitingOrderedAsync(req.ServiceId, ct);
        int pos = 1;
        foreach (var t in remaining)
        {
            await _hub.SendPositionUpdateAsync(t.ClientId,
                new QueuePositionUpdatedEvent(t.Id, t.TicketNumber, pos++, t.EstimatedWaitMinutes), ct);
        }

        var stats = await _tickets.GetQueueStatsAsync(req.ServiceId, ct);
        await _hub.BroadcastQueueStatsAsync(req.ServiceId,
            new QueueStatsDto(req.ServiceId, service?.Name ?? "", stats.TotalWaiting,
                stats.TotalServedToday, stats.AverageWaitMinutes, stats.ActiveAgents), ct);

        return new TicketDto(next.Id, next.TicketNumber, next.ClientId,
            client?.FullName ?? "", client?.Email ?? "", next.ServiceId,
            service?.Name ?? "", next.Priority, next.Status, next.CreatedAt,
            next.CalledAt, next.ServedAt, next.EstimatedWaitMinutes,
            next.ActualWaitMinutes, 0, agent.Counter);
    }
}

// ── Serve Ticket ──────────────────────────────────────────────────────────────
public record ServeTicketCommand(Guid TicketId, string? Notes = null) : IRequest<Unit>;

public class ServeTicketHandler : IRequestHandler<ServeTicketCommand, Unit>
{
    private readonly ITicketRepository _tickets;
    private readonly IClientRepository _clients;
    private readonly IServiceRepository _services;
    private readonly IAgentRepository _agents;
    private readonly INotificationService _notify;
    private readonly IQueueHubService _hub;
    private readonly IUnitOfWork _uow;

    public ServeTicketHandler(ITicketRepository tickets, IClientRepository clients,
        IServiceRepository services, IAgentRepository agents,
        INotificationService notify, IQueueHubService hub, IUnitOfWork uow)
    {
        _tickets = tickets; _clients = clients; _services = services;
        _agents = agents; _notify = notify; _hub = hub; _uow = uow;
    }

    public async Task<Unit> Handle(ServeTicketCommand req, CancellationToken ct)
    {
        var ticket = await _tickets.GetByIdAsync(req.TicketId, ct)
            ?? throw new KeyNotFoundException();
        var client = await _clients.GetByIdAsync(ticket.ClientId, ct);
        var service = await _services.GetByIdAsync(ticket.ServiceId, ct);

        ticket.MarkServed(req.Notes);
        _tickets.Update(ticket);

        if (ticket.AssignedAgentId.HasValue)
        {
            var agent = await _agents.GetByIdAsync(ticket.AssignedAgentId.Value, ct);
            agent?.IncrementServed();
            if (agent is not null) _agents.Update(agent);
        }

        await _uow.SaveChangesAsync(ct);

        // Notify client: ticket served
        if (client is not null)
            await _notify.SendTicketServedAsync(client.Id, ticket.Id, ticket.TicketNumber,
                service?.Name ?? "", ct);

        // Broadcast to TV + admin
        await _hub.BroadcastTicketServedAsync(new TicketServedEvent(ticket.Id, ticket.TicketNumber), ct);

        var stats = await _tickets.GetQueueStatsAsync(ticket.ServiceId, ct);
        await _hub.BroadcastQueueStatsAsync(ticket.ServiceId,
            new QueueStatsDto(ticket.ServiceId, service?.Name ?? "", stats.TotalWaiting,
                stats.TotalServedToday, stats.AverageWaitMinutes, stats.ActiveAgents), ct);

        return Unit.Value;
    }
}

// ── Mark No-Show ──────────────────────────────────────────────────────────────
public record MarkNoShowCommand(Guid TicketId) : IRequest<Unit>;

public class MarkNoShowHandler : IRequestHandler<MarkNoShowCommand, Unit>
{
    private readonly ITicketRepository _tickets;
    private readonly IQueueHubService _hub;
    private readonly IServiceRepository _services;
    private readonly IUnitOfWork _uow;

    public MarkNoShowHandler(ITicketRepository tickets, IQueueHubService hub,
        IServiceRepository services, IUnitOfWork uow)
    { _tickets = tickets; _hub = hub; _services = services; _uow = uow; }

    public async Task<Unit> Handle(MarkNoShowCommand req, CancellationToken ct)
    {
        var ticket = await _tickets.GetByIdAsync(req.TicketId, ct)
            ?? throw new KeyNotFoundException();
        ticket.MarkNoShow();
        _tickets.Update(ticket);
        await _uow.SaveChangesAsync(ct);

        var stats = await _tickets.GetQueueStatsAsync(ticket.ServiceId, ct);
        var service = await _services.GetByIdAsync(ticket.ServiceId, ct);
        await _hub.BroadcastQueueStatsAsync(ticket.ServiceId,
            new QueueStatsDto(ticket.ServiceId, service?.Name ?? "",
                stats.TotalWaiting, stats.TotalServedToday,
                stats.AverageWaitMinutes, stats.ActiveAgents), ct);
        return Unit.Value;
    }
}

// ── Cancel Ticket ─────────────────────────────────────────────────────────────
public record CancelTicketCommand(Guid TicketId, Guid RequesterId) : IRequest<Unit>;

public class CancelTicketHandler : IRequestHandler<CancelTicketCommand, Unit>
{
    private readonly ITicketRepository _tickets;
    private readonly IUnitOfWork _uow;

    public CancelTicketHandler(ITicketRepository tickets, IUnitOfWork uow)
    { _tickets = tickets; _uow = uow; }

    public async Task<Unit> Handle(CancelTicketCommand req, CancellationToken ct)
    {
        var ticket = await _tickets.GetByIdAsync(req.TicketId, ct)
            ?? throw new KeyNotFoundException();
        if (ticket.ClientId != req.RequesterId)
            throw new UnauthorizedAccessException("Cannot cancel another client's ticket.");
        ticket.Cancel();
        _tickets.Update(ticket);
        await _uow.SaveChangesAsync(ct);
        return Unit.Value;
    }
}
