using MediatR;
using QueueMaster.Application.DTOs;
using QueueMaster.Application.Interfaces;
using QueueMaster.Domain.Entities;
using QueueMaster.Domain.Enums;
using QueueMaster.Domain.Interfaces;

namespace QueueMaster.Application.Features.Tickets.Queries;

// ── Get Queue ─────────────────────────────────────────────────────────────────
public record GetQueueQuery(Guid ServiceId, TicketStatus? Status = null)
    : IRequest<IReadOnlyList<TicketDto>>;

public class GetQueueHandler : IRequestHandler<GetQueueQuery, IReadOnlyList<TicketDto>>
{
    private readonly ITicketRepository _tickets;
    private readonly IClientRepository _clients;
    private readonly IServiceRepository _services;

    public GetQueueHandler(ITicketRepository t, IClientRepository c, IServiceRepository s)
    { _tickets = t; _clients = c; _services = s; }

    public async Task<IReadOnlyList<TicketDto>> Handle(GetQueueQuery req, CancellationToken ct)
    {
        var tickets = await _tickets.GetByServiceAsync(req.ServiceId, req.Status, ct);
        var service = await _services.GetByIdAsync(req.ServiceId, ct);
        var result = new List<TicketDto>();
        int pos = 1;
        foreach (var t in tickets.OrderBy(x => x.Priority).ThenBy(x => x.CreatedAt))
        {
            var client = await _clients.GetByIdAsync(t.ClientId, ct);
            result.Add(new TicketDto(t.Id, t.TicketNumber, t.ClientId,
                client?.FullName ?? "N/A", client?.Email ?? "", t.ServiceId,
                service?.Name ?? "N/A", t.Priority, t.Status, t.CreatedAt,
                t.CalledAt, t.ServedAt, t.EstimatedWaitMinutes,
                t.ActualWaitMinutes, t.Status == TicketStatus.Waiting ? pos++ : 0, null));
        }
        return result;
    }
}

// ── Get Ticket Position ───────────────────────────────────────────────────────
public record GetTicketPositionQuery(Guid TicketId) : IRequest<TicketPositionDto>;

public class GetTicketPositionHandler : IRequestHandler<GetTicketPositionQuery, TicketPositionDto>
{
    private readonly ITicketRepository _tickets;
    public GetTicketPositionHandler(ITicketRepository t) => _tickets = t;

    public async Task<TicketPositionDto> Handle(GetTicketPositionQuery req, CancellationToken ct)
    {
        var ticket = await _tickets.GetByIdAsync(req.TicketId, ct)
            ?? throw new KeyNotFoundException();
        var pos = await _tickets.GetPositionAsync(req.TicketId, ct);
        return new TicketPositionDto(ticket.Id, ticket.TicketNumber, pos,
            ticket.EstimatedWaitMinutes, ticket.Status);
    }
}

// ── Get Queue Stats ───────────────────────────────────────────────────────────
public record GetQueueStatsQuery(Guid ServiceId) : IRequest<QueueStatsDto>;

public class GetQueueStatsHandler : IRequestHandler<GetQueueStatsQuery, QueueStatsDto>
{
    private readonly ITicketRepository _tickets;
    private readonly IServiceRepository _services;
    public GetQueueStatsHandler(ITicketRepository t, IServiceRepository s)
    { _tickets = t; _services = s; }

    public async Task<QueueStatsDto> Handle(GetQueueStatsQuery req, CancellationToken ct)
    {
        var service = await _services.GetByIdAsync(req.ServiceId, ct)
            ?? throw new KeyNotFoundException();
        var stats = await _tickets.GetQueueStatsAsync(req.ServiceId, ct);
        return new QueueStatsDto(req.ServiceId, service.Name, stats.TotalWaiting,
            stats.TotalServedToday, stats.AverageWaitMinutes, stats.ActiveAgents);
    }
}

namespace QueueMaster.Application.Features.Appointments.Commands;

// ── Create Appointment ────────────────────────────────────────────────────────
public record CreateAppointmentCommand(Guid ClientId, Guid ServiceId, DateTime ScheduledAt)
    : IRequest<AppointmentDto>;

public class CreateAppointmentHandler : IRequestHandler<CreateAppointmentCommand, AppointmentDto>
{
    private readonly IAppointmentRepository _appointments;
    private readonly IClientRepository _clients;
    private readonly IServiceRepository _services;
    private readonly INotificationService _notify;
    private readonly IUnitOfWork _uow;

    public CreateAppointmentHandler(IAppointmentRepository a, IClientRepository c,
        IServiceRepository s, INotificationService n, IUnitOfWork uow)
    { _appointments = a; _clients = c; _services = s; _notify = n; _uow = uow; }

    public async Task<AppointmentDto> Handle(CreateAppointmentCommand req, CancellationToken ct)
    {
        var client = await _clients.GetByIdAsync(req.ClientId, ct)
            ?? throw new KeyNotFoundException("Client not found.");
        var service = await _services.GetByIdAsync(req.ServiceId, ct)
            ?? throw new KeyNotFoundException("Service not found.");

        var appointment = Appointment.Create(req.ClientId, req.ServiceId, req.ScheduledAt);
        await _appointments.AddAsync(appointment, ct);
        await _uow.SaveChangesAsync(ct);

        await _notify.SendAppointmentConfirmedAsync(client.Id, appointment.Id,
            service.Name, appointment.ScheduledAt, appointment.QrCode, ct);

        return new AppointmentDto(appointment.Id, client.Id, client.FullName,
            client.Email, service.Id, service.Name, appointment.ScheduledAt,
            appointment.Status, appointment.QrCode);
    }
}

// ── CheckIn via QR ────────────────────────────────────────────────────────────
public record CheckInCommand(string QrCode) : IRequest<AppointmentDto>;

public class CheckInHandler : IRequestHandler<CheckInCommand, AppointmentDto>
{
    private readonly IAppointmentRepository _appointments;
    private readonly IClientRepository _clients;
    private readonly IServiceRepository _services;
    private readonly IUnitOfWork _uow;

    public CheckInHandler(IAppointmentRepository a, IClientRepository c,
        IServiceRepository s, IUnitOfWork uow)
    { _appointments = a; _clients = c; _services = s; _uow = uow; }

    public async Task<AppointmentDto> Handle(CheckInCommand req, CancellationToken ct)
    {
        var appt = await _appointments.GetByQrCodeAsync(req.QrCode, ct)
            ?? throw new KeyNotFoundException("Invalid QR code.");
        if (appt.ScheduledAt.Date != DateTime.UtcNow.Date)
            throw new InvalidOperationException("This appointment is not for today.");
        if (appt.Status == AppointmentStatus.Cancelled)
            throw new InvalidOperationException("This appointment has been cancelled.");

        appt.MarkArrived();
        _appointments.Update(appt);
        await _uow.SaveChangesAsync(ct);

        var client = await _clients.GetByIdAsync(appt.ClientId, ct);
        var service = await _services.GetByIdAsync(appt.ServiceId, ct);

        return new AppointmentDto(appt.Id, appt.ClientId, client?.FullName ?? "",
            client?.Email ?? "", appt.ServiceId, service?.Name ?? "",
            appt.ScheduledAt, appt.Status, appt.QrCode);
    }
}
