using QueueMaster.Application.DTOs;

namespace QueueMaster.Application.Interfaces;

public interface INotificationService
{
    Task SendTicketCreatedAsync(Guid clientId, Guid ticketId, string ticketNumber,
        string serviceName, int position, int estimatedWait, CancellationToken ct = default);

    Task SendTicketCalledAsync(Guid clientId, Guid ticketId, string ticketNumber,
        string counter, string agentName, CancellationToken ct = default);

    Task SendTicketServedAsync(Guid clientId, Guid ticketId, string ticketNumber,
        string serviceName, CancellationToken ct = default);

    Task SendPositionReminderAsync(Guid clientId, Guid ticketId, string ticketNumber,
        int position, int estimatedWait, CancellationToken ct = default);

    Task SendAppointmentConfirmedAsync(Guid clientId, Guid appointmentId, string serviceName,
        DateTime scheduledAt, string qrCode, CancellationToken ct = default);

    Task SendAppointmentReminderAsync(Guid clientId, Guid appointmentId, string serviceName,
        DateTime scheduledAt, int hoursAhead, CancellationToken ct = default);
}

public interface IPushNotificationService
{
    Task SendAsync(string fcmToken, string title, string body,
        Dictionary<string, string>? data = null, CancellationToken ct = default);
    Task SendMulticastAsync(IEnumerable<string> tokens, string title, string body,
        Dictionary<string, string>? data = null, CancellationToken ct = default);
}

public interface IEmailService
{
    Task SendAsync(string to, string subject, string htmlBody, CancellationToken ct = default);
    Task SendTicketConfirmationAsync(string to, string clientName, string ticketNumber,
        string serviceName, int position, int estimatedWait, CancellationToken ct = default);
    Task SendTicketCalledAsync(string to, string clientName, string ticketNumber,
        string counter, CancellationToken ct = default);
    Task SendTicketServedAsync(string to, string clientName, string ticketNumber,
        string serviceName, CancellationToken ct = default);
    Task SendAppointmentConfirmationAsync(string to, string clientName, string serviceName,
        DateTime scheduledAt, string qrCode, CancellationToken ct = default);
    Task SendAppointmentReminderAsync(string to, string clientName, string serviceName,
        DateTime scheduledAt, int hoursAhead, CancellationToken ct = default);
}

public interface IQueueHubService
{
    Task BroadcastQueueStatsAsync(Guid serviceId, QueueStatsDto stats, CancellationToken ct = default);
    Task BroadcastTicketCalledAsync(TicketCalledEvent evt, CancellationToken ct = default);
    Task BroadcastTicketServedAsync(TicketServedEvent evt, CancellationToken ct = default);
    Task BroadcastNewTicketAsync(NewTicketEvent evt, CancellationToken ct = default);
    Task SendPositionUpdateAsync(Guid clientId, QueuePositionUpdatedEvent evt, CancellationToken ct = default);
}

public interface ITokenService
{
    string GenerateAccessToken(string userId, string email, string role,
        Guid? clientId = null, Guid? agentId = null);
    string GenerateRefreshToken();
    bool ValidateRefreshToken(string userId, string refreshToken);
    void StoreRefreshToken(string userId, string refreshToken);
    void RevokeRefreshToken(string userId);
}

public interface ICacheService
{
    Task<T?> GetAsync<T>(string key, CancellationToken ct = default);
    Task SetAsync<T>(string key, T value, TimeSpan? expiry = null, CancellationToken ct = default);
    Task RemoveAsync(string key, CancellationToken ct = default);
    Task<int> IncrementAsync(string key, CancellationToken ct = default);
}
