using QueueMaster.Domain.Enums;

namespace QueueMaster.Application.DTOs;

// Tickets
public record CreateTicketDto(Guid ClientId, Guid ServiceId, TicketPriority Priority = TicketPriority.Standard);
public record TicketDto(Guid Id, string TicketNumber, Guid ClientId, string ClientName,
    string ClientEmail, Guid ServiceId, string ServiceName, TicketPriority Priority,
    TicketStatus Status, DateTime CreatedAt, DateTime? CalledAt, DateTime? ServedAt,
    int EstimatedWaitMinutes, int? ActualWaitMinutes, int Position, string? Counter);
public record TicketPositionDto(Guid TicketId, string TicketNumber, int Position,
    int EstimatedWaitMinutes, TicketStatus Status);
public record QueueStatsDto(Guid ServiceId, string ServiceName, int TotalWaiting,
    int TotalServedToday, double AverageWaitMinutes, int ActiveAgents);
public record CallNextDto(Guid ServiceId);
public record ServeTicketDto(string? Notes = null);

// Services
public record ServiceDto(Guid Id, string Name, string? Description, int MaxCapacity,
    int AverageServiceMinutes, bool IsActive, string OpenTime, string CloseTime,
    string? Color, int EstimatedWaitMinutes, int CurrentQueue);
public record CreateServiceDto(string Name, string? Description, int MaxCapacity,
    int AverageServiceMinutes, string OpenTime, string CloseTime, string? Color);

// Clients
public record ClientDto(Guid Id, string FullName, string Email, string? Phone);
public record RegisterDto(string FullName, string Email, string Password, string? Phone);
public record LoginDto(string Email, string Password);
public record AuthResponseDto(string AccessToken, string RefreshToken, int ExpiresIn,
    string Role, Guid? ClientId, Guid? AgentId);
public record UpdateFcmTokenDto(string FcmToken);

// Agents
public record AgentDto(Guid Id, string FullName, string Counter, AgentStatus Status, int ServedToday);
public record CreateAgentDto(string FullName, string Counter, string UserId, Guid ServiceId);

// Appointments
public record CreateAppointmentDto(Guid ClientId, Guid ServiceId, DateTime ScheduledAt);
public record AppointmentDto(Guid Id, Guid ClientId, string ClientName, string ClientEmail,
    Guid ServiceId, string ServiceName, DateTime ScheduledAt, AppointmentStatus Status, string QrCode);
public record CheckInDto(string QrCode);

// Notifications
public record SendNotificationDto(Guid ClientId, Guid? TicketId, NotificationType Type,
    string Title, string Body, NotificationChannel Channel);
public record NotificationLogDto(Guid Id, string Title, string Body, NotificationType Type,
    bool IsSent, DateTime CreatedAt, DateTime? SentAt);

// Real-time SignalR events
public record QueuePositionUpdatedEvent(Guid TicketId, string TicketNumber, int NewPosition, int EstimatedWait);
public record TicketCalledEvent(Guid TicketId, string TicketNumber, string Counter, string AgentName, string ServiceName);
public record TicketServedEvent(Guid TicketId, string TicketNumber);
public record QueueStatsUpdatedEvent(Guid ServiceId, QueueStatsDto Stats);
public record NewTicketEvent(Guid ServiceId, TicketDto Ticket);
