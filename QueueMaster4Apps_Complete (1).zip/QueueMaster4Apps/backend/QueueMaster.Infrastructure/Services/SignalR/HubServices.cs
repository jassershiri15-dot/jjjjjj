using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using QueueMaster.Application.DTOs;
using QueueMaster.Application.Interfaces;
using QueueMaster.Domain.Enums;
using QueueMaster.Infrastructure.Persistence;

namespace QueueMaster.Infrastructure.Services.SignalR;

// ── SignalR Hub ────────────────────────────────────────────────────────────────
[Authorize]
public class QueueHub(ILogger<QueueHub> log) : Hub
{
    public override async Task OnConnectedAsync()
    {
        log.LogDebug("Client connected: {Id}", Context.ConnectionId);
        await base.OnConnectedAsync();
    }

    public override async Task OnDisconnectedAsync(Exception? ex)
    {
        log.LogDebug("Client disconnected: {Id}", Context.ConnectionId);
        await base.OnDisconnectedAsync(ex);
    }

    // Client joins service group (agents, admin, TV)
    public async Task JoinServiceGroup(string serviceId)
        => await Groups.AddToGroupAsync(Context.ConnectionId, $"service-{serviceId}");

    public async Task LeaveServiceGroup(string serviceId)
        => await Groups.RemoveFromGroupAsync(Context.ConnectionId, $"service-{serviceId}");

    // Client joins own notification channel
    public async Task JoinClientGroup(string clientId)
        => await Groups.AddToGroupAsync(Context.ConnectionId, $"client-{clientId}");

    // TV app joins display group
    public async Task JoinDisplayGroup()
        => await Groups.AddToGroupAsync(Context.ConnectionId, "display");

    // Admin joins admin group
    public async Task JoinAdminGroup()
        => await Groups.AddToGroupAsync(Context.ConnectionId, "admin");
}

// ── QueueHubService (server-side sender) ──────────────────────────────────────
public class QueueHubService(IHubContext<QueueHub> hub, ILogger<QueueHubService> log)
    : IQueueHubService
{
    public async Task BroadcastQueueStatsAsync(Guid serviceId, QueueStatsDto stats, CancellationToken ct = default)
    {
        await hub.Clients.Group($"service-{serviceId}").SendAsync("QueueStatsUpdated", stats, ct);
        await hub.Clients.Group("display").SendAsync("QueueStatsUpdated", stats, ct);
        await hub.Clients.Group("admin").SendAsync("QueueStatsUpdated", stats, ct);
    }

    public async Task BroadcastTicketCalledAsync(TicketCalledEvent evt, CancellationToken ct = default)
    {
        await hub.Clients.Group($"client-{evt.TicketId}").SendAsync("TicketCalled", evt, ct);
        await hub.Clients.Group("display").SendAsync("TicketCalled", evt, ct);
        await hub.Clients.Group("admin").SendAsync("TicketCalled", evt, ct);
        log.LogInformation("Ticket {Num} called at counter {Counter}", evt.TicketNumber, evt.Counter);
    }

    public async Task BroadcastTicketServedAsync(TicketServedEvent evt, CancellationToken ct = default)
    {
        await hub.Clients.Group("display").SendAsync("TicketServed", evt, ct);
        await hub.Clients.Group("admin").SendAsync("TicketServed", evt, ct);
    }

    public async Task BroadcastNewTicketAsync(NewTicketEvent evt, CancellationToken ct = default)
    {
        await hub.Clients.Group($"service-{evt.ServiceId}").SendAsync("NewTicket", evt.Ticket, ct);
        await hub.Clients.Group("admin").SendAsync("NewTicket", evt.Ticket, ct);
    }

    public async Task SendPositionUpdateAsync(Guid clientId, QueuePositionUpdatedEvent evt, CancellationToken ct = default)
        => await hub.Clients.Group($"client-{clientId}").SendAsync("PositionUpdated", evt, ct);
}

// ── Queue Background Service (recalculate wait times every 60s) ───────────────
public class QueueBackgroundService(IServiceScopeFactory scopeFactory, ILogger<QueueBackgroundService> log)
    : BackgroundService
{
    protected override async Task ExecuteAsync(CancellationToken ct)
    {
        log.LogInformation("QueueBackgroundService started.");
        while (!ct.IsCancellationRequested)
        {
            try { await ProcessAsync(ct); }
            catch (Exception ex) { log.LogError(ex, "QueueBackgroundService error."); }
            await Task.Delay(TimeSpan.FromSeconds(60), ct);
        }
    }

    private async Task ProcessAsync(CancellationToken ct)
    {
        using var scope = scopeFactory.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
        var hub = scope.ServiceProvider.GetRequiredService<IQueueHubService>();
        var notify = scope.ServiceProvider.GetRequiredService<INotificationService>();

        var services = await db.Services.Where(s => s.IsActive).ToListAsync(ct);

        foreach (var service in services)
        {
            var waiting = await db.Tickets
                .Include(t => t.Client)
                .Where(t => t.ServiceId == service.Id && t.Status == TicketStatus.Waiting)
                .OrderBy(t => t.Priority).ThenBy(t => t.CreatedAt).ToListAsync(ct);

            if (!waiting.Any()) continue;

            var agents = await db.ServiceAgents.Include(sa => sa.Agent)
                .CountAsync(sa => sa.ServiceId == service.Id && sa.Agent!.Status == AgentStatus.Active, ct);

            int pos = 1;
            foreach (var ticket in waiting)
            {
                var wait = agents > 0
                    ? (int)Math.Ceiling((double)pos / agents * service.AverageServiceMinutes)
                    : pos * service.AverageServiceMinutes;

                ticket.UpdateEstimatedWait(wait);

                // Reminder when 3 people ahead
                if (pos == 3 && ticket.Client is not null)
                    await notify.SendPositionReminderAsync(ticket.ClientId, ticket.Id,
                        ticket.TicketNumber, pos, wait, ct);

                await hub.SendPositionUpdateAsync(ticket.ClientId,
                    new QueuePositionUpdatedEvent(ticket.Id, ticket.TicketNumber, pos, wait), ct);
                pos++;
            }

            await db.SaveChangesAsync(ct);

            var served = await db.Tickets.CountAsync(t =>
                t.ServiceId == service.Id && t.Status == TicketStatus.Served
                && t.ServedAt.HasValue && t.ServedAt.Value.Date == DateTime.UtcNow.Date, ct);

            await hub.BroadcastQueueStatsAsync(service.Id,
                new QueueStatsDto(service.Id, service.Name, waiting.Count, served,
                    waiting.Any() ? waiting.Average(t => (double)t.EstimatedWaitMinutes) : 0, agents), ct);
        }
    }
}

// ── Appointment Reminder Background Service ───────────────────────────────────
public class AppointmentReminderService(IServiceScopeFactory scopeFactory, ILogger<AppointmentReminderService> log)
    : BackgroundService
{
    protected override async Task ExecuteAsync(CancellationToken ct)
    {
        while (!ct.IsCancellationRequested)
        {
            try { await SendRemindersAsync(ct); }
            catch (Exception ex) { log.LogError(ex, "AppointmentReminderService error."); }
            await Task.Delay(TimeSpan.FromMinutes(5), ct);
        }
    }

    private async Task SendRemindersAsync(CancellationToken ct)
    {
        using var scope = scopeFactory.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
        var notify = scope.ServiceProvider.GetRequiredService<INotificationService>();
        var now = DateTime.UtcNow;

        foreach (var hours in new[] { 24, 1 })
        {
            var target = now.AddHours(hours);
            var appointments = await db.Appointments.Include(a => a.Service)
                .Where(a => a.Status == AppointmentStatus.Confirmed
                            && a.ScheduledAt >= target.AddMinutes(-5)
                            && a.ScheduledAt <= target.AddMinutes(5))
                .ToListAsync(ct);

            foreach (var appt in appointments)
                if (appt.Service is not null)
                    await notify.SendAppointmentReminderAsync(appt.ClientId, appt.Id,
                        appt.Service.Name, appt.ScheduledAt, hours, ct);
        }
    }
}
