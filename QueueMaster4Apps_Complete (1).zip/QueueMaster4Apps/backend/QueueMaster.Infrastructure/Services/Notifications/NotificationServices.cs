using FirebaseAdmin;
using FirebaseAdmin.Messaging;
using Google.Apis.Auth.OAuth2;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using QueueMaster.Application.Interfaces;
using QueueMaster.Domain.Entities;
using QueueMaster.Domain.Enums;
using QueueMaster.Domain.Interfaces;
using QueueMaster.Infrastructure.Persistence;

namespace QueueMaster.Infrastructure.Services.Notifications;

// ── Composite Notification Service ────────────────────────────────────────────
public class NotificationService(
    IPushNotificationService push,
    IEmailService email,
    AppDbContext db,
    IUnitOfWork uow,
    ILogger<NotificationService> log) : INotificationService
{
    public async Task SendTicketCreatedAsync(Guid clientId, Guid ticketId,
        string ticketNumber, string serviceName, int position, int estimatedWait, CancellationToken ct)
    {
        var client = await db.Clients.FindAsync(new object[] { clientId }, ct);
        if (client is null) return;

        var title = "Ticket créé — " + ticketNumber;
        var body = $"Service : {serviceName} | Position : #{position} | Attente estimée : ~{estimatedWait} min";

        await SendAllChannelsAsync(client, ticketId, NotificationType.TicketCreated, title, body, ct);
        await email.SendTicketConfirmationAsync(client.Email, client.FullName,
            ticketNumber, serviceName, position, estimatedWait, ct);
        log.LogInformation("Ticket created notification sent to {Email}", client.Email);
    }

    public async Task SendTicketCalledAsync(Guid clientId, Guid ticketId,
        string ticketNumber, string counter, string agentName, CancellationToken ct)
    {
        var client = await db.Clients.FindAsync(new object[] { clientId }, ct);
        if (client is null) return;

        var title = $"C'est votre tour ! — {ticketNumber}";
        var body = $"Présentez-vous au guichet {counter} avec {agentName}";

        await SendAllChannelsAsync(client, ticketId, NotificationType.TicketCalled, title, body, ct);
        await email.SendTicketCalledAsync(client.Email, client.FullName, ticketNumber, counter, ct);
        log.LogInformation("Ticket called notification sent to {Email}", client.Email);
    }

    public async Task SendTicketServedAsync(Guid clientId, Guid ticketId,
        string ticketNumber, string serviceName, CancellationToken ct)
    {
        var client = await db.Clients.FindAsync(new object[] { clientId }, ct);
        if (client is null) return;

        var title = "Service terminé — Merci !";
        var body = $"Votre demande {ticketNumber} au service {serviceName} a été traitée.";

        await SendAllChannelsAsync(client, ticketId, NotificationType.TicketServed, title, body, ct);
        await email.SendTicketServedAsync(client.Email, client.FullName, ticketNumber, serviceName, ct);
    }

    public async Task SendPositionReminderAsync(Guid clientId, Guid ticketId,
        string ticketNumber, int position, int estimatedWait, CancellationToken ct)
    {
        var client = await db.Clients.FindAsync(new object[] { clientId }, ct);
        if (client is null) return;

        var title = "Préparez-vous !";
        var body = $"Il reste {position} personne(s) avant vous. Attente : ~{estimatedWait} min.";

        await SendAllChannelsAsync(client, ticketId, NotificationType.PositionReminder, title, body, ct);
    }

    public async Task SendAppointmentConfirmedAsync(Guid clientId, Guid appointmentId,
        string serviceName, DateTime scheduledAt, string qrCode, CancellationToken ct)
    {
        var client = await db.Clients.FindAsync(new object[] { clientId }, ct);
        if (client is null) return;

        var title = "Rendez-vous confirmé";
        var body = $"{serviceName} — {scheduledAt:dd/MM/yyyy à HH:mm}. Code QR : {qrCode}";

        await SendAllChannelsAsync(client, appointmentId, NotificationType.AppointmentConfirmed, title, body, ct);
        await email.SendAppointmentConfirmationAsync(client.Email, client.FullName,
            serviceName, scheduledAt, qrCode, ct);
    }

    public async Task SendAppointmentReminderAsync(Guid clientId, Guid appointmentId,
        string serviceName, DateTime scheduledAt, int hoursAhead, CancellationToken ct)
    {
        var client = await db.Clients.FindAsync(new object[] { clientId }, ct);
        if (client is null) return;

        var title = hoursAhead == 24 ? "Rappel RDV demain" : $"RDV dans {hoursAhead}h";
        var body = $"{serviceName} — {scheduledAt:dd/MM/yyyy à HH:mm}";

        await SendAllChannelsAsync(client, appointmentId, NotificationType.AppointmentReminder, title, body, ct);
        await email.SendAppointmentReminderAsync(client.Email, client.FullName,
            serviceName, scheduledAt, hoursAhead, ct);
    }

    private async Task SendAllChannelsAsync(Client client, Guid? refId,
        NotificationType type, string title, string body, CancellationToken ct)
    {
        // Push notification
        if (!string.IsNullOrEmpty(client.FcmToken))
        {
            var notifLog = NotificationLog.Create(client.Id, refId, type, title, body, NotificationChannel.Push);
            try
            {
                await push.SendAsync(client.FcmToken, title, body,
                    new Dictionary<string, string> { { "type", type.ToString() }, { "refId", refId?.ToString() ?? "" } }, ct);
                notifLog.MarkSent();
            }
            catch (Exception ex) { notifLog.MarkFailed(ex.Message); }
            await db.NotificationLogs.AddAsync(notifLog, ct);
        }
        await uow.SaveChangesAsync(ct);
    }
}

// ── Firebase Push Notification Service ────────────────────────────────────────
public class FirebasePushService(IConfiguration config, ILogger<FirebasePushService> log)
    : IPushNotificationService
{
    private static bool _initialized;
    private static readonly object _lock = new();

    private void EnsureInitialized()
    {
        lock (_lock)
        {
            if (_initialized) return;
            var credPath = config["Firebase:CredentialPath"];
            if (!string.IsNullOrEmpty(credPath) && File.Exists(credPath))
            {
                FirebaseApp.Create(new AppOptions { Credential = GoogleCredential.FromFile(credPath) });
                _initialized = true;
            }
        }
    }

    public async Task SendAsync(string fcmToken, string title, string body,
        Dictionary<string, string>? data = null, CancellationToken ct = default)
    {
        EnsureInitialized();
        if (!_initialized) { log.LogWarning("Firebase not initialized, skipping push."); return; }

        try
        {
            var msg = new Message
            {
                Token = fcmToken,
                Notification = new Notification { Title = title, Body = body },
                Data = data,
                Android = new AndroidConfig { Priority = Priority.High },
                Apns = new ApnsConfig { Aps = new Aps { Sound = "default", Badge = 1 } }
            };
            var result = await FirebaseMessaging.DefaultInstance.SendAsync(msg, ct);
            log.LogDebug("FCM sent: {MessageId}", result);
        }
        catch (Exception ex)
        {
            log.LogError(ex, "FCM send failed for token {Token}", fcmToken[..Math.Min(10, fcmToken.Length)]);
            throw;
        }
    }

    public async Task SendMulticastAsync(IEnumerable<string> tokens, string title, string body,
        Dictionary<string, string>? data = null, CancellationToken ct = default)
    {
        EnsureInitialized();
        if (!_initialized) return;

        var tokenList = tokens.ToList();
        if (!tokenList.Any()) return;

        var msg = new MulticastMessage
        {
            Tokens = tokenList,
            Notification = new Notification { Title = title, Body = body },
            Data = data
        };
        var result = await FirebaseMessaging.DefaultInstance.SendEachForMulticastAsync(msg, ct);
        log.LogInformation("Multicast FCM: {Success}/{Total}", result.SuccessCount, tokenList.Count);
    }
}

// ── SendGrid Email Service ─────────────────────────────────────────────────────
public class SendGridEmailService(IConfiguration config, ILogger<SendGridEmailService> log)
    : IEmailService
{
    private readonly string _apiKey = config["SendGrid:ApiKey"] ?? "";
    private readonly string _fromEmail = config["SendGrid:FromEmail"] ?? "noreply@queuemaster.pro";
    private readonly string _fromName = "QueueMaster Pro";

    public async Task SendAsync(string to, string subject, string htmlBody, CancellationToken ct = default)
    {
        if (string.IsNullOrEmpty(_apiKey)) { log.LogWarning("SendGrid not configured, skipping email."); return; }
        var client = new SendGrid.SendGridClient(_apiKey);
        var msg = new SendGrid.Helpers.Mail.SendGridMessage
        {
            From = new SendGrid.Helpers.Mail.EmailAddress(_fromEmail, _fromName),
            Subject = subject,
            HtmlContent = htmlBody
        };
        msg.AddTo(new SendGrid.Helpers.Mail.EmailAddress(to));
        var resp = await client.SendEmailAsync(msg, ct);
        if (!resp.IsSuccessStatusCode)
            log.LogWarning("SendGrid {Status} for {Email}", resp.StatusCode, to);
    }

    public async Task SendTicketConfirmationAsync(string to, string name, string ticketNumber,
        string serviceName, int position, int estimatedWait, CancellationToken ct = default)
    {
        var html = $"""
        <div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto">
          <div style="background:#1E3A5F;padding:24px;border-radius:8px 8px 0 0">
            <h1 style="color:#fff;margin:0;font-size:22px">QueueMaster Pro</h1>
          </div>
          <div style="background:#f8f9fa;padding:24px;border-radius:0 0 8px 8px">
            <p style="color:#333">Bonjour <strong>{name}</strong>,</p>
            <p style="color:#333">Votre ticket a été créé avec succès.</p>
            <div style="background:#fff;border-left:4px solid #1E3A5F;padding:16px;margin:16px 0;border-radius:4px">
              <p style="margin:4px 0;color:#555">Numéro : <strong style="color:#1E3A5F;font-size:24px">{ticketNumber}</strong></p>
              <p style="margin:4px 0;color:#555">Service : {serviceName}</p>
              <p style="margin:4px 0;color:#555">Position : #{position}</p>
              <p style="margin:4px 0;color:#555">Attente estimée : ~{estimatedWait} min</p>
            </div>
            <p style="color:#555;font-size:13px">Vous recevrez une notification dès que votre tour arrive.</p>
            <p style="color:#999;font-size:12px">QueueMaster Pro — Merci de votre confiance.</p>
          </div>
        </div>
        """;
        await SendAsync(to, $"Ticket {ticketNumber} — Confirmation", html, ct);
    }

    public async Task SendTicketCalledAsync(string to, string name, string ticketNumber,
        string counter, CancellationToken ct = default)
    {
        var html = $"""
        <div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto">
          <div style="background:#BA7517;padding:24px;border-radius:8px 8px 0 0">
            <h1 style="color:#fff;margin:0;font-size:22px">C'est votre tour !</h1>
          </div>
          <div style="background:#f8f9fa;padding:24px;border-radius:0 0 8px 8px">
            <p style="color:#333">Bonjour <strong>{name}</strong>,</p>
            <div style="background:#fff;border-left:4px solid #BA7517;padding:16px;margin:16px 0;border-radius:4px">
              <p style="margin:4px 0;color:#555">Ticket : <strong style="color:#BA7517;font-size:24px">{ticketNumber}</strong></p>
              <p style="margin:4px 0;color:#555">Veuillez vous présenter au <strong>Guichet {counter}</strong></p>
            </div>
            <p style="color:#e53e3e;font-weight:bold">Présentez-vous immédiatement, sinon votre ticket sera annulé.</p>
          </div>
        </div>
        """;
        await SendAsync(to, $"Ticket {ticketNumber} — Appelé au guichet {counter}", html, ct);
    }

    public async Task SendTicketServedAsync(string to, string name, string ticketNumber,
        string serviceName, CancellationToken ct = default)
    {
        var html = $"""
        <div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto">
          <div style="background:#27500A;padding:24px;border-radius:8px 8px 0 0">
            <h1 style="color:#fff;margin:0;font-size:22px">Service terminé — Merci !</h1>
          </div>
          <div style="background:#f8f9fa;padding:24px;border-radius:0 0 8px 8px">
            <p style="color:#333">Bonjour <strong>{name}</strong>,</p>
            <p style="color:#333">Votre demande <strong>{ticketNumber}</strong> au service <strong>{serviceName}</strong> a été traitée avec succès.</p>
            <p style="color:#555;font-size:13px">Merci de votre visite. À bientôt !</p>
          </div>
        </div>
        """;
        await SendAsync(to, $"Ticket {ticketNumber} — Service terminé", html, ct);
    }

    public async Task SendAppointmentConfirmationAsync(string to, string name, string serviceName,
        DateTime scheduledAt, string qrCode, CancellationToken ct = default)
    {
        var html = $"""
        <div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto">
          <div style="background:#1E3A5F;padding:24px;border-radius:8px 8px 0 0">
            <h1 style="color:#fff;margin:0;font-size:22px">Rendez-vous confirmé</h1>
          </div>
          <div style="background:#f8f9fa;padding:24px;border-radius:0 0 8px 8px">
            <p style="color:#333">Bonjour <strong>{name}</strong>,</p>
            <p style="color:#333">Votre rendez-vous a été confirmé.</p>
            <div style="background:#fff;border-left:4px solid #1E3A5F;padding:16px;margin:16px 0;border-radius:4px">
              <p style="margin:4px 0;color:#555">Service : <strong>{serviceName}</strong></p>
              <p style="margin:4px 0;color:#555">Date : <strong>{scheduledAt:dddd dd MMMM yyyy}</strong></p>
              <p style="margin:4px 0;color:#555">Heure : <strong>{scheduledAt:HH:mm}</strong></p>
              <p style="margin:4px 0;color:#555">Code QR : <strong style="color:#1E3A5F;font-size:20px;letter-spacing:3px">{qrCode}</strong></p>
            </div>
            <p style="color:#555;font-size:13px">Présentez ce code à l'accueil le jour de votre rendez-vous.</p>
          </div>
        </div>
        """;
        await SendAsync(to, $"Confirmation RDV — {serviceName}", html, ct);
    }

    public async Task SendAppointmentReminderAsync(string to, string name, string serviceName,
        DateTime scheduledAt, int hoursAhead, CancellationToken ct = default)
    {
        var subject = hoursAhead == 24
            ? $"Rappel RDV demain — {serviceName}"
            : $"Rappel RDV dans {hoursAhead}h — {serviceName}";
        var html = $"""
        <div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto">
          <div style="background:#1E3A5F;padding:20px;border-radius:8px 8px 0 0">
            <h2 style="color:#fff;margin:0">Rappel de rendez-vous</h2>
          </div>
          <div style="background:#f8f9fa;padding:20px">
            <p>Bonjour <strong>{name}</strong>, n'oubliez pas votre rendez-vous :</p>
            <p><strong>{serviceName}</strong> — {scheduledAt:dd/MM/yyyy à HH:mm}</p>
            <p style="color:#555;font-size:13px">QueueMaster Pro</p>
          </div>
        </div>
        """;
        await SendAsync(to, subject, html, ct);
    }
}
