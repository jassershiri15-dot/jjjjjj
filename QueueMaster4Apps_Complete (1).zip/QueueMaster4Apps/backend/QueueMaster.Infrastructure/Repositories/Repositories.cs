using Microsoft.EntityFrameworkCore;
using QueueMaster.Domain.Entities;
using QueueMaster.Domain.Enums;
using QueueMaster.Domain.Interfaces;
using QueueMaster.Infrastructure.Persistence;

namespace QueueMaster.Infrastructure.Repositories;

public abstract class BaseRepository<T>(AppDbContext db) : IRepository<T> where T : class
{
    protected readonly AppDbContext Db = db;
    protected abstract DbSet<T> DbSet { get; }

    public async Task<T?> GetByIdAsync(Guid id, CancellationToken ct = default)
        => await DbSet.FindAsync(new object[] { id }, ct);
    public async Task<IReadOnlyList<T>> GetAllAsync(CancellationToken ct = default)
        => await DbSet.ToListAsync(ct);
    public async Task AddAsync(T entity, CancellationToken ct = default)
        => await DbSet.AddAsync(entity, ct);
    public void Update(T entity) => DbSet.Update(entity);
    public void Remove(T entity) => DbSet.Remove(entity);
}

// ── Ticket Repository ─────────────────────────────────────────────────────────
public class TicketRepository(AppDbContext db) : BaseRepository<Ticket>(db), ITicketRepository
{
    protected override DbSet<Ticket> DbSet => Db.Tickets;

    public async Task<IReadOnlyList<Ticket>> GetByServiceAsync(Guid serviceId,
        TicketStatus? status = null, CancellationToken ct = default)
    {
        var q = Db.Tickets.Include(t => t.Client).Where(t => t.ServiceId == serviceId);
        if (status.HasValue) q = q.Where(t => t.Status == status.Value);
        return await q.OrderBy(t => t.Priority).ThenBy(t => t.CreatedAt).ToListAsync(ct);
    }

    public async Task<IReadOnlyList<Ticket>> GetByClientAsync(Guid clientId, CancellationToken ct = default)
        => await Db.Tickets.Include(t => t.Service)
            .Where(t => t.ClientId == clientId).OrderByDescending(t => t.CreatedAt).ToListAsync(ct);

    public async Task<Ticket?> GetNextWaitingAsync(Guid serviceId, CancellationToken ct = default)
        => await Db.Tickets
            .Where(t => t.ServiceId == serviceId && t.Status == TicketStatus.Waiting)
            .OrderBy(t => t.Priority).ThenBy(t => t.CreatedAt).FirstOrDefaultAsync(ct);

    public async Task<int> GetPositionAsync(Guid ticketId, CancellationToken ct = default)
    {
        var ticket = await Db.Tickets.FindAsync(new object[] { ticketId }, ct);
        if (ticket is null || ticket.Status != TicketStatus.Waiting) return 0;
        return await Db.Tickets.CountAsync(t =>
            t.ServiceId == ticket.ServiceId && t.Status == TicketStatus.Waiting &&
            (t.Priority < ticket.Priority ||
             (t.Priority == ticket.Priority && t.CreatedAt < ticket.CreatedAt)), ct) + 1;
    }

    public async Task<string> GenerateTicketNumberAsync(Guid serviceId, CancellationToken ct = default)
    {
        var today = DateTime.UtcNow.Date;
        var count = await Db.Tickets
            .CountAsync(t => t.ServiceId == serviceId && t.CreatedAt.Date == today, ct);
        var service = await Db.Services.FindAsync(new object[] { serviceId }, ct);
        var prefix = service?.Name?.Substring(0, 1).ToUpper() ?? "T";
        return $"{prefix}{(count + 1):D3}";
    }

    public async Task<QueueStats> GetQueueStatsAsync(Guid serviceId, CancellationToken ct = default)
    {
        var today = DateTime.UtcNow.Date;
        var waiting = await Db.Tickets
            .CountAsync(t => t.ServiceId == serviceId && t.Status == TicketStatus.Waiting, ct);
        var served = await Db.Tickets
            .CountAsync(t => t.ServiceId == serviceId && t.Status == TicketStatus.Served
                             && t.ServedAt.HasValue && t.ServedAt.Value.Date == today, ct);
        var avg = await Db.Tickets
            .Where(t => t.ServiceId == serviceId && t.ActualWaitMinutes.HasValue && t.CreatedAt.Date == today)
            .AverageAsync(t => (double?)t.ActualWaitMinutes ?? 0, ct);
        var agents = await Db.ServiceAgents.Include(sa => sa.Agent)
            .CountAsync(sa => sa.ServiceId == serviceId && sa.Agent!.Status == AgentStatus.Active, ct);
        return new QueueStats(waiting, served, Math.Round(avg, 1), agents);
    }

    public async Task<IReadOnlyList<Ticket>> GetWaitingOrderedAsync(Guid serviceId, CancellationToken ct = default)
        => await Db.Tickets
            .Where(t => t.ServiceId == serviceId && t.Status == TicketStatus.Waiting)
            .OrderBy(t => t.Priority).ThenBy(t => t.CreatedAt).ToListAsync(ct);
}

// ── Client Repository ─────────────────────────────────────────────────────────
public class ClientRepository(AppDbContext db) : BaseRepository<Client>(db), IClientRepository
{
    protected override DbSet<Client> DbSet => Db.Clients;

    public async Task<Client?> GetByEmailAsync(string email, CancellationToken ct = default)
        => await Db.Clients.FirstOrDefaultAsync(c => c.Email == email.ToLowerInvariant(), ct);

    public async Task<IReadOnlyList<Client>> GetAllActiveAsync(CancellationToken ct = default)
        => await Db.Clients.Where(c => c.IsActive).ToListAsync(ct);
}

// ── Service Repository ────────────────────────────────────────────────────────
public class ServiceRepository(AppDbContext db) : BaseRepository<Service>(db), IServiceRepository
{
    protected override DbSet<Service> DbSet => Db.Services;

    public async Task<IReadOnlyList<Service>> GetActiveServicesAsync(CancellationToken ct = default)
        => await Db.Services.Where(s => s.IsActive).OrderBy(s => s.Name).ToListAsync(ct);

    public async Task<int> GetEstimatedWaitAsync(Guid serviceId, CancellationToken ct = default)
    {
        var service = await Db.Services.FindAsync(new object[] { serviceId }, ct);
        if (service is null) return 0;
        var waiting = await Db.Tickets
            .CountAsync(t => t.ServiceId == serviceId && t.Status == TicketStatus.Waiting, ct);
        var agents = await Db.ServiceAgents.Include(sa => sa.Agent)
            .CountAsync(sa => sa.ServiceId == serviceId && sa.Agent!.Status == AgentStatus.Active, ct);
        return agents > 0
            ? (int)Math.Ceiling((double)waiting / agents * service.AverageServiceMinutes)
            : waiting * service.AverageServiceMinutes;
    }
}

// ── Agent Repository ──────────────────────────────────────────────────────────
public class AgentRepository(AppDbContext db) : BaseRepository<Agent>(db), IAgentRepository
{
    protected override DbSet<Agent> DbSet => Db.Agents;

    public async Task<IReadOnlyList<Agent>> GetByServiceAsync(Guid serviceId, CancellationToken ct = default)
        => await Db.ServiceAgents.Include(sa => sa.Agent)
            .Where(sa => sa.ServiceId == serviceId)
            .Select(sa => sa.Agent!).ToListAsync(ct);

    public async Task<Agent?> GetByUserIdAsync(string userId, CancellationToken ct = default)
        => await Db.Agents.FirstOrDefaultAsync(a => a.UserId == userId, ct);

    public async Task<IReadOnlyList<Agent>> GetActiveAgentsAsync(CancellationToken ct = default)
        => await Db.Agents.Where(a => a.Status == AgentStatus.Active).ToListAsync(ct);
}

// ── Appointment Repository ────────────────────────────────────────────────────
public class AppointmentRepository(AppDbContext db) : BaseRepository<Appointment>(db), IAppointmentRepository
{
    protected override DbSet<Appointment> DbSet => Db.Appointments;

    public async Task<IReadOnlyList<Appointment>> GetByDateAsync(DateTime date, CancellationToken ct = default)
        => await Db.Appointments.Include(a => a.Client).Include(a => a.Service)
            .Where(a => a.ScheduledAt.Date == date.Date).OrderBy(a => a.ScheduledAt).ToListAsync(ct);

    public async Task<IReadOnlyList<DateTime>> GetAvailableSlotsAsync(Guid serviceId, DateTime date, CancellationToken ct = default)
    {
        var service = await Db.Services.FindAsync(new object[] { serviceId }, ct);
        if (service is null) return [];
        var taken = await Db.Appointments
            .Where(a => a.ServiceId == serviceId && a.ScheduledAt.Date == date.Date
                        && a.Status != AppointmentStatus.Cancelled)
            .Select(a => a.ScheduledAt).ToListAsync(ct);
        var slots = new List<DateTime>();
        var current = date.Date + service.OpenTime;
        var close = date.Date + service.CloseTime;
        while (current < close)
        {
            if (!taken.Any(t => Math.Abs((t - current).TotalMinutes) < 30))
                slots.Add(current);
            current = current.AddMinutes(30);
        }
        return slots;
    }

    public async Task<Appointment?> GetByQrCodeAsync(string qrCode, CancellationToken ct = default)
        => await Db.Appointments.Include(a => a.Client).Include(a => a.Service)
            .FirstOrDefaultAsync(a => a.QrCode == qrCode, ct);

    public async Task<IReadOnlyList<Appointment>> GetUpcomingByClientAsync(Guid clientId, CancellationToken ct = default)
        => await Db.Appointments.Include(a => a.Service)
            .Where(a => a.ClientId == clientId && a.ScheduledAt >= DateTime.UtcNow
                        && a.Status == AppointmentStatus.Confirmed)
            .OrderBy(a => a.ScheduledAt).ToListAsync(ct);
}

// ── Notification Repository ───────────────────────────────────────────────────
public class NotificationRepository(AppDbContext db) : BaseRepository<NotificationLog>(db), INotificationRepository
{
    protected override DbSet<NotificationLog> DbSet => Db.NotificationLogs;

    public async Task<IReadOnlyList<NotificationLog>> GetByClientAsync(Guid clientId, CancellationToken ct = default)
        => await Db.NotificationLogs.Where(n => n.ClientId == clientId)
            .OrderByDescending(n => n.CreatedAt).Take(50).ToListAsync(ct);
}
