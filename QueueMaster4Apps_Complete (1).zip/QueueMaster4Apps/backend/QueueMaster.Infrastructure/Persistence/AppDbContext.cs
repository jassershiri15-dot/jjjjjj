using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using QueueMaster.Domain.Entities;
using QueueMaster.Domain.Enums;
using QueueMaster.Domain.Interfaces;

namespace QueueMaster.Infrastructure.Persistence;

public class AppDbContext : IdentityDbContext<AppUser>, IUnitOfWork
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    public DbSet<Ticket> Tickets => Set<Ticket>();
    public DbSet<Client> Clients => Set<Client>();
    public DbSet<Service> Services => Set<Service>();
    public DbSet<Agent> Agents => Set<Agent>();
    public DbSet<ServiceAgent> ServiceAgents => Set<ServiceAgent>();
    public DbSet<Appointment> Appointments => Set<Appointment>();
    public DbSet<NotificationLog> NotificationLogs => Set<NotificationLog>();

    protected override void OnModelCreating(ModelBuilder b)
    {
        base.OnModelCreating(b);

        b.Entity<Ticket>(e => {
            e.HasKey(x => x.Id);
            e.Property(x => x.TicketNumber).HasMaxLength(20).IsRequired();
            e.Property(x => x.Priority).HasConversion<int>();
            e.Property(x => x.Status).HasConversion<int>();
            e.HasIndex(x => new { x.ServiceId, x.Status });
            e.HasOne(x => x.Client).WithMany(c => c.Tickets)
                .HasForeignKey(x => x.ClientId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.Service).WithMany(s => s.Tickets)
                .HasForeignKey(x => x.ServiceId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.AssignedAgent).WithMany(a => a.ServedTickets)
                .HasForeignKey(x => x.AssignedAgentId).OnDelete(DeleteBehavior.SetNull);
        });

        b.Entity<Client>(e => {
            e.HasKey(x => x.Id);
            e.Property(x => x.FullName).HasMaxLength(100).IsRequired();
            e.Property(x => x.Email).HasMaxLength(200).IsRequired();
            e.HasIndex(x => x.Email).IsUnique();
        });

        b.Entity<Service>(e => {
            e.HasKey(x => x.Id);
            e.Property(x => x.Name).HasMaxLength(100).IsRequired();
        });

        b.Entity<Agent>(e => {
            e.HasKey(x => x.Id);
            e.Property(x => x.Status).HasConversion<int>();
            e.HasIndex(x => x.UserId).IsUnique();
        });

        b.Entity<ServiceAgent>(e => {
            e.HasKey(x => new { x.ServiceId, x.AgentId });
            e.HasOne(x => x.Service).WithMany(s => s.ServiceAgents).HasForeignKey(x => x.ServiceId);
            e.HasOne(x => x.Agent).WithMany(a => a.ServiceAgents).HasForeignKey(x => x.AgentId);
        });

        b.Entity<Appointment>(e => {
            e.HasKey(x => x.Id);
            e.Property(x => x.Status).HasConversion<int>();
            e.HasIndex(x => x.QrCode).IsUnique();
            e.HasOne(x => x.Client).WithMany(c => c.Appointments)
                .HasForeignKey(x => x.ClientId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.Service).WithMany()
                .HasForeignKey(x => x.ServiceId).OnDelete(DeleteBehavior.Restrict);
        });

        b.Entity<NotificationLog>(e => {
            e.HasKey(x => x.Id);
            e.Property(x => x.Type).HasConversion<int>();
            e.Property(x => x.Channel).HasConversion<int>();
            e.HasIndex(x => new { x.ClientId, x.IsSent });
        });

        // Seed
        var caisse = Service.Create("Caisse", "Paiements et opérations de caisse", 50, 8,
            new TimeSpan(8,0,0), new TimeSpan(17,0,0), "#1E3A5F");
        var rh = Service.Create("Ressources Humaines", "Démarches administratives RH", 30, 15,
            new TimeSpan(8,30,0), new TimeSpan(16,30,0), "#0F6E56");
        var tech = Service.Create("Support Technique", "Assistance informatique et technique", 40, 10,
            new TimeSpan(8,0,0), new TimeSpan(17,0,0), "#854F0B");
        b.Entity<Service>().HasData(caisse, rh, tech);
    }

    public override async Task<int> SaveChangesAsync(CancellationToken ct = default)
        => await base.SaveChangesAsync(ct);
}

public class AppUser : IdentityUser
{
    public string FullName { get; set; } = string.Empty;
    public string Role { get; set; } = "Client";
    public Guid? LinkedClientId { get; set; }
    public Guid? LinkedAgentId { get; set; }
}
