using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using QueueMaster.Application.DTOs;
using QueueMaster.Application.Features.Appointments.Commands;
using QueueMaster.Application.Features.Tickets.Commands;
using QueueMaster.Application.Features.Tickets.Queries;
using QueueMaster.Application.Interfaces;
using QueueMaster.Domain.Enums;
using QueueMaster.Domain.Interfaces;
using QueueMaster.Infrastructure.Persistence;
using System.Security.Claims;

namespace QueueMaster.API.Controllers;

// ── Tickets ───────────────────────────────────────────────────────────────────
[ApiController, Route("api/[controller]"), Authorize]
public class TicketsController(IMediator m) : ControllerBase
{
    [HttpPost]
    public async Task<ActionResult<TicketDto>> Create([FromBody] CreateTicketDto dto, CancellationToken ct)
    {
        var ticket = await m.Send(new CreateTicketCommand(dto.ClientId, dto.ServiceId, dto.Priority), ct);
        return CreatedAtAction(nameof(GetPosition), new { id = ticket.Id }, ticket);
    }

    [HttpGet("{id:guid}/position")]
    public async Task<ActionResult<TicketPositionDto>> GetPosition(Guid id, CancellationToken ct)
        => Ok(await m.Send(new GetTicketPositionQuery(id), ct));

    [HttpDelete("{id:guid}")]
    public async Task<IActionResult> Cancel(Guid id, CancellationToken ct)
    {
        var clientId = GetClientId();
        await m.Send(new CancelTicketCommand(id, clientId), ct);
        return NoContent();
    }

    [HttpPost("call-next"), Authorize(Roles = "Agent,Admin")]
    public async Task<ActionResult<TicketDto?>> CallNext([FromBody] CallNextDto dto, CancellationToken ct)
    {
        var agentId = GetAgentId();
        var result = await m.Send(new CallNextTicketCommand(dto.ServiceId, agentId), ct);
        return result is null ? NoContent() : Ok(result);
    }

    [HttpPost("{id:guid}/serve"), Authorize(Roles = "Agent,Admin")]
    public async Task<IActionResult> Serve(Guid id, [FromBody] ServeTicketDto? dto, CancellationToken ct)
    {
        await m.Send(new ServeTicketCommand(id, dto?.Notes), ct);
        return NoContent();
    }

    [HttpPost("{id:guid}/no-show"), Authorize(Roles = "Agent,Admin")]
    public async Task<IActionResult> NoShow(Guid id, CancellationToken ct)
    {
        await m.Send(new MarkNoShowCommand(id), ct);
        return NoContent();
    }

    private Guid GetClientId()
    {
        var v = User.FindFirst("clientId")?.Value;
        return Guid.TryParse(v, out var id) ? id : Guid.Empty;
    }
    private Guid GetAgentId()
    {
        var v = User.FindFirst("agentId")?.Value;
        return Guid.TryParse(v, out var id) ? id : Guid.Empty;
    }
}

// ── Queues ────────────────────────────────────────────────────────────────────
[ApiController, Route("api/[controller]"), Authorize]
public class QueuesController(IMediator m) : ControllerBase
{
    [HttpGet("{serviceId:guid}")]
    public async Task<ActionResult<IReadOnlyList<TicketDto>>> GetQueue(
        Guid serviceId, [FromQuery] TicketStatus? status, CancellationToken ct)
        => Ok(await m.Send(new GetQueueQuery(serviceId, status), ct));

    [HttpGet("{serviceId:guid}/stats")]
    public async Task<ActionResult<QueueStatsDto>> GetStats(Guid serviceId, CancellationToken ct)
        => Ok(await m.Send(new GetQueueStatsQuery(serviceId), ct));
}

// ── Services ──────────────────────────────────────────────────────────────────
[ApiController, Route("api/[controller]")]
public class ServicesController(IServiceRepository services, IAppointmentRepository appointments)
    : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<IReadOnlyList<ServiceDto>>> GetAll(CancellationToken ct)
    {
        var list = await services.GetActiveServicesAsync(ct);
        var result = new List<ServiceDto>();
        foreach (var s in list)
        {
            var wait = await services.GetEstimatedWaitAsync(s.Id, ct);
            result.Add(new ServiceDto(s.Id, s.Name, s.Description, s.MaxCapacity,
                s.AverageServiceMinutes, s.IsActive,
                s.OpenTime.ToString(@"hh\:mm"), s.CloseTime.ToString(@"hh\:mm"),
                s.Color, wait, 0));
        }
        return Ok(result);
    }

    [HttpGet("{serviceId:guid}/slots")]
    public async Task<ActionResult<IReadOnlyList<DateTime>>> GetSlots(
        Guid serviceId, [FromQuery] DateTime date, CancellationToken ct)
        => Ok(await appointments.GetAvailableSlotsAsync(serviceId, date, ct));
}

// ── Appointments ──────────────────────────────────────────────────────────────
[ApiController, Route("api/[controller]"), Authorize]
public class AppointmentsController(IMediator m, IAppointmentRepository repo) : ControllerBase
{
    [HttpPost]
    public async Task<ActionResult<AppointmentDto>> Create(
        [FromBody] CreateAppointmentDto dto, CancellationToken ct)
    {
        var result = await m.Send(new CreateAppointmentCommand(dto.ClientId, dto.ServiceId, dto.ScheduledAt), ct);
        return CreatedAtAction(nameof(GetById), new { id = result.Id }, result);
    }

    [HttpGet("{id:guid}")]
    public async Task<ActionResult<AppointmentDto>> GetById(Guid id, CancellationToken ct)
    {
        var appt = await repo.GetByIdAsync(id, ct);
        if (appt is null) return NotFound();
        return Ok(new AppointmentDto(appt.Id, appt.ClientId, appt.Client?.FullName ?? "",
            appt.Client?.Email ?? "", appt.ServiceId, appt.Service?.Name ?? "",
            appt.ScheduledAt, appt.Status, appt.QrCode));
    }

    [HttpPost("checkin")]
    public async Task<ActionResult<AppointmentDto>> CheckIn(
        [FromBody] CheckInDto dto, CancellationToken ct)
        => Ok(await m.Send(new CheckInCommand(dto.QrCode), ct));

    [HttpDelete("{id:guid}")]
    public async Task<IActionResult> Cancel(Guid id, CancellationToken ct)
    {
        var appt = await repo.GetByIdAsync(id, ct);
        if (appt is null) return NotFound();
        appt.Cancel();
        repo.Update(appt);
        return NoContent();
    }
}

// ── Agents ────────────────────────────────────────────────────────────────────
[ApiController, Route("api/[controller]"), Authorize(Roles = "Agent,Admin")]
public class AgentsController(IAgentRepository agents) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<IReadOnlyList<AgentDto>>> GetAll(CancellationToken ct)
    {
        var list = await agents.GetAllAsync(ct);
        return Ok(list.Select(a => new AgentDto(a.Id, a.FullName, a.Counter, a.Status, a.ServedToday)));
    }

    [HttpPatch("{id:guid}/status"), Authorize(Roles = "Agent,Admin")]
    public async Task<IActionResult> SetStatus(Guid id, [FromBody] SetStatusRequest req, CancellationToken ct)
    {
        var agent = await agents.GetByIdAsync(id, ct);
        if (agent is null) return NotFound();
        agent.SetStatus(req.Status);
        agents.Update(agent);
        return NoContent();
    }
}

public record SetStatusRequest(AgentStatus Status);

// ── Auth ──────────────────────────────────────────────────────────────────────
[ApiController, Route("api/[controller]")]
public class AuthController(
    UserManager<AppUser> userManager,
    SignInManager<AppUser> signIn,
    ITokenService token,
    IClientRepository clients,
    IUnitOfWork uow) : ControllerBase
{
    [HttpPost("register")]
    public async Task<ActionResult<AuthResponseDto>> Register(
        [FromBody] RegisterDto dto, CancellationToken ct)
    {
        if (await userManager.FindByEmailAsync(dto.Email) is not null)
            return Conflict("Email already in use.");

        var user = new AppUser
        {
            UserName = dto.Email, Email = dto.Email, FullName = dto.FullName, Role = "Client"
        };
        var result = await userManager.CreateAsync(user, dto.Password);
        if (!result.Succeeded)
            return BadRequest(result.Errors.Select(e => e.Description));

        await userManager.AddToRoleAsync(user, "Client");

        var client = QueueMaster.Domain.Entities.Client.Create(dto.FullName, dto.Email, dto.Phone);
        await clients.AddAsync(client, ct);
        user.LinkedClientId = client.Id;
        await userManager.UpdateAsync(user);
        await uow.SaveChangesAsync(ct);

        var access = token.GenerateAccessToken(user.Id, user.Email!, "Client", client.Id);
        var refresh = token.GenerateRefreshToken();
        token.StoreRefreshToken(user.Id, refresh);

        return Ok(new AuthResponseDto(access, refresh, 900, "Client", client.Id, null));
    }

    [HttpPost("login")]
    public async Task<ActionResult<AuthResponseDto>> Login([FromBody] LoginDto dto)
    {
        var user = await userManager.FindByEmailAsync(dto.Email);
        if (user is null) return Unauthorized("Invalid credentials.");

        var result = await signIn.CheckPasswordSignInAsync(user, dto.Password, true);
        if (!result.Succeeded)
        {
            if (result.IsLockedOut) return StatusCode(429, "Account temporarily locked.");
            return Unauthorized("Invalid credentials.");
        }

        var roles = await userManager.GetRolesAsync(user);
        var role = roles.FirstOrDefault() ?? "Client";
        var access = token.GenerateAccessToken(user.Id, user.Email!, role,
            user.LinkedClientId, user.LinkedAgentId);
        var refresh = token.GenerateRefreshToken();
        token.StoreRefreshToken(user.Id, refresh);

        return Ok(new AuthResponseDto(access, refresh, 900, role,
            user.LinkedClientId, user.LinkedAgentId));
    }

    [HttpPost("refresh")]
    public async Task<ActionResult<AuthResponseDto>> Refresh([FromBody] RefreshTokenDto dto)
    {
        var user = await userManager.FindByIdAsync(dto.UserId);
        if (user is null || !token.ValidateRefreshToken(dto.UserId, dto.RefreshToken))
            return Unauthorized();

        var roles = await userManager.GetRolesAsync(user);
        var role = roles.FirstOrDefault() ?? "Client";
        var access = token.GenerateAccessToken(user.Id, user.Email!, role,
            user.LinkedClientId, user.LinkedAgentId);
        var newRefresh = token.GenerateRefreshToken();
        token.StoreRefreshToken(user.Id, newRefresh);

        return Ok(new AuthResponseDto(access, newRefresh, 900, role,
            user.LinkedClientId, user.LinkedAgentId));
    }

    [HttpPost("fcm-token"), Authorize]
    public async Task<IActionResult> UpdateFcmToken([FromBody] UpdateFcmTokenDto dto, CancellationToken ct)
    {
        var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
        var user = await userManager.FindByIdAsync(userId!);
        if (user?.LinkedClientId is null) return BadRequest();

        var client = await clients.GetByIdAsync(user.LinkedClientId.Value, ct);
        if (client is null) return NotFound();
        client.UpdateFcmToken(dto.FcmToken);
        clients.Update(client);
        await uow.SaveChangesAsync(ct);
        return NoContent();
    }
}

public record RefreshTokenDto(string UserId, string RefreshToken);
