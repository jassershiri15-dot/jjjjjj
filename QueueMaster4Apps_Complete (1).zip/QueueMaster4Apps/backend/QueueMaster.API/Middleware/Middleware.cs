// ── Exception Middleware ──────────────────────────────────────────────────────
using System.IdentityModel.Tokens.Jwt;
using System.Net;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.IdentityModel.Tokens;
using QueueMaster.Application.Interfaces;

namespace QueueMaster.API.Middleware;

public class ExceptionMiddleware(RequestDelegate next, ILogger<ExceptionMiddleware> log)
{
    public async Task InvokeAsync(HttpContext ctx)
    {
        try { await next(ctx); }
        catch (KeyNotFoundException ex) { await Write(ctx, 404, ex.Message); }
        catch (UnauthorizedAccessException ex) { await Write(ctx, 403, ex.Message); }
        catch (InvalidOperationException ex) { await Write(ctx, 400, ex.Message); }
        catch (FluentValidation.ValidationException ex)
            { await Write(ctx, 422, "Validation failed", ex.Errors.Select(e => e.ErrorMessage)); }
        catch (Exception ex)
        {
            log.LogError(ex, "Unhandled exception");
            await Write(ctx, 500, "An unexpected error occurred.");
        }
    }

    private static async Task Write(HttpContext ctx, int code, string msg,
        IEnumerable<string>? errors = null)
    {
        ctx.Response.StatusCode = code;
        ctx.Response.ContentType = "application/json";
        await ctx.Response.WriteAsync(JsonSerializer.Serialize(
            new { status = code, message = msg, errors, timestamp = DateTime.UtcNow },
            new JsonSerializerOptions { PropertyNamingPolicy = JsonNamingPolicy.CamelCase }));
    }
}

// ── JWT Token Service ─────────────────────────────────────────────────────────
public class JwtTokenService(IConfiguration config, IMemoryCache cache) : ITokenService
{
    public string GenerateAccessToken(string userId, string email, string role,
        Guid? clientId = null, Guid? agentId = null)
    {
        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(config["Jwt:Secret"]!));
        var claims = new List<Claim>
        {
            new(JwtRegisteredClaimNames.Sub, userId),
            new(JwtRegisteredClaimNames.Email, email),
            new(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
            new(ClaimTypes.Role, role),
            new("uid", userId)
        };
        if (clientId.HasValue) claims.Add(new("clientId", clientId.Value.ToString()));
        if (agentId.HasValue) claims.Add(new("agentId", agentId.Value.ToString()));

        var token = new JwtSecurityToken(
            issuer: config["Jwt:Issuer"],
            audience: config["Jwt:Audience"],
            claims: claims,
            expires: DateTime.UtcNow.AddMinutes(15),
            signingCredentials: new SigningCredentials(key, SecurityAlgorithms.HmacSha256));

        return new JwtSecurityTokenHandler().WriteToken(token);
    }

    public string GenerateRefreshToken()
    {
        var bytes = new byte[64];
        using var rng = RandomNumberGenerator.Create();
        rng.GetBytes(bytes);
        return Convert.ToBase64String(bytes);
    }

    public bool ValidateRefreshToken(string userId, string refreshToken)
    {
        var stored = cache.Get<string>($"refresh:{userId}");
        return stored == refreshToken;
    }

    public void StoreRefreshToken(string userId, string refreshToken)
        => cache.Set($"refresh:{userId}", refreshToken, TimeSpan.FromDays(7));

    public void RevokeRefreshToken(string userId)
        => cache.Remove($"refresh:{userId}");
}
