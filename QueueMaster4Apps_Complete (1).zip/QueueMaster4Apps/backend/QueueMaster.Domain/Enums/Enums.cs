namespace QueueMaster.Domain.Enums;

public enum TicketStatus   { Waiting = 1, Calling = 2, Served = 3, Cancelled = 4, NoShow = 5 }
public enum TicketPriority { Emergency = 1, Priority = 2, VIP = 3, Standard = 4 }
public enum AgentStatus    { Offline = 0, Active = 1, OnBreak = 2, Busy = 3 }
public enum AppointmentStatus { Pending=1, Confirmed=2, Arrived=3, Completed=4, Cancelled=5, NoShow=6 }
public enum NotificationType  { TicketCreated=1, PositionReminder=2, TicketCalled=3,
                                 TicketServed=4, AppointmentReminder=5, AppointmentConfirmed=6, NoShow=7 }
public enum NotificationChannel { Push = 1, Email = 2, SMS = 3 }
