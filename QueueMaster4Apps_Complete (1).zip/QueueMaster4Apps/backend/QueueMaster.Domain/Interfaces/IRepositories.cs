using QueueMaster.Domain.Entities;
using QueueMaster.Domain.Enums;

namespace QueueMaster.Domain.Interfaces;

public interface IRepository<T> where T : class
{
    Task<T?> GetByIdAsync(Guid id, CancellationToken ct = default);
    Task<IReadOnlyList<T>> GetAllAsync(CancellationToken ct = default);
    Task AddAsync(T entity, CancellationToken ct = default);
    void Update(T entity);
    void Remove(T entity);
}

public interface IUnitOfWork
{
    Task<int> SaveChangesAsync(CancellationToken ct = default);
}

public interface ITicketRepository : IRepository<Ticket>
{
    Task<IReadOnlyList<Ticket>> GetByServiceAsync(Guid serviceId, TicketStatus? status = null, CancellationToken ct = default);
    Task<IReadOnlyList<Ticket>> GetByClientAsync(Guid clientId, CancellationToken ct = default);
    Task<Ticket?> GetNextWaitingAsync(Guid serviceId, CancellationToken ct = default);
    Task<int> GetPositionAsync(Guid ticketId, CancellationToken ct = default);
    Task<string> GenerateTicketNumberAsync(Guid serviceId, CancellationToken ct = default);
    Task<QueueStats> GetQueueStatsAsync(Guid serviceId, CancellationToken ct = default);
    Task<IReadOnlyList<Ticket>> GetWaitingOrderedAsync(Guid serviceId, CancellationToken ct = default);
}

public interface IClientRepository : IRepository<Client>
{
    Task<Client?> GetByEmailAsync(string email, CancellationToken ct = default);
    Task<IReadOnlyList<Client>> GetAllActiveAsync(CancellationToken ct = default);
}

public interface IServiceRepository : IRepository<Service>
{
    Task<IReadOnlyList<Service>> GetActiveServicesAsync(CancellationToken ct = default);
    Task<int> GetEstimatedWaitAsync(Guid serviceId, CancellationToken ct = default);
}

public interface IAgentRepository : IRepository<Agent>
{
    Task<IReadOnlyList<Agent>> GetByServiceAsync(Guid serviceId, CancellationToken ct = default);
    Task<Agent?> GetByUserIdAsync(string userId, CancellationToken ct = default);
    Task<IReadOnlyList<Agent>> GetActiveAgentsAsync(CancellationToken ct = default);
}

public interface IAppointmentRepository : IRepository<Appointment>
{
    Task<IReadOnlyList<Appointment>> GetByDateAsync(DateTime date, CancellationToken ct = default);
    Task<IReadOnlyList<DateTime>> GetAvailableSlotsAsync(Guid serviceId, DateTime date, CancellationToken ct = default);
    Task<Appointment?> GetByQrCodeAsync(string qrCode, CancellationToken ct = default);
    Task<IReadOnlyList<Appointment>> GetUpcomingByClientAsync(Guid clientId, CancellationToken ct = default);
}

public interface INotificationRepository : IRepository<NotificationLog>
{
    Task<IReadOnlyList<NotificationLog>> GetByClientAsync(Guid clientId, CancellationToken ct = default);
}

public record QueueStats(int TotalWaiting, int TotalServedToday, double AverageWaitMinutes, int ActiveAgents);
