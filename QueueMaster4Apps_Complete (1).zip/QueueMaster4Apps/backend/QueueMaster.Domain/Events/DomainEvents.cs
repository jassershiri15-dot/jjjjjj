namespace QueueMaster.Domain.Events;

public interface IDomainEvent
{
    Guid EventId { get; }
    DateTime OccurredAt { get; }
}

public abstract record DomainEvent : IDomainEvent
{
    public Guid EventId { get; } = Guid.NewGuid();
    public DateTime OccurredAt { get; } = DateTime.UtcNow;
}

public record TicketCreatedEvent(
    Guid TicketId, Guid ClientId, Guid ServiceId,
    string TicketNumber, int EstimatedWait) : DomainEvent;

public record TicketCalledEvent(
    Guid TicketId, Guid ClientId, Guid ServiceId,
    string TicketNumber, Guid AgentId) : DomainEvent;

public record TicketServedEvent(
    Guid TicketId, Guid ClientId, Guid ServiceId,
    string TicketNumber) : DomainEvent;

public record TicketNoShowEvent(
    Guid TicketId, Guid ClientId, string TicketNumber) : DomainEvent;

public record TicketCancelledEvent(
    Guid TicketId, Guid ClientId, string TicketNumber) : DomainEvent;
