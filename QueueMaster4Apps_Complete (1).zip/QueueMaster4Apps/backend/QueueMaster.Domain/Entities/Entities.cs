using QueueMaster.Domain.Enums;

namespace QueueMaster.Domain.Entities;

// ─── Client ───────────────────────────────────────────────────────────────────
public class Client
{
    public Guid Id { get; private set; }
    public string FullName { get; private set; } = string.Empty;
    public string Email { get; private set; } = string.Empty;
    public string? Phone { get; private set; }
    public string? FcmToken { get; private set; }
    public bool IsActive { get; private set; }
    public DateTime CreatedAt { get; private set; }
    public string PreferredLanguage { get; private set; } = "fr";

    public ICollection<Ticket> Tickets { get; private set; } = new List<Ticket>();
    public ICollection<Appointment> Appointments { get; private set; } = new List<Appointment>();
    public ICollection<NotificationLog> Notifications { get; private set; } = new List<NotificationLog>();

    private Client() { }

    public static Client Create(string fullName, string email, string? phone = null, string lang = "fr")
        => new()
        {
            Id = Guid.NewGuid(),
            FullName = fullName,
            Email = email.ToLowerInvariant(),
            Phone = phone,
            IsActive = true,
            CreatedAt = DateTime.UtcNow,
            PreferredLanguage = lang
        };

    public void UpdateFcmToken(string token) => FcmToken = token;
    public void Deactivate() => IsActive = false;
    public void UpdateProfile(string name, string? phone) { FullName = name; Phone = phone; }
}

// ─── Service ──────────────────────────────────────────────────────────────────
public class Service
{
    public Guid Id { get; private set; }
    public string Name { get; private set; } = string.Empty;
    public string? Description { get; private set; }
    public int MaxCapacity { get; private set; }
    public int AverageServiceMinutes { get; private set; }
    public bool IsActive { get; private set; }
    public TimeSpan OpenTime { get; private set; }
    public TimeSpan CloseTime { get; private set; }
    public string? Color { get; private set; }

    public ICollection<Ticket> Tickets { get; private set; } = new List<Ticket>();
    public ICollection<ServiceAgent> ServiceAgents { get; private set; } = new List<ServiceAgent>();

    private Service() { }

    public static Service Create(string name, string? desc, int cap, int avgMin,
        TimeSpan open, TimeSpan close, string? color = null)
        => new()
        {
            Id = Guid.NewGuid(),
            Name = name,
            Description = desc,
            MaxCapacity = cap,
            AverageServiceMinutes = avgMin,
            IsActive = true,
            OpenTime = open,
            CloseTime = close,
            Color = color ?? "#1E3A5F"
        };

    public void Update(string name, string? desc, int cap, int avgMin)
    {
        Name = name; Description = desc;
        MaxCapacity = cap; AverageServiceMinutes = avgMin;
    }
    public void SetActive(bool active) => IsActive = active;
}

// ─── Agent ────────────────────────────────────────────────────────────────────
public class Agent
{
    public Guid Id { get; private set; }
    public string FullName { get; private set; } = string.Empty;
    public string Counter { get; private set; } = string.Empty;
    public AgentStatus Status { get; private set; }
    public string UserId { get; private set; } = string.Empty;
    public DateTime CreatedAt { get; private set; }
    public int ServedToday { get; private set; }

    public ICollection<ServiceAgent> ServiceAgents { get; private set; } = new List<ServiceAgent>();
    public ICollection<Ticket> ServedTickets { get; private set; } = new List<Ticket>();

    private Agent() { }

    public static Agent Create(string fullName, string counter, string userId)
        => new()
        {
            Id = Guid.NewGuid(),
            FullName = fullName,
            Counter = counter,
            Status = AgentStatus.Offline,
            UserId = userId,
            CreatedAt = DateTime.UtcNow
        };

    public void SetStatus(AgentStatus status) => Status = status;
    public void IncrementServed() => ServedToday++;
    public void ResetDaily() => ServedToday = 0;
}

public class ServiceAgent
{
    public Guid ServiceId { get; set; }
    public Guid AgentId { get; set; }
    public Service? Service { get; set; }
    public Agent? Agent { get; set; }
}

// ─── Appointment ──────────────────────────────────────────────────────────────
public class Appointment
{
    public Guid Id { get; private set; }
    public Guid ClientId { get; private set; }
    public Guid ServiceId { get; private set; }
    public DateTime ScheduledAt { get; private set; }
    public AppointmentStatus Status { get; private set; }
    public string QrCode { get; private set; } = string.Empty;
    public Guid? TicketId { get; private set; }
    public DateTime CreatedAt { get; private set; }

    public Client? Client { get; private set; }
    public Service? Service { get; private set; }

    private Appointment() { }

    public static Appointment Create(Guid clientId, Guid serviceId, DateTime scheduledAt)
        => new()
        {
            Id = Guid.NewGuid(),
            ClientId = clientId,
            ServiceId = serviceId,
            ScheduledAt = scheduledAt,
            Status = AppointmentStatus.Confirmed,
            QrCode = Convert.ToBase64String(Guid.NewGuid().ToByteArray())
                .Replace("+", "").Replace("/", "").Replace("=", "")[..12].ToUpper(),
            CreatedAt = DateTime.UtcNow
        };

    public void LinkTicket(Guid ticketId) => TicketId = ticketId;
    public void Cancel() => Status = AppointmentStatus.Cancelled;
    public void MarkNoShow() => Status = AppointmentStatus.NoShow;
    public void MarkArrived() => Status = AppointmentStatus.Arrived;
}

// ─── Notification Log ─────────────────────────────────────────────────────────
public class NotificationLog
{
    public Guid Id { get; private set; }
    public Guid ClientId { get; private set; }
    public Guid? TicketId { get; private set; }
    public NotificationType Type { get; private set; }
    public string Title { get; private set; } = string.Empty;
    public string Body { get; private set; } = string.Empty;
    public NotificationChannel Channel { get; private set; }
    public bool IsSent { get; private set; }
    public string? ErrorMessage { get; private set; }
    public DateTime CreatedAt { get; private set; }
    public DateTime? SentAt { get; private set; }

    private NotificationLog() { }

    public static NotificationLog Create(Guid clientId, Guid? ticketId,
        NotificationType type, string title, string body, NotificationChannel channel)
        => new()
        {
            Id = Guid.NewGuid(),
            ClientId = clientId,
            TicketId = ticketId,
            Type = type,
            Title = title,
            Body = body,
            Channel = channel,
            IsSent = false,
            CreatedAt = DateTime.UtcNow
        };

    public void MarkSent() { IsSent = true; SentAt = DateTime.UtcNow; }
    public void MarkFailed(string error) { IsSent = false; ErrorMessage = error; }
}
