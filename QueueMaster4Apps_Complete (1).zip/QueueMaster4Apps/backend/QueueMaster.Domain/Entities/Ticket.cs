using QueueMaster.Domain.Enums;
using QueueMaster.Domain.Events;

namespace QueueMaster.Domain.Entities;

public class Ticket
{
    public Guid Id { get; private set; }
    public string TicketNumber { get; private set; } = string.Empty;
    public Guid ClientId { get; private set; }
    public Guid ServiceId { get; private set; }
    public TicketPriority Priority { get; private set; }
    public TicketStatus Status { get; private set; }
    public DateTime CreatedAt { get; private set; }
    public DateTime? CalledAt { get; private set; }
    public DateTime? ServedAt { get; private set; }
    public int EstimatedWaitMinutes { get; private set; }
    public int? ActualWaitMinutes { get; private set; }
    public Guid? AssignedAgentId { get; private set; }
    public string? Notes { get; private set; }

    private readonly List<IDomainEvent> _domainEvents = new();
    public IReadOnlyCollection<IDomainEvent> DomainEvents => _domainEvents.AsReadOnly();

    public Client? Client { get; private set; }
    public Service? Service { get; private set; }
    public Agent? AssignedAgent { get; private set; }

    private Ticket() { }

    public static Ticket Create(Guid clientId, Guid serviceId, TicketPriority priority,
        string ticketNumber, int estimatedWait)
    {
        var ticket = new Ticket
        {
            Id = Guid.NewGuid(),
            TicketNumber = ticketNumber,
            ClientId = clientId,
            ServiceId = serviceId,
            Priority = priority,
            Status = TicketStatus.Waiting,
            CreatedAt = DateTime.UtcNow,
            EstimatedWaitMinutes = estimatedWait
        };
        ticket._domainEvents.Add(new TicketCreatedEvent(ticket.Id, clientId, serviceId, ticketNumber, estimatedWait));
        return ticket;
    }

    public void Call(Guid agentId)
    {
        if (Status != TicketStatus.Waiting)
            throw new InvalidOperationException($"Cannot call ticket with status {Status}.");
        Status = TicketStatus.Calling;
        AssignedAgentId = agentId;
        CalledAt = DateTime.UtcNow;
        ActualWaitMinutes = (int)(CalledAt.Value - CreatedAt).TotalMinutes;
        _domainEvents.Add(new TicketCalledEvent(Id, ClientId, ServiceId, TicketNumber, agentId));
    }

    public void MarkServed(string? notes = null)
    {
        if (Status != TicketStatus.Calling)
            throw new InvalidOperationException($"Cannot serve ticket with status {Status}.");
        Status = TicketStatus.Served;
        ServedAt = DateTime.UtcNow;
        Notes = notes;
        _domainEvents.Add(new TicketServedEvent(Id, ClientId, ServiceId, TicketNumber));
    }

    public void MarkNoShow()
    {
        Status = TicketStatus.NoShow;
        ServedAt = DateTime.UtcNow;
        _domainEvents.Add(new TicketNoShowEvent(Id, ClientId, TicketNumber));
    }

    public void Cancel()
    {
        if (Status is TicketStatus.Served or TicketStatus.NoShow)
            throw new InvalidOperationException("Cannot cancel a completed ticket.");
        Status = TicketStatus.Cancelled;
        _domainEvents.Add(new TicketCancelledEvent(Id, ClientId, TicketNumber));
    }

    public void UpdatePriority(TicketPriority newPriority)
    {
        if (Status != TicketStatus.Waiting)
            throw new InvalidOperationException("Can only change priority of waiting tickets.");
        Priority = newPriority;
    }

    public void UpdateEstimatedWait(int minutes) => EstimatedWaitMinutes = minutes;
    public void ClearDomainEvents() => _domainEvents.Clear();
}
